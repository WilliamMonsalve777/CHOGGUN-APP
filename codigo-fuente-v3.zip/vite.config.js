import { defineConfig } from 'vite';

// Rutas relativas: el mismo build sirve en el navegador y dentro del APK (Capacitor).
export default defineConfig({
  base: './',
  server: { port: 5173 },
  build: { target: 'es2020', sourcemap: false, chunkSizeWarningLimit: 900, assetsInlineLimit: 0 },
});
