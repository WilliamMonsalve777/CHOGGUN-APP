import { defineConfig } from 'vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

// Un solo index.html autocontenido (como el que usa el flujo de GitHub).
export default defineConfig({
  base: './',
  server: { port: 5173 },
  plugins: [viteSingleFile()],
  build: { target: 'es2020', sourcemap: false, chunkSizeWarningLimit: 4000 },
});
