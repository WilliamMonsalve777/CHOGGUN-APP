/* ================= CHOGGUN — conexión con Supabase =================
 * Todo lo que antes se guardaba en el teléfono (localStorage) ahora vive en Supabase:
 * cuentas reales con correo confirmado, obras, comentarios, comunidades, mensajes, etc.
 * Este archivo traduce las filas de la base de datos al mismo formato que usan las pantallas.
 */
import { createClient } from '@supabase/supabase-js';
import { Capacitor } from '@capacitor/core';
import { Preferences } from '@capacitor/preferences';

export const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'https://ugwajrjdajfaaqsdzqge.supabase.co';
export const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_KEY || 'sb_publishable_149BX_73jWKYIb8L13KxIg_o1BMRidx';
export const MAX_VIDEO_MB = 50;

// En el APK la sesión se guarda con Preferences (almacenamiento nativo del teléfono).
const nativeStorage = {
  getItem: async (k) => (await Preferences.get({ key: k })).value,
  setItem: (k, v) => Preferences.set({ key: k, value: v }),
  removeItem: (k) => Preferences.remove({ key: k }),
};

export const sb = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: {
    storage: Capacitor.isNativePlatform() ? nativeStorage : undefined,
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
  },
  realtime: { params: { eventsPerSecond: 20 } },
});

/* ---------- errores en español ---------- */
const MESSAGES = [
  [/invalid login credentials/i, 'Correo o contraseña incorrectos'],
  [/email not confirmed/i, 'Confirma tu correo con el código que te enviamos', 'EMAIL_NOT_CONFIRMED'],
  [/user already registered|already been registered/i, 'Ya existe una cuenta con ese correo', 'EMAIL_TAKEN'],
  [/password should be at least|weak password|password is too weak/i, 'La contraseña es muy débil'],
  [/should be different from the old password/i, 'La nueva contraseña debe ser distinta de la actual'],
  [/token has expired|otp.*expired|invalid.*otp|token.*invalid/i, 'El código no es válido o ya venció. Pide uno nuevo.', 'BAD_CODE'],
  [/rate limit|too many requests|security purposes/i, 'Demasiados intentos. Espera un momento e inténtalo de nuevo.'],
  [/failed to fetch|network|load failed|networkerror|fetch/i, 'Sin conexión. Revisa tu internet.', 'NETWORK'],
  [/communities_pkey|duplicate key.*communities/i, 'Ya existe una comunidad con ese nombre'],
  [/profiles_username_key/i, 'Ese nombre de usuario ya existe'],
  [/payload too large|exceeded the maximum allowed size|entity too large/i, `El archivo es demasiado grande (máx. ${MAX_VIDEO_MB} MB)`],
  [/mime type .* is not supported|invalid mime/i, 'Formato de archivo no permitido'],
  [/JWT expired|invalid jwt/i, 'Tu sesión expiró. Vuelve a entrar.'],
  [/provider is not enabled|unsupported provider|provider.*disabled/i, 'El inicio con Google aún no está activado en Supabase'],
  [/audience|nonce|id token/i, 'Google no pudo validar tu cuenta. Revisa la configuración de Google en Supabase.'],
  [/row-level security|permission denied/i, 'No tienes permiso para hacer esto'],
];
export class AppError extends Error {
  constructor(message, code = 'ERROR') { super(message); this.code = code; }
}
export function toAppError(err) {
  if (err instanceof AppError) return err;
  const msg = String(err?.message || err?.error_description || err || '');
  for (const [re, text, code] of MESSAGES) if (re.test(msg)) return new AppError(text, code);
  // Los mensajes de la base de datos (RAISE EXCEPTION) ya vienen en español.
  if (/^[A-ZÁÉÍÓÚÑ¿¡][^_]{2,140}$/.test(msg) && /[áéíóúñ ]/i.test(msg)) return new AppError(msg);
  console.error(err);
  return new AppError('Ocurrió un error. Intenta de nuevo.');
}
async function q(p) {
  let r;
  try { r = await p; } catch (e) { throw toAppError(e); }
  if (r.error) throw toAppError(r.error);
  return r.data;
}

/* ---------- archivos ---------- */
export const publicUrl = (path) => (path ? sb.storage.from('media').getPublicUrl(path).data.publicUrl : null);
const MEDIA_PREFIX = () => `${SUPABASE_URL}/storage/v1/object/public/media/`;
/** De URL pública a ruta en el bucket (para guardar en la base). */
export function toPath(url) {
  if (!url) return null;
  const pre = MEDIA_PREFIX();
  return url.startsWith(pre) ? decodeURIComponent(url.slice(pre.length).split('?')[0]) : null;
}
function dataUrlToBlob(dataUrl) {
  const [head, b64] = dataUrl.split(',');
  const mime = head.match(/data:([^;]+)/)[1];
  const bin = atob(b64); const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: mime });
}
const EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov' };

/** Sube un archivo (data URL, Blob o File) con barra de progreso real. Devuelve la ruta. */
export async function upload(bucket, folder, src, onProgress) {
  const blob = typeof src === 'string' ? dataUrlToBlob(src) : src;
  const ext = EXT[blob.type];
  if (!ext) throw new AppError('Formato no permitido. Usa JPG, PNG, WEBP, GIF, MP4, WEBM o MOV.');
  if (blob.size > MAX_VIDEO_MB * 1024 * 1024) throw new AppError(`El archivo supera ${MAX_VIDEO_MB} MB`);
  const { data } = await sb.auth.getSession();
  const s = data.session; if (!s) throw new AppError('Tu sesión expiró. Vuelve a entrar.');
  const path = `${folder}/${crypto.randomUUID()}.${ext}`;
  const send = () => new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${SUPABASE_URL}/storage/v1/object/${bucket}/${path}`);
    xhr.setRequestHeader('Authorization', `Bearer ${s.access_token}`);
    xhr.setRequestHeader('apikey', SUPABASE_KEY);
    xhr.setRequestHeader('Content-Type', blob.type);
    xhr.setRequestHeader('x-upsert', 'false');
    xhr.setRequestHeader('cache-control', 'max-age=31536000');
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress && onProgress(e.loaded / e.total);
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) return resolve();
      let m = ''; try { m = JSON.parse(xhr.responseText).message || ''; } catch { /* nada */ }
      reject(xhr.status === 413 ? new AppError(`El archivo supera ${MAX_VIDEO_MB} MB`) : toAppError(new Error(m || `Error al subir (${xhr.status})`)));
    };
    xhr.onerror = () => reject(new AppError('Se perdió la conexión durante la subida', 'NETWORK'));
    xhr.send(blob);
  });
  try { await send(); } catch (e) {
    if (e.code !== 'NETWORK') throw e;
    await new Promise((r) => setTimeout(r, 1500)); await send(); // un reintento en redes móviles
  }
  return path;
}
export const removeFiles = (paths) => { const p = paths.filter(Boolean); if (p.length) sb.storage.from('media').remove(p).catch(() => {}); };

/* ═════════════ Cuenta ═════════════ */
export const getSession = async () => (await sb.auth.getSession()).data.session;
export const onAuth = (cb) => sb.auth.onAuthStateChange((ev, s) => setTimeout(() => cb(ev, s), 0));
export const signInWithGoogle = (token, nonce) => q(sb.auth.signInWithIdToken({ provider: 'google', token, nonce }));
export const signIn = (email, password) => q(sb.auth.signInWithPassword({ email: email.trim().toLowerCase(), password }));
export async function signUp({ email, password, username, name, role }) {
  const data = await q(sb.auth.signUp({ email: email.trim().toLowerCase(), password, options: { data: { username, name, role } } }));
  // Si el correo ya existía, Supabase no lo dice directamente: devuelve un usuario sin identidades.
  if (data.user && data.user.identities && data.user.identities.length === 0)
    throw new AppError('Ya existe una cuenta con ese correo. Inicia sesión o recupera tu contraseña.', 'EMAIL_TAKEN');
  return { needsCode: !data.session };
}
export const verifySignup = (email, code) => q(sb.auth.verifyOtp({ email: email.trim().toLowerCase(), token: code.trim(), type: 'email' }));
export const resendSignup = (email) => q(sb.auth.resend({ type: 'signup', email: email.trim().toLowerCase() }));
export const requestReset = (email) => q(sb.auth.resetPasswordForEmail(email.trim().toLowerCase()));
export async function resetWithCode(email, code, password) {
  await q(sb.auth.verifyOtp({ email: email.trim().toLowerCase(), token: code.trim(), type: 'recovery' }));
  await q(sb.auth.updateUser({ password }));
}
export async function changePassword(email, current, next) {
  await q(sb.auth.signInWithPassword({ email, password: current })).catch(() => { throw new AppError('La contraseña actual no es correcta'); });
  await q(sb.auth.updateUser({ password: next }));
}
export const signOut = () => sb.auth.signOut().catch(() => {});
export const usernameAvailable = (u) => q(sb.rpc('username_available', { p_username: u }));
export async function deleteMyAccount(uid) {
  // Primero los archivos (fotos, portadas, páginas, videos) y luego la cuenta con todo lo demás.
  for (const bucket of ['media', 'chat']) {
    try {
      const { data } = await sb.storage.from(bucket).list(uid, { limit: 1000 });
      const files = [];
      for (const f of data || []) {
        if (f.id) files.push(`${uid}/${f.name}`);
        else { const { data: sub } = await sb.storage.from(bucket).list(`${uid}/${f.name}`, { limit: 1000 }); (sub || []).forEach((x) => files.push(`${uid}/${f.name}/${x.name}`)); }
      }
      if (files.length) await sb.storage.from(bucket).remove(files);
    } catch { /* seguimos */ }
  }
  await q(sb.rpc('delete_my_account'));
  await signOut();
}

/* ═════════════ Lectura: filas → formato de la app ═════════════ */
const ms = (t) => (t ? new Date(t).getTime() : Date.now());
export function mapProfile(p) {
  return {
    id: p.id, username: p.username, name: p.name || p.username, role: p.role, bio: p.bio || '',
    genres: p.genres || [], collab: p.collab || [],
    avatar: publicUrl(p.avatar_path), avatarPath: p.avatar_path,
    bannerImg: publicUrl(p.banner_path), bannerPath: p.banner_path, banner: p.banner_seed || p.username,
    followerCount: p.follower_count, followingCount: p.following_count, workCount: p.work_count, karma: p.karma,
    isMod: !!p.is_mod, joined: ms(p.created_at),
  };
}
const WORK_COLS = 'id,author_id,type,title,synopsis,community_id,genres,cover_path,cover_seed,image_path,video_path,poster_path,chapters_meta,credits,license,mature,status,removed,views,score,comment_count,created_at';
export function mapWork(r, byId) {
  return {
    id: r.id, author: byId[r.author_id] || r.author_id, authorId: r.author_id, type: r.type, title: r.title,
    synopsis: r.synopsis || '', community: r.community_id || '', genres: r.genres || [],
    cover: publicUrl(r.cover_path), coverSeed: r.cover_seed,
    image: r.image_path ? { data: publicUrl(r.image_path) } : null,
    video: r.video_path ? { url: publicUrl(r.video_path), poster: publicUrl(r.poster_path) } : null,
    chaptersMeta: r.chapters_meta || [], chapters: null,
    credits: r.credits || [], license: r.license, mature: r.mature, status: r.status, removed: r.removed,
    views: r.views, score: r.score, commentCount: r.comment_count, created: ms(r.created_at), comments: null,
  };
}
const mapCommunity = (c, byId) => ({
  id: c.id, name: c.name, icon: c.icon, cat: c.cat, color: c.color, desc: c.descr, private: c.private,
  owner: c.owner_id ? byId[c.owner_id] || null : null, ownerId: c.owner_id, memberCount: c.member_count, created: ms(c.created_at),
});

/** Asegura tener los perfiles de estos ids (autores de obras, mensajes, etc.). */
export async function ensureProfiles(S, ids) {
  const missing = [...new Set(ids.filter((id) => id && !S.byId[id]))];
  for (let i = 0; i < missing.length; i += 100) {
    const rows = await q(sb.from('profiles').select('*').in('id', missing.slice(i, i + 100)));
    rows.forEach((p) => addProfile(S, p));
  }
}
export function addProfile(S, p) {
  const u = mapProfile(p);
  const prev = S.users[u.username];
  S.users[u.username] = prev ? Object.assign(prev, u) : u;
  S.byId[u.id] = u.username;
  return S.users[u.username];
}

/** Datos públicos: personas, comunidades y obras publicadas (más mis borradores). */
export async function loadPublic(S) {
  const [profiles, comms, works] = await Promise.all([
    q(sb.from('profiles').select('*').order('created_at', { ascending: false }).limit(2000)),
    q(sb.from('communities').select('*').order('created_at').limit(1000)),
    q(sb.from('works').select(WORK_COLS).order('created_at', { ascending: false }).limit(600)),
  ]);
  S.users = {}; S.byId = {};
  profiles.forEach((p) => addProfile(S, p));
  await ensureProfiles(S, [...works.map((w) => w.author_id), ...comms.map((c) => c.owner_id)]);
  S.communities = comms.map((c) => mapCommunity(c, S.byId));
  S.works = works.map((w) => mapWork(w, S.byId));
}
export async function refreshWork(S, id) {
  const r = await q(sb.from('works').select(WORK_COLS).eq('id', id).maybeSingle());
  if (!r) { S.works = S.works.filter((w) => w.id !== id); return null; }
  await ensureProfiles(S, [r.author_id]);
  return upsertWork(S, r);
}
export function upsertWork(S, r) {
  const w = mapWork(r, S.byId);
  const old = S.works.find((x) => x.id === r.id);
  if (old) { const keep = { chapters: old.chapters, comments: old.comments }; Object.assign(old, w, keep); if (w.status !== old.status) old.chapters = null; return old; }
  S.works.unshift(w); return w;
}
export function upsertCommunity(S, c) {
  const m = mapCommunity(c, S.byId); const i = S.communities.findIndex((x) => x.id === c.id);
  if (i >= 0) S.communities[i] = m; else S.communities.push(m);
}

/** Lo mío: votos, guardados, ocultos, comunidades, a quién sigo, historial, avisos, mensajes, reportes. */
export async function loadMine(S, uid) {
  const [votes, saved, hidden, joined, following, history, reports] = await Promise.all([
    q(sb.from('votes').select('work_id,value').eq('user_id', uid)),
    q(sb.from('saved_works').select('work_id').eq('user_id', uid).order('created_at', { ascending: false })),
    q(sb.from('hidden_works').select('work_id').eq('user_id', uid)),
    q(sb.from('community_members').select('community_id').eq('user_id', uid)),
    q(sb.from('follows').select('followee_id').eq('follower_id', uid)),
    q(sb.from('reading_history').select('*').eq('user_id', uid)),
    q(sb.from('reports').select('*').eq('reporter_id', uid).order('created_at', { ascending: false }).limit(200)),
  ]);
  await ensureProfiles(S, following.map((f) => f.followee_id));
  const me = S.session;
  S.myVotes = Object.fromEntries(votes.map((v) => [v.work_id, v.value]));
  S.saved = { [me]: saved.map((x) => x.work_id) };
  S.hidden = { [me]: hidden.map((x) => x.work_id) };
  S.joined = { [me]: joined.map((x) => x.community_id) };
  S.following = following.map((f) => S.byId[f.followee_id]).filter(Boolean);
  S.history = { [me]: Object.fromEntries(history.map((h) => [h.work_id, { ch: h.ch, pct: h.pct, pctCh: h.pct_ch, read: h.read || [], t: ms(h.updated_at) }])) };
  S.reports = reports.map(mapReport(S));
  // Obras guardadas o leídas que no estén entre las recientes
  const need = [...S.saved[me], ...Object.keys(S.history[me])].filter((id) => !S.works.some((w) => w.id === id));
  if (need.length) {
    const rows = await q(sb.from('works').select(WORK_COLS).in('id', [...new Set(need)].slice(0, 200)));
    await ensureProfiles(S, rows.map((r) => r.author_id));
    rows.forEach((r) => upsertWork(S, r));
  }
  await Promise.all([loadNotifs(S, uid), loadChats(S, uid)]);
}
const mapReport = (S) => (r) => ({
  rid: r.id, kind: r.kind, id: r.target_id, parent: r.parent_id, reason: r.reason, note: r.note,
  by: r.auto ? 'sistema' : (S.byId[r.reporter_id] || S.session), t: ms(r.created_at), status: r.status,
});

/* ---------- notificaciones ---------- */
const NOTIF_SELECT = '*, actor:profiles!notifications_actor_id_fkey(id,username,name), work:works(id,title)';
export async function loadNotifs(S, uid) {
  const rows = await q(sb.from('notifications').select(NOTIF_SELECT).eq('user_id', uid).order('id', { ascending: false }).limit(80));
  S.notifRows = rows;
}
export const fetchNotif = (id) => q(sb.from('notifications').select(NOTIF_SELECT).eq('id', id).maybeSingle());
export const markNotifRead = (id) => q(sb.from('notifications').update({ read: true }).eq('id', id));
export const markAllNotifsRead = (uid) => q(sb.from('notifications').update({ read: true }).eq('user_id', uid).eq('read', false));

/* ---------- mensajes ---------- */
const signed = {}; // ruta → URL firmada (las fotos del chat son privadas)
async function signChatImages(paths) {
  const need = [...new Set(paths.filter((p) => p && !signed[p]))];
  if (!need.length) return;
  const { data } = await sb.storage.from('chat').createSignedUrls(need, 60 * 60 * 24);
  (data || []).forEach((d) => { if (d.signedUrl) signed[d.path] = d.signedUrl; });
}
export const chatImg = (path) => signed[path] || null;
export async function loadChats(S, uid) {
  const [msgs, clears] = await Promise.all([
    q(sb.from('messages').select('*').or(`sender_id.eq.${uid},recipient_id.eq.${uid}`).order('created_at').limit(3000)),
    q(sb.from('chat_clears').select('*').eq('user_id', uid)),
  ]);
  await ensureProfiles(S, msgs.flatMap((m) => [m.sender_id, m.recipient_id]));
  await signChatImages(msgs.map((m) => m.img_path));
  S.clears = Object.fromEntries(clears.map((c) => [c.other_id, ms(c.cleared_at)]));
  S.chats = {};
  msgs.forEach((m) => addMessage(S, m));
}
export async function prepareMessage(S, m) {
  await ensureProfiles(S, [m.sender_id, m.recipient_id]);
  if (m.img_path) await signChatImages([m.img_path]);
}
export function addMessage(S, m) {
  const me = S.session; const mine = m.sender_id === S.uid;
  const otherId = mine ? m.recipient_id : m.sender_id; const other = S.byId[otherId];
  if (!other) return null;
  if (S.clears[otherId] && ms(m.created_at) <= S.clears[otherId]) return null;
  const id = [me, other].sort().join('__');
  const c = S.chats[id] = S.chats[id] || { members: [me, other], msgs: [], unread: {} };
  if (c.msgs.some((x) => x.id === m.id)) return null;
  const msg = { id: m.id, from: mine ? me : other, text: m.text, img: m.img_path ? chatImg(m.img_path) : null, t: ms(m.created_at), readAt: m.read_at };
  c.msgs.push(msg); c.msgs.sort((a, b) => a.t - b.t);
  if (!mine && !m.read_at) c.unread[me] = true;
  return msg;
}
export async function sendMessage(S, otherUsername, { text, img }) {
  const other = S.users[otherUsername];
  let img_path = null;
  if (img) img_path = await upload('chat', `${S.uid}/${other.id}`, img);
  const row = await q(sb.from('messages').insert({ recipient_id: other.id, text: text || '', img_path }).select('*').single());
  if (img_path) await signChatImages([img_path]);
  return row;
}
export const markChatRead = (uid, otherId) => q(sb.from('messages').update({ read_at: new Date().toISOString() }).eq('recipient_id', uid).eq('sender_id', otherId).is('read_at', null));
export const clearChat = (otherId) => q(sb.from('chat_clears').upsert({ other_id: otherId, cleared_at: new Date().toISOString() }, { onConflict: 'user_id,other_id' }));

/* ═════════════ Obras ═════════════ */
export async function loadContent(w) {
  const r = await q(sb.from('work_content').select('chapters').eq('work_id', w.id).maybeSingle());
  w.chapters = (r?.chapters || []).map((c) => (c.pages ? { title: c.title, pages: c.pages.map(publicUrl) } : { title: c.title, text: c.text || '' }));
  return w.chapters;
}
export async function loadComments(S, w) {
  const rows = await q(sb.from('comments').select('*').eq('work_id', w.id).order('created_at').limit(1000));
  await ensureProfiles(S, rows.map((r) => r.user_id));
  let mine = [];
  if (S.uid && rows.length) mine = await q(sb.from('comment_likes').select('comment_id').eq('user_id', S.uid).in('comment_id', rows.map((r) => r.id)));
  const liked = new Set(mine.map((x) => x.comment_id));
  const map = {}; const top = [];
  rows.forEach((r) => { map[r.id] = { id: r.id, user: S.byId[r.user_id] || '?', text: r.text, time: ms(r.created_at), likeCount: r.like_count, liked: liked.has(r.id), removed: r.removed, replies: [] }; });
  rows.forEach((r) => { if (r.parent_id) map[r.parent_id]?.replies.push(map[r.id]); else top.push(map[r.id]); });
  w.comments = top;
  return top;
}

/** Guarda una obra (nueva o editada): sube imágenes/video nuevos y escribe obra + capítulos. */
export async function saveWork(S, d, status, onProgress) {
  const uid = S.uid;
  const jobs = []; // archivos por subir: {src, set}
  const keepPath = (v) => (typeof v === 'string' && v.startsWith('data:') ? null : toPath(v));
  const row = {
    title: d.title.trim(), synopsis: (d.synopsis || '').trim(), community_id: d.community || null,
    genres: d.genres, cover_seed: d.coverSeed || null, credits: d.credits || [], license: d.license, mature: !!d.mature, status,
    cover_path: null, image_path: null, video_path: null, poster_path: null,
  };
  if (d.type !== 'foro' && d.type !== 'ilustracion' && d.cover) {
    const p = keepPath(d.cover); if (p) row.cover_path = p; else jobs.push({ src: d.cover, set: (x) => { row.cover_path = x; } });
  }
  if (d.type === 'ilustracion' && d.image?.data) {
    const p = keepPath(d.image.data); if (p) row.image_path = p; else jobs.push({ src: d.image.data, set: (x) => { row.image_path = x; } });
  }
  if (d.type === 'video') {
    if (d.videoFile) jobs.push({ src: d.videoFile, set: (x) => { row.video_path = x; } });
    else row.video_path = toPath(d.video?.url);
    if (d.posterData) jobs.push({ src: d.posterData, set: (x) => { row.poster_path = x; } });
    else row.poster_path = toPath(d.video?.poster);
  }
  let chapters = [];
  if (['novela', 'relato'].includes(d.type)) chapters = d.chapters.map((c) => ({ title: (c.title || '').trim() || 'Capítulo', text: (c.text || '').trim() }));
  if (['manga', 'comic'].includes(d.type)) {
    chapters = d.chapters.map((c) => ({ title: (c.title || '').trim() || 'Capítulo', pages: [] }));
    d.chapters.forEach((c, i) => (c.pages || []).forEach((pg, k) => {
      const p = keepPath(pg); if (p) chapters[i].pages[k] = p; else jobs.push({ src: pg, set: (x) => { chapters[i].pages[k] = x; } });
    }));
  }
  // Subidas (de a 3 a la vez) con progreso total
  const total = jobs.length; let done = 0; const uploaded = [];
  const progress = {};
  const report = () => onProgress && total && onProgress(done, total, Object.values(progress).reduce((a, b) => a + b, 0) / total);
  try {
    for (let i = 0; i < jobs.length; i += 3) {
      await Promise.all(jobs.slice(i, i + 3).map(async (j, k) => {
        const path = await upload('media', uid, j.src, (f) => { progress[i + k] = f; report(); });
        uploaded.push(path); j.set(path); done++; progress[i + k] = 1; report();
      }));
    }
    let saved;
    if (d.editId) saved = await q(sb.from('works').update(row).eq('id', d.editId).select(WORK_COLS).single());
    else saved = await q(sb.from('works').insert({ ...row, type: d.type }).select(WORK_COLS).single());
    if (['novela', 'relato', 'manga', 'comic'].includes(d.type))
      await q(sb.from('work_content').upsert({ work_id: saved.id, chapters }, { onConflict: 'work_id' }));
    const fresh = await q(sb.from('works').select(WORK_COLS).eq('id', saved.id).single());
    const w = upsertWork(S, fresh);
    w.chapters = null;
    return w;
  } catch (e) {
    removeFiles(uploaded); // no dejar archivos huérfanos si algo falló
    throw e;
  }
}
export async function deleteWork(w) {
  const paths = [toPath(w.cover), toPath(w.image?.data), toPath(w.video?.url), toPath(w.video?.poster)];
  try { if (!w.chapters) await loadContent(w); (w.chapters || []).forEach((c) => (c.pages || []).forEach((p) => paths.push(toPath(p)))); } catch { /* nada */ }
  await q(sb.from('works').delete().eq('id', w.id));
  removeFiles(paths);
}
export const addView = (id) => sb.rpc('add_view', { p_work: id }).then(() => {}, () => {});
export async function vote(workId, value) {
  if (value === 0) return q(sb.from('votes').delete().eq('work_id', workId).eq('user_id', (await getSession()).user.id));
  return q(sb.from('votes').upsert({ work_id: workId, value }, { onConflict: 'work_id,user_id' }));
}
// Para insertar solo se mandan las columnas permitidas (user_id/follower_id los pone la base).
const stripOwner = (row) => { const r = { ...row }; delete r.user_id; delete r.follower_id; return r; };
async function toggleRow(table, row, on, keys) {
  if (on) {
    const { error } = await sb.from(table).insert(stripOwner(row));
    if (error && error.code !== '23505') throw toAppError(error);
  } else {
    let qb = sb.from(table).delete();
    for (const k of keys) qb = qb.eq(k, row[k]);
    await q(qb);
  }
}
export const setSaved = (uid, workId, on) => toggleRow('saved_works', { user_id: uid, work_id: workId }, on, ['user_id', 'work_id']);
export const setHidden = (uid, workId, on) => toggleRow('hidden_works', { user_id: uid, work_id: workId }, on, ['user_id', 'work_id']);
export const setJoined = (uid, cid, on) => toggleRow('community_members', { user_id: uid, community_id: cid }, on, ['user_id', 'community_id']);
export const setFollow = (uid, otherId, on) => toggleRow('follows', { follower_id: uid, followee_id: otherId }, on, ['follower_id', 'followee_id']);
export const setCommentLike = (uid, cid, on) => toggleRow('comment_likes', { user_id: uid, comment_id: cid }, on, ['user_id', 'comment_id']);
export async function addComment(workId, text, parentId, flagged) {
  return q(sb.from('comments').insert({ work_id: workId, text, parent_id: parentId || null, flagged: !!flagged }).select('*').single());
}
export const deleteComment = (id) => q(sb.from('comments').delete().eq('id', id));

let histTimer = {}; let histData = {};
/** Guarda el progreso de lectura (agrupado para no escribir en cada scroll). */
export function saveHistory(workId, h) {
  histData[workId] = h; clearTimeout(histTimer[workId]);
  histTimer[workId] = setTimeout(() => {
    const x = histData[workId];
    sb.from('reading_history').upsert({ work_id: workId, ch: x.ch, pct: Math.min(1, Math.max(0, x.pct || 0)), pct_ch: x.pctCh || 0, read: x.read || [] }, { onConflict: 'user_id,work_id' }).then(() => {}, () => {});
  }, 1500);
}

/* ═════════════ Comunidades, perfil, reportes ═════════════ */
export async function createCommunity(S, c) {
  const r = await q(sb.from('communities').insert({ id: c.id, name: c.name, icon: c.icon, cat: c.cat, color: c.color, descr: c.desc, private: c.private }).select('*').single());
  upsertCommunity(S, r); return r;
}
export const deleteCommunity = (id) => q(sb.from('communities').delete().eq('id', id));
export async function loadUserCommunities(uid) {
  return (await q(sb.from('community_members').select('community_id').eq('user_id', uid))).map((x) => x.community_id);
}
export async function updateProfile(S, e) {
  const me = S.users[S.session];
  const patch = { name: e.name.trim(), bio: (e.bio || '').trim(), role: e.role, genres: e.genres || [], collab: e.collab || [], banner_seed: e.banner || me.banner };
  const old = [];
  if (e.avatar && e.avatar.startsWith('data:')) { patch.avatar_path = await upload('media', S.uid, e.avatar); if (me.avatarPath) old.push(me.avatarPath); }
  else if (!e.avatar) { patch.avatar_path = null; if (me.avatarPath) old.push(me.avatarPath); }
  if (e.bannerImg && e.bannerImg.startsWith('data:')) { patch.banner_path = await upload('media', S.uid, e.bannerImg); if (me.bannerPath) old.push(me.bannerPath); }
  else if (!e.bannerImg) { patch.banner_path = null; if (me.bannerPath) old.push(me.bannerPath); }
  const r = await q(sb.from('profiles').update(patch).eq('id', S.uid).select('*').single());
  removeFiles(old);
  return addProfile(S, r);
}
export async function report(S, { kind, id, parent, reason, note, auto }) {
  const r = await q(sb.from('reports').insert({ kind, target_id: String(id), parent_id: parent ? String(parent) : null, reason, note: note || '', auto: !!auto }).select('*').single());
  S.reports.unshift(mapReport(S)(r));
}
export const modReports = () => q(sb.rpc('mod_reports'));
export const modResolve = (id, status) => q(sb.rpc('mod_resolve', { p_report: id, p_status: status }));

/* ═════════════ Match ═════════════
 * La tabla match_profiles solo la puede leer su dueño. Los perfiles de los demás llegan
 * por funciones (match_candidates, my_matches, match_profile_of) que nunca devuelven coordenadas. */
const MP_COLS = 'user_id,active,photos,about,match_role,seeking_role,looking_for,genres,languages,experience,commitment,portfolio,country,country_code,city,lat,lng,located_at,is_adult,updated_at';
function mapMyMatch(r) {
  if (!r) return null;
  return {
    active: r.active, photos: (r.photos || []).map(publicUrl), photoPaths: r.photos || [], about: r.about,
    role: r.match_role, seeking: r.seeking_role, lookingFor: r.looking_for || [], genres: r.genres || [],
    languages: r.languages || [], experience: r.experience, commitment: r.commitment, portfolio: r.portfolio || '',
    country: r.country || '', countryCode: r.country_code || '', city: r.city || '',
    hasLocation: r.lat != null && r.lng != null, locatedAt: r.located_at ? ms(r.located_at) : null, isAdult: r.is_adult,
  };
}
/** Ficha de otra persona tal como la devuelven las funciones de la base. */
export function mapMatchCard(c) {
  return {
    userId: c.userId, username: c.username, name: c.name || c.username, avatar: publicUrl(c.avatarPath),
    photos: (c.photos || []).map(publicUrl), about: c.about || '', role: c.role, seeking: c.seeking,
    lookingFor: c.lookingFor || [], genres: c.genres || [], languages: c.languages || [],
    experience: c.experience, commitment: c.commitment, portfolio: c.portfolio || '',
    country: c.country || '', countryCode: c.countryCode || '', city: c.city || '',
    km: c.km, affinity: c.affinity || 0, matchId: c.matchId || null, matchedAt: c.createdAt ? ms(c.createdAt) : null,
  };
}
export async function loadMyMatchProfile(uid) {
  const r = await sb.from('match_profiles').select(MP_COLS).eq('user_id', uid).maybeSingle();
  // Si aún no se ejecutó supabase-match.sql, la tabla no existe.
  if (r.error && (/match_profiles|schema cache|does not exist/i.test(r.error.message || '') || ['42P01', 'PGRST205'].includes(r.error.code)))
    throw new AppError('Match aún no está activado en el servidor', 'NO_MATCH_DB');
  if (r.error) throw toAppError(r.error);
  return mapMyMatch(r.data);
}
/** Guarda mi perfil de Match: sube las fotos nuevas, borra las que quité. */
export async function saveMatchProfile(S, d, onProgress) {
  const uid = S.uid;
  const prev = S.match.profile;
  const paths = []; const uploaded = [];
  const news = d.photos.filter((p) => p.startsWith('data:')).length; let done = 0;
  try {
    for (const p of d.photos) {
      if (p.startsWith('data:')) {
        const path = await upload('media', `${uid}/match`, p, (f) => onProgress && onProgress(done, news, (done + f) / news));
        uploaded.push(path); paths.push(path); done++;
      } else {
        const path = toPath(p); if (path) paths.push(path);
      }
    }
    const row = {
      active: d.active !== false, photos: paths, about: d.about.trim(), match_role: d.role, seeking_role: d.seeking,
      looking_for: d.lookingFor, genres: d.genres, languages: d.languages, experience: d.experience, commitment: d.commitment,
      portfolio: (d.portfolio || '').trim(), country: (d.country || '').trim(), country_code: (d.countryCode || '').toUpperCase(),
      city: (d.city || '').trim(), is_adult: !!d.isAdult,
    };
    if (d.coords) { row.lat = d.coords.lat; row.lng = d.coords.lng; }
    else if (d.clearCoords) { row.lat = null; row.lng = null; }
    const r = prev
      ? await q(sb.from('match_profiles').update(row).eq('user_id', uid).select(MP_COLS).single())
      : await q(sb.from('match_profiles').insert(row).select(MP_COLS).single());
    if (prev) removeFiles((prev.photoPaths || []).filter((p) => !paths.includes(p)));
    return mapMyMatch(r);
  } catch (e) {
    removeFiles(uploaded);
    throw e;
  }
}
export async function setMatchActive(uid, active) {
  return mapMyMatch(await q(sb.from('match_profiles').update({ active }).eq('user_id', uid).select(MP_COLS).single()));
}
export async function deleteMatchProfile(S) {
  const prev = S.match.profile;
  await q(sb.from('match_profiles').delete().eq('user_id', S.uid));
  if (prev) removeFiles(prev.photoPaths || []);
}
export async function matchCandidates({ maxKm = 0, role = 'Cualquiera' } = {}) {
  const rows = await q(sb.rpc('match_candidates', { p_max_km: maxKm || 0, p_role: role || 'Cualquiera', p_limit: 30 }));
  return (rows || []).map(mapMatchCard);
}
export const matchSwipe = (targetId, like) => q(sb.rpc('match_swipe', { p_target: targetId, p_like: !!like }));
export const matchUndo = (targetId) => q(sb.rpc('match_undo', { p_target: targetId }));
export async function myMatches() { return ((await q(sb.rpc('my_matches'))) || []).map(mapMatchCard); }
export async function matchProfileOf(userId) {
  const r = await q(sb.rpc('match_profile_of', { p_user: userId }));
  return r ? mapMatchCard(r) : null;
}
export const unmatch = (matchId) => q(sb.from('matches').delete().eq('id', matchId));
export async function loadBlocks(uid) {
  return (await q(sb.from('blocks').select('blocked_id').eq('blocker_id', uid))).map((b) => b.blocked_id);
}
export async function block(otherId) {
  const { error } = await sb.from('blocks').insert({ blocked_id: otherId });
  if (error && error.code !== '23505') throw toAppError(error);
}
export const unblock = (uid, otherId) => q(sb.from('blocks').delete().eq('blocker_id', uid).eq('blocked_id', otherId));

/* ═════════════ Tiempo real ═════════════ */
let channel = null;
export function subscribe(uid, h) {
  if (channel) sb.removeChannel(channel);
  let ch = sb.channel(`choggun:${uid || 'invitado'}:${Date.now()}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'works' }, h.works)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, h.profiles)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'communities' }, h.communities)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'comments' }, h.comments);
  if (uid) {
    ch = ch
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${uid}` }, h.notifications)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `recipient_id=eq.${uid}` }, h.messages)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `sender_id=eq.${uid}` }, h.messages);
  }
  channel = ch.subscribe((status) => h.status && h.status(status));
}
export function unsubscribe() { if (channel) { sb.removeChannel(channel); channel = null; } }
export function refreshRealtimeAuth() { sb.realtime.setAuth().catch(() => {}); }
export function reconnect() { if (channel && !sb.realtime.isConnected()) sb.realtime.connect(); }
