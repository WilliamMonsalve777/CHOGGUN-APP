/* CHOGGUN 3 — la app original, ahora conectada a Supabase (cuentas reales, sin bots). */
import './styles.css';
import { Capacitor, CapacitorHttp } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { Browser } from '@capacitor/browser';
import { Share } from '@capacitor/share';
import { SplashScreen } from '@capacitor/splash-screen';
import { StatusBar } from '@capacitor/status-bar';
import { SocialLogin } from '@capgo/capacitor-social-login';
import { Geolocation } from '@capacitor/geolocation';
import * as DB from './db.js';
import logoImg from './assets/logo.png';
import avdefImg from './assets/avdef.jpg';
import fondo1Img from './assets/fondo1.jpg';
import fondo2Img from './assets/fondo2.jpg';
import matchImg from './assets/match.jpg';
import googleImg from './assets/google.png';
const isNative = Capacitor.isNativePlatform();

/* ================= Iconos + arte generado ================= */
/* ================= Iconos Lucide (lucide.dev, licencia ISC) ================= */
const ICONS = {"arrow-up":"<path d=\"m5 12 7-7 7 7\"/><path d=\"M12 19V5\"/>","at-sign":"<circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8\"/>","badge":"<path d=\"M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z\"/>","ban":"<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M4.929 4.929 19.07 19.071\"/>","bell":"<path d=\"M10.268 21a2 2 0 0 0 3.464 0\"/><path d=\"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326\"/>","book":"<path d=\"M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20\"/>","book-image":"<path d=\"m20 13.7-2.1-2.1a2 2 0 0 0-2.8 0L9.7 17\"/><path d=\"M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20\"/><circle cx=\"10\" cy=\"8\" r=\"2\"/>","book-open":"<path d=\"M12 5v16\"/><path d=\"M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z\"/>","book-open-text":"<path d=\"M12 5v16\"/><path d=\"M16 13h2\"/><path d=\"M16 9h2\"/><path d=\"M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z\"/><path d=\"M6 13h2\"/><path d=\"M6 9h2\"/>","bookmark":"<path d=\"M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z\"/>","brush":"<path d=\"m11 10 3 3\"/><path d=\"M6.5 21A3.5 3.5 0 1 0 3 17.5a2.62 2.62 0 0 1-.708 1.792A1 1 0 0 0 3 21z\"/><path d=\"M9.969 17.031 21.378 5.624a1 1 0 0 0-3.002-3.002L6.967 14.031\"/>","camera":"<path d=\"M13.997 4a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 1.759-1.048l.489-.904A2 2 0 0 1 10.004 4z\"/><circle cx=\"12\" cy=\"13\" r=\"3\"/>","castle":"<path d=\"M10 5V3\"/><path d=\"M14 5V3\"/><path d=\"M15 21v-3a3 3 0 0 0-6 0v3\"/><path d=\"M18 3v8\"/><path d=\"M18 5H6\"/><path d=\"M22 11H2\"/><path d=\"M22 9v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9\"/><path d=\"M6 3v8\"/>","cat":"<path d=\"M12 5c.67 0 1.35.09 2 .26 1.78-2 5.03-2.84 6.42-2.26 1.4.58-.42 7-.42 7 .57 1.07 1 2.24 1 3.44C21 17.9 16.97 21 12 21s-9-3-9-7.56c0-1.25.5-2.4 1-3.44 0 0-1.89-6.42-.5-7 1.39-.58 4.72.23 6.5 2.23A9.04 9.04 0 0 1 12 5Z\"/><path d=\"M8 14v.5\"/><path d=\"M16 14v.5\"/><path d=\"M11.25 16.25h1.5L12 17l-.75-.75Z\"/>","check":"<path d=\"M20 6 9 17l-5-5\"/>","chevron-down":"<path d=\"m6 9 6 6 6-6\"/>","chevron-left":"<path d=\"m15 18-6-6 6-6\"/>","chevron-right":"<path d=\"m9 18 6-6-6-6\"/>","chevron-up":"<path d=\"m18 15-6-6-6 6\"/>","clapperboard":"<path d=\"m12.296 3.464 3.02 3.956\"/><path d=\"M20.2 6 3 11l-.9-2.4c-.3-1.1.3-2.2 1.3-2.5l13.5-4c1.1-.3 2.2.3 2.5 1.3z\"/><path d=\"M3 11h18v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"/><path d=\"m6.18 5.276 3.1 3.899\"/>","clock":"<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M12 6v6l4 2\"/>","coffee":"<path d=\"M10 2v2\"/><path d=\"M14 2v2\"/><path d=\"M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1\"/><path d=\"M6 2v2\"/>","compass":"<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z\"/>","copyright":"<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M14.83 14.83a4 4 0 1 1 0-5.66\"/>","cpu":"<path d=\"M12 20v2\"/><path d=\"M12 2v2\"/><path d=\"M17 20v2\"/><path d=\"M17 2v2\"/><path d=\"M2 12h2\"/><path d=\"M2 17h2\"/><path d=\"M2 7h2\"/><path d=\"M20 12h2\"/><path d=\"M20 17h2\"/><path d=\"M20 7h2\"/><path d=\"M7 20v2\"/><path d=\"M7 2v2\"/><rect x=\"4\" y=\"4\" width=\"16\" height=\"16\" rx=\"2\"/><rect x=\"8\" y=\"8\" width=\"8\" height=\"8\" rx=\"1\"/>","crown":"<path d=\"M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z\"/><path d=\"M5 21h14\"/>","download":"<path d=\"M12 15V3\"/><path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\"/><path d=\"m7 10 5 5 5-5\"/>","drama":"<path d=\"M10 11h.01\"/><path d=\"M14 6h.01\"/><path d=\"M18 6h.01\"/><path d=\"M6.5 13.1h.01\"/><path d=\"M22 5c0 9-4 12-6 12s-6-3-6-12c0-2 2-3 6-3s6 1 6 3\"/><path d=\"M17.4 9.9c-.8.8-2 .8-2.8 0\"/><path d=\"M10.1 7.1C9 7.2 7.7 7.7 6 8.6c-3.5 2-4.7 3.9-3.7 5.6 4.5 7.8 9.5 8.4 11.2 7.4.9-.5 1.9-2.1 1.9-4.7\"/><path d=\"M9.1 16.5c.3-1.1 1.4-1.7 2.4-1.4\"/>","edit":"<path d=\"M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7\"/><path d=\"M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z\"/>","ellipsis":"<circle cx=\"12\" cy=\"12\" r=\"1\"/><circle cx=\"19\" cy=\"12\" r=\"1\"/><circle cx=\"5\" cy=\"12\" r=\"1\"/>","eye":"<path d=\"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/>","eye-off":"<path d=\"M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49\"/><path d=\"M14.084 14.158a3 3 0 0 1-4.242-4.242\"/><path d=\"M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143\"/><path d=\"m2 2 20 20\"/>","feather":"<path d=\"M14.086 18.412A2 2 0 0112.67 19H5v-7.672a2 2 0 01.586-1.414L11.75 3.75a6 6 0 118.49 8.49z\"/><path d=\"M16 8 2 22\"/><path d=\"M17.488 15H9\"/>","file":"<path d=\"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z\"/><path d=\"M14 2v5a1 1 0 0 0 1 1h5\"/>","file-text":"<path d=\"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z\"/><path d=\"M14 2v5a1 1 0 0 0 1 1h5\"/><path d=\"M10 9H8\"/><path d=\"M16 13H8\"/><path d=\"M16 17H8\"/>","filter":"<path d=\"M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z\"/>","flag":"<path d=\"M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528\"/>","flower-2":"<path d=\"M12 5a3 3 0 1 1 3 3m-3-3a3 3 0 1 0-3 3m3-3v1M9 8a3 3 0 1 0 3 3M9 8h1m5 0a3 3 0 1 1-3 3m3-3h-1m-2 3v-1\"/><circle cx=\"12\" cy=\"8\" r=\"2\"/><path d=\"M12 10v12\"/><path d=\"M12 22c4.2 0 7-1.667 7-5-4.2 0-7 1.667-7 5Z\"/><path d=\"M12 22c-4.2 0-7-1.667-7-5 4.2 0 7 1.667 7 5Z\"/>","funnel":"<path d=\"M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z\"/>","gamepad-2":"<line x1=\"6\" x2=\"10\" y1=\"11\" y2=\"11\"/><line x1=\"8\" x2=\"8\" y1=\"9\" y2=\"13\"/><line x1=\"15\" x2=\"15.01\" y1=\"12\" y2=\"12\"/><line x1=\"18\" x2=\"18.01\" y1=\"10\" y2=\"10\"/><path d=\"M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z\"/>","ghost":"<path d=\"M15 10v1\"/><path d=\"M7.528 20.472a1.6 1.6 0 012.277 0l1.057 1.056a1.6 1.6 0 002.276 0l1.057-1.056a1.6 1.6 0 012.277 0l1.114 1.114a1.4 1.4 0 002.414-1V10a8 8 0 00-16 0v10.586a1.4 1.4 0 002.414 1z\"/><path d=\"M9 10v1\"/>","globe":"<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20\"/><path d=\"M2 12h20\"/>","grab":"<path d=\"M18 11.5V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1.4\"/><path d=\"M14 10V8a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2\"/><path d=\"M10 9.9V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v5\"/><path d=\"M6 14a2 2 0 0 0-2-2a2 2 0 0 0-2 2\"/><path d=\"M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-4a8 8 0 0 1-8-8 2 2 0 1 1 4 0\"/>","grid":"<rect width=\"18\" height=\"18\" x=\"3\" y=\"3\" rx=\"2\"/><path d=\"M3 9h18\"/><path d=\"M3 15h18\"/><path d=\"M9 3v18\"/><path d=\"M15 3v18\"/>","handshake":"<path d=\"m11 17 2 2a1 1 0 1 0 3-3\"/><path d=\"m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4\"/><path d=\"m21 3 1 11h-2\"/><path d=\"M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3\"/><path d=\"M3 4h8\"/>","heart":"<path d=\"M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5\"/>","heart-handshake":"<path d=\"M19.414 14.414C21 12.828 22 11.5 22 9.5a5.5 5.5 0 0 0-9.591-3.676.6.6 0 0 1-.818.001A5.5 5.5 0 0 0 2 9.5c0 2.3 1.5 4 3 5.5l5.535 5.362a2 2 0 0 0 2.879.052 2.12 2.12 0 0 0-.004-3 2.124 2.124 0 1 0 3-3 2.124 2.124 0 0 0 3.004 0 2 2 0 0 0 0-2.828l-1.881-1.882a2.41 2.41 0 0 0-3.409 0l-1.71 1.71a2 2 0 0 1-2.828 0 2 2 0 0 1 0-2.828l2.823-2.762\"/>","home":"<path d=\"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8\"/><path d=\"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"/>","house":"<path d=\"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8\"/><path d=\"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z\"/>","image":"<rect width=\"18\" height=\"18\" x=\"3\" y=\"3\" rx=\"2\" ry=\"2\"/><circle cx=\"9\" cy=\"9\" r=\"2\"/><path d=\"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21\"/>","info":"<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"M12 16v-4\"/><path d=\"M12 8h.01\"/>","layers":"<path d=\"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z\"/><path d=\"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12\"/><path d=\"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17\"/>","library":"<path d=\"m16 6 4 14\"/><path d=\"M12 6v14\"/><path d=\"M8 8v12\"/><path d=\"M4 4v16\"/>","lightbulb":"<path d=\"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5\"/><path d=\"M9 18h6\"/><path d=\"M10 22h4\"/>","link":"<path d=\"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71\"/><path d=\"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71\"/>","list":"<path d=\"M3 5h.01\"/><path d=\"M3 12h.01\"/><path d=\"M3 19h.01\"/><path d=\"M8 5h13\"/><path d=\"M8 12h13\"/><path d=\"M8 19h13\"/>","lock":"<rect width=\"18\" height=\"11\" x=\"3\" y=\"11\" rx=\"2\" ry=\"2\"/><path d=\"M7 11V7a5 5 0 0 1 10 0v4\"/>","log-out":"<path d=\"m16 17 5-5-5-5\"/><path d=\"M21 12H9\"/><path d=\"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4\"/>","map-pin":"<path d=\"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0\"/><circle cx=\"12\" cy=\"10\" r=\"3\"/>","mail":"<path d=\"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7\"/><rect x=\"2\" y=\"4\" width=\"20\" height=\"16\" rx=\"2\"/>","message-circle":"<path d=\"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719\"/>","message-square":"<path d=\"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z\"/>","messages-square":"<path d=\"M16 10a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 14.286V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z\"/><path d=\"M20 9a2 2 0 0 1 2 2v10.286a.71.71 0 0 1-1.212.502l-2.202-2.202A2 2 0 0 0 17.172 19H10a2 2 0 0 1-2-2v-1\"/>","moon":"<path d=\"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401\"/>","moon-star":"<path d=\"M18 5h4\"/><path d=\"M20 3v4\"/><path d=\"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401\"/>","mountain":"<path d=\"m8 3 4 8 5-5 5 15H2L8 3z\"/>","music":"<path d=\"M21 16V3a1 1 0 0 0-1.28-.96l-10 2.917a1 1 0 0 0-.72.96V19\"/><circle cx=\"18\" cy=\"16\" r=\"3\"/><circle cx=\"6\" cy=\"19\" r=\"3\"/>","newspaper":"<path d=\"M15 18h-5\"/><path d=\"M18 14h-8\"/><path d=\"M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0v-9a2 2 0 0 1 2-2h2\"/><rect width=\"8\" height=\"4\" x=\"10\" y=\"6\" rx=\"1\"/>","orbit":"<path d=\"M20.341 6.484A10 10 0 0 1 10.266 21.85\"/><path d=\"M3.659 17.516A10 10 0 0 1 13.74 2.152\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/><circle cx=\"19\" cy=\"5\" r=\"2\"/><circle cx=\"5\" cy=\"19\" r=\"2\"/>","palette":"<path d=\"M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z\"/><circle cx=\"13.5\" cy=\"6.5\" r=\".5\" fill=\"currentColor\"/><circle cx=\"17.5\" cy=\"10.5\" r=\".5\" fill=\"currentColor\"/><circle cx=\"6.5\" cy=\"12.5\" r=\".5\" fill=\"currentColor\"/><circle cx=\"8.5\" cy=\"7.5\" r=\".5\" fill=\"currentColor\"/>","pen-line":"<path d=\"M13 21h8\"/><path d=\"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z\"/>","pen-tool":"<path d=\"m18 13-.654-4.736a4 4 0 00-2.756-3.266l-9.163-2.9a2 2 0 00-2.017.493l-.82.819a2 2 0 00-.492 2.017l2.9 9.163a4 4 0 003.266 2.756L13 18\"/><path d=\"M18.648 12.352a1.205 1.205 0 011.704 0l1.296 1.296a1.205 1.205 0 010 1.704l-6.296 6.296a1.205 1.205 0 01-1.704 0l-1.296-1.296a1.205 1.205 0 010-1.704z\"/><path d=\"m3 3 6.586 6.586\"/><circle cx=\"11\" cy=\"11\" r=\"2\"/>","plus":"<path d=\"M5 12h14\"/><path d=\"M12 5v14\"/>","refresh-cw":"<path d=\"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8\"/><path d=\"M21 3v5h-5\"/><path d=\"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16\"/><path d=\"M8 16H3v5\"/>","rocket":"<path d=\"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5\"/><path d=\"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09\"/><path d=\"M9 12a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.4 22.4 0 0 1-4 2z\"/><path d=\"M9 12H4s.55-3.03 2-4c1.62-1.08 5 .05 5 .05\"/>","save":"<path d=\"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z\"/><path d=\"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7\"/><path d=\"M7 3v4a1 1 0 0 0 1 1h7\"/>","scroll":"<path d=\"M19 17V5a2 2 0 0 0-2-2H4\"/><path d=\"M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3\"/>","search":"<path d=\"m21 21-4.34-4.34\"/><circle cx=\"11\" cy=\"11\" r=\"8\"/>","send":"<path d=\"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z\"/><path d=\"m21.854 2.147-10.94 10.939\"/>","settings":"<path d=\"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/>","share":"<path d=\"M12 2v13\"/><path d=\"m16 6-4-4-4 4\"/><path d=\"M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8\"/>","share-2":"<circle cx=\"18\" cy=\"5\" r=\"3\"/><circle cx=\"6\" cy=\"12\" r=\"3\"/><circle cx=\"18\" cy=\"19\" r=\"3\"/><line x1=\"8.59\" x2=\"15.42\" y1=\"13.51\" y2=\"17.49\"/><line x1=\"15.41\" x2=\"8.59\" y1=\"6.51\" y2=\"10.49\"/>","sheet":"<rect width=\"18\" height=\"18\" x=\"3\" y=\"3\" rx=\"2\" ry=\"2\"/><line x1=\"3\" x2=\"21\" y1=\"9\" y2=\"9\"/><line x1=\"3\" x2=\"21\" y1=\"15\" y2=\"15\"/><line x1=\"9\" x2=\"9\" y1=\"9\" y2=\"21\"/><line x1=\"15\" x2=\"15\" y1=\"9\" y2=\"21\"/>","shield":"<path d=\"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z\"/>","shield-check":"<path d=\"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z\"/><path d=\"m9 12 2 2 4-4\"/>","skull":"<path d=\"m12.5 17-.5-1-.5 1h1z\"/><path d=\"M15 22a1 1 0 0 0 1-1v-1a2 2 0 0 0 1.56-3.25 8 8 0 1 0-11.12 0A2 2 0 0 0 8 20v1a1 1 0 0 0 1 1z\"/><circle cx=\"15\" cy=\"12\" r=\"1\"/><circle cx=\"9\" cy=\"12\" r=\"1\"/>","sparkles":"<path d=\"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z\"/><path d=\"M20 2v4\"/><path d=\"M22 4h-4\"/><circle cx=\"4\" cy=\"20\" r=\"2\"/>","square-pen":"<path d=\"M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7\"/><path d=\"M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z\"/>","star":"<path d=\"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z\"/>","sun":"<circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M12 2v2\"/><path d=\"M12 20v2\"/><path d=\"m4.93 4.93 1.41 1.41\"/><path d=\"m17.66 17.66 1.41 1.41\"/><path d=\"M2 12h2\"/><path d=\"M20 12h2\"/><path d=\"m6.34 17.66-1.41 1.41\"/><path d=\"m19.07 4.93-1.41 1.41\"/>","sun-moon":"<path d=\"M12 2v2\"/><path d=\"M14.837 16.385a6 6 0 1 1-7.223-7.222c.624-.147.97.66.715 1.248a4 4 0 0 0 5.26 5.259c.589-.255 1.396.09 1.248.715\"/><path d=\"M16 12a4 4 0 0 0-4-4\"/><path d=\"m19 5-1.256 1.256\"/><path d=\"M20 12h2\"/>","swords":"<path d=\"m13 19 6-6\"/><path d=\"M14.5 17.5 3.586 6.586A2 2 0 013 5.172V3h2.172a2 2 0 011.414.586L17.5 14.5\"/><path d=\"m14.828 6.172 2.586-2.586A2 2 0 0118.828 3H21v2.172a2 2 0 01-.586 1.414l-2.586 2.586\"/><path d=\"m16 16 4 4\"/><path d=\"m19 21 2-2\"/><path d=\"m5 14 4 4\"/><path d=\"m5 21-2-2\"/><path d=\"M7.5 16.5 4 20\"/>","tag":"<path d=\"M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z\"/><circle cx=\"7.5\" cy=\"7.5\" r=\".5\" fill=\"currentColor\"/>","text":"<path d=\"M21 5H3\"/><path d=\"M15 12H3\"/><path d=\"M17 19H3\"/>","trash":"<path d=\"M10 11v6\"/><path d=\"M14 11v6\"/><path d=\"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6\"/><path d=\"M3 6h18\"/><path d=\"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2\"/>","trash-2":"<path d=\"M10 11v6\"/><path d=\"M14 11v6\"/><path d=\"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6\"/><path d=\"M3 6h18\"/><path d=\"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2\"/>","triangle-alert":"<path d=\"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3\"/><path d=\"M12 9v4\"/><path d=\"M12 17h.01\"/>","tv":"<path d=\"m17 2-5 5-5-5\"/><rect width=\"20\" height=\"15\" x=\"2\" y=\"7\" rx=\"2\"/>","type":"<path d=\"M12 4v16\"/><path d=\"M4 7V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2\"/><path d=\"M9 20h6\"/>","undo":"<path d=\"M3 7v6h6\"/><path d=\"M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13\"/>","undo-2":"<path d=\"M9 14 4 9l5-5\"/><path d=\"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11\"/>","upload":"<path d=\"M12 3v12\"/><path d=\"m17 8-5-5-5 5\"/><path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\"/>","user":"<path d=\"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2\"/><circle cx=\"12\" cy=\"7\" r=\"4\"/>","user-plus":"<path d=\"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2\"/><circle cx=\"9\" cy=\"7\" r=\"4\"/><line x1=\"19\" x2=\"19\" y1=\"8\" y2=\"14\"/><line x1=\"22\" x2=\"16\" y1=\"11\" y2=\"11\"/>","users":"<path d=\"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2\"/><path d=\"M16 3.128a4 4 0 0 1 0 7.744\"/><path d=\"M22 21v-2a4 4 0 0 0-3-3.87\"/><circle cx=\"9\" cy=\"7\" r=\"4\"/>","vote":"<path d=\"m9 12 2 2 4-4\"/><path d=\"M5 7c0-1.1.9-2 2-2h10a2 2 0 0 1 2 2v12H5V7Z\"/><path d=\"M22 19H2\"/>","waves":"<path d=\"M2 12q2.5 2 5 0t5 0 5 0 5 0\"/><path d=\"M2 19q2.5 2 5 0t5 0 5 0 5 0\"/><path d=\"M2 5q2.5 2 5 0t5 0 5 0 5 0\"/>","wifi-off":"<path d=\"M12 20h.01\"/><path d=\"M8.5 16.429a5 5 0 0 1 7 0\"/><path d=\"M5 12.859a10 10 0 0 1 5.17-2.69\"/><path d=\"M19 12.859a10 10 0 0 0-2.007-1.523\"/><path d=\"M2 8.82a15 15 0 0 1 4.177-2.643\"/><path d=\"M22 8.82a15 15 0 0 0-11.288-3.764\"/><path d=\"m2 2 20 20\"/>","x":"<path d=\"M18 6 6 18\"/><path d=\"m6 6 12 12\"/>","zap":"<path d=\"M15.914 4a1.5 1.5 0 00-2.474-1.561l-9 9A1.5 1.5 0 005.5 14h4.002a.5.5 0 01.471.666L8.086 20a1.5 1.5 0 002.475 1.56l9-9A1.5 1.5 0 0018.5 10h-3.997a.5.5 0 01-.472-.667z\"/>"};
const ICON_ALIAS = {home:'house',chat:'message-square',comment:'message-circle',back:'chevron-left',chevR:'chevron-right',up:'chevron-up',down:'chevron-down',more:'ellipsis',share:'share-2',eyeOff:'eye-off',book:'book-open',pen:'pen-line',edit:'square-pen',gear:'settings',trash:'trash-2',filter:'funnel',logout:'log-out',at:'at-sign',refresh:'refresh-cw',undo:'undo-2',arrowUp:'arrow-up',file:'file-text',userPlus:'user-plus'};
function icon(name, extra=''){
  const n=ICON_ALIAS[name]||name;
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ${extra} aria-hidden="true">${ICONS[n]||''}</svg>`;
}

/* ---------- utilidades aleatorias deterministas ---------- */
function hashStr(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function rng(seed){let a=typeof seed==='number'?seed:hashStr(String(seed));return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const PALETTES=[
  ['#1f3d4a','#0b1720','#f5b942','#e04848'],['#3b1d4a','#120a1d','#ff8a5c','#ffd36e'],
  ['#0f3b3a','#061716','#7fe0c2','#f5b942'],['#4a1d1d','#160909','#ffb347','#ffe9b0'],
  ['#1d2a4a','#090f1d','#8ab4ff','#ff7aa8'],['#2d4a1d','#0c1608','#d8f07a','#ffcf5c'],
  ['#4a3b1d','#1a1208','#ffd27a','#e04848'],['#1d4a44','#08201d','#ffd166','#ef476f'],
  ['#3a1d4a','#140820','#c39bff','#5ce1e6'],['#4a1d35','#1d0914','#ff9ecd','#ffd36e']
];
function escXml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function wrapWords(text,maxChars,maxLines){
  const words=String(text).split(/\s+/);const lines=[];let cur='';
  for(const w of words){ if((cur+' '+w).trim().length>maxChars && cur){lines.push(cur);cur=w}else cur=(cur+' '+w).trim() }
  if(cur)lines.push(cur);
  if(lines.length>maxLines){const l=lines.slice(0,maxLines);l[maxLines-1]=l[maxLines-1].replace(/.{0,2}$/,'…');return l}
  return lines;
}
let _uid=0; function uid(p='g'){return p+(++_uid)+Math.floor(Math.random()*1e5)}

/* ---------- portadas ---------- */
function coverSVG(work){
  const r=rng(work.coverSeed||work.id);
  const p=PALETTES[Math.floor(r()*PALETTES.length)];
  const id=uid('c'); const motif=work.motif||['moon','city','sun','waves','forest','orbit'][Math.floor(r()*6)];
  let art='';
  if(motif==='moon'||motif==='forest'){
    art+=`<circle cx="${130+r()*30}" cy="${70+r()*30}" r="${26+r()*12}" fill="${p[2]}" opacity=".95"/>`;
    for(let i=0;i<30;i++)art+=`<circle cx="${r()*200}" cy="${r()*170}" r="${r()*1.4+.3}" fill="#fff" opacity="${r()*.8+.2}"/>`;
    let d='M0 230';for(let x=0;x<=200;x+=20)d+=` L${x} ${170+r()*50}`;d+=' L200 300 L0 300Z';
    art+=`<path d="${d}" fill="${p[1]}" opacity=".85"/>`;
    if(motif==='forest'){for(let i=0;i<14;i++){const x=r()*200,h=40+r()*50,b=250-r()*20;art+=`<path d="M${x} ${b-h} L${x-12} ${b} L${x+12} ${b}Z" fill="${p[1]}"/>`}}
    let d2='M0 260';for(let x=0;x<=200;x+=25)d2+=` L${x} ${215+r()*40}`;d2+=' L200 300 L0 300Z';
    art+=`<path d="${d2}" fill="#000" opacity=".45"/>`;
  }else if(motif==='city'){
    art+=`<circle cx="60" cy="80" r="34" fill="${p[3]}" opacity=".8"/>`;
    for(let i=0;i<12;i++){const w=14+r()*20,x=i*17-6,h=60+r()*120;art+=`<rect x="${x}" y="${260-h}" width="${w}" height="${h}" fill="${p[1]}" opacity="${.7+r()*.3}"/>`;
      for(let k=0;k<6;k++)if(r()>.5)art+=`<rect x="${x+3+r()*(w-6)}" y="${260-h+8+r()*(h-16)}" width="2.5" height="3.5" fill="${p[2]}" opacity=".9"/>`}
    art+=`<rect y="255" width="200" height="45" fill="#000" opacity=".55"/>`;
  }else if(motif==='sun'){
    for(let i=0;i<18;i++){const a=i/18*Math.PI*2;art+=`<path d="M100 120 L${100+Math.cos(a)*260} ${120+Math.sin(a)*260} L${100+Math.cos(a+.12)*260} ${120+Math.sin(a+.12)*260}Z" fill="${p[2]}" opacity=".18"/>`}
    art+=`<circle cx="100" cy="120" r="44" fill="${p[2]}"/><circle cx="100" cy="120" r="30" fill="${p[3]}" opacity=".85"/>`;
  }else if(motif==='waves'){
    for(let i=0;i<7;i++){const y=110+i*24;art+=`<path d="M0 ${y} Q50 ${y-18-r()*10} 100 ${y} T200 ${y} V300 H0Z" fill="${i%2?p[1]:p[0]}" opacity="${.5+i*.07}"/>`}
    art+=`<circle cx="150" cy="70" r="20" fill="${p[2]}"/>`;
  }else{
    art+=`<circle cx="100" cy="125" r="40" fill="${p[2]}"/>`;
    for(let i=0;i<3;i++)art+=`<ellipse cx="100" cy="125" rx="${70+i*18}" ry="${18+i*6}" fill="none" stroke="${p[3]}" stroke-width="1.6" opacity="${.8-i*.2}" transform="rotate(${-18+i*6} 100 125)"/>`;
    for(let i=0;i<40;i++)art+=`<circle cx="${r()*200}" cy="${r()*300}" r="${r()*1.2+.3}" fill="#fff" opacity="${r()}"/>`;
  }
  const lines=wrapWords((work.title||'').toUpperCase(),13,3);
  const fs=lines.some(l=>l.length>10)?19:23; const y0=300-26-lines.length*(fs+1)-14;
  const title=lines.map((l,i)=>`<text x="14" y="${y0+i*(fs+1)}" font-family="Barlow Condensed,Arial Narrow,sans-serif" font-weight="900" font-size="${fs}" fill="#fff" letter-spacing="1">${escXml(l)}</text>`).join('');
  return `<svg viewBox="0 0 200 300" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${p[0]}"/><stop offset="1" stop-color="${p[1]}"/></linearGradient><linearGradient id="${id}s" x1="0" y1="0" x2="0" y2="1"><stop offset=".45" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".75"/></linearGradient></defs><rect width="200" height="300" fill="url(#${id})"/>${art}<rect width="200" height="300" fill="url(#${id}s)"/>${title}<rect x="14" y="${300-30}" width="26" height="3" fill="${p[2]}"/><text x="14" y="${300-14}" font-family="Rajdhani,sans-serif" font-weight="700" font-size="11" fill="#fff" opacity=".85">${escXml(work.authorName||'')}</text></svg>`;
}

/* ---------- avatar con iniciales ---------- */
function initialsAvatar(name,seed){
  const r=rng(seed||name); const p=PALETTES[Math.floor(r()*PALETTES.length)]; const id=uid('a');
  const ini=String(name||'?').split(/\s+/).filter(Boolean).slice(0,2).map(w=>w[0]).join('').toUpperCase();
  return `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${p[3]}"/><stop offset="1" stop-color="${p[0]}"/></linearGradient></defs><rect width="100" height="100" fill="url(#${id})"/><circle cx="${20+r()*60}" cy="${10+r()*30}" r="${18+r()*14}" fill="#fff" opacity=".12"/><text x="50" y="50" dy=".35em" text-anchor="middle" font-family="Barlow Condensed,Arial Narrow,sans-serif" font-weight="900" font-size="42" fill="#fff">${escXml(ini)}</text></svg>`;
}
function bannerSVG(seed){
  const r=rng(seed+'b'); const p=PALETTES[Math.floor(r()*PALETTES.length)]; const id=uid('b');
  let s='';for(let i=0;i<6;i++)s+=`<circle cx="${r()*400}" cy="${r()*120}" r="${20+r()*70}" fill="${i%2?p[2]:p[3]}" opacity="${.12+r()*.18}"/>`;
  for(let i=0;i<25;i++)s+=`<circle cx="${r()*400}" cy="${r()*120}" r="${r()*1.3+.3}" fill="#fff" opacity="${r()}"/>`;
  return `<svg viewBox="0 0 400 120" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${p[0]}"/><stop offset="1" stop-color="${p[1]}"/></linearGradient></defs><rect width="400" height="120" fill="url(#${id})"/>${s}</svg>`;
}

/* ---------- ilustración grande generada ---------- */
function illustrationSVG(seed,title){
  const r=rng(seed); const p=PALETTES[Math.floor(r()*PALETTES.length)]; const id=uid('i');
  let s='';
  for(let i=0;i<60;i++)s+=`<circle cx="${r()*800}" cy="${r()*350}" r="${r()*1.8+.3}" fill="#fff" opacity="${r()}"/>`;
  s+=`<circle cx="${560+r()*80}" cy="${130+r()*40}" r="${70+r()*30}" fill="${p[2]}" opacity=".9"/>`;
  for(let l=0;l<4;l++){let d=`M0 ${330+l*50}`;for(let x=0;x<=800;x+=40)d+=` L${x} ${300+l*55-r()*90}`;d+=' L800 600 L0 600Z';s+=`<path d="${d}" fill="${l===3?'#000':p[1]}" opacity="${.45+l*.15}"/>`}
  // guardianes (siluetas)
  for(let g=0;g<3;g++){const x=230+g*150+r()*30,y=470-g*8,h=120+r()*40;
    s+=`<g transform="translate(${x} ${y})" fill="#05080b"><path d="M-22 0 L-16 ${-h*.62} Q0 ${-h*.72} 16 ${-h*.62} L22 0Z"/><circle cx="0" cy="${-h*.75}" r="${h*.11}"/><path d="M${-h*.13} ${-h*.82} L${-h*.2} ${-h*1.02} L${-h*.04} ${-h*.86}Z M${h*.13} ${-h*.82} L${h*.2} ${-h*1.02} L${h*.04} ${-h*.86}Z"/><rect x="26" y="${-h*.95}" width="4" height="${h*.95}" transform="rotate(8)"/></g>`}
  s+=`<rect width="800" height="600" fill="url(#${id}v)"/>`;
  return `<svg viewBox="0 0 800 600" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${p[0]}"/><stop offset="1" stop-color="${p[3]}"/></linearGradient><radialGradient id="${id}v" cx=".5" cy=".5" r=".75"><stop offset=".6" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".55"/></radialGradient></defs><rect width="800" height="600" fill="url(#${id})"/>${s}</svg>`;
}

/* ---------- páginas de manga / cómic generadas ---------- */
const PANEL_LAYOUTS=[
  [[20,20,560,300],[20,340,270,260],[310,340,270,260],[20,620,560,260]],
  [[20,20,270,420],[310,20,270,200],[310,240,270,200],[20,460,560,420]],
  [[20,20,560,260],[20,300,560,280],[20,600,270,280],[310,600,270,280]],
];
function sceneSVG(scene,x,y,w,h,r,color){
  const ink='#111'; let s='';
  const c=color?PALETTES[Math.floor(r()*PALETTES.length)]:['#e8e8e8','#bdbdbd','#777','#333'];
  const bg=color?c[0]:'#f4f4f4';
  s+=`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${bg}"/>`;
  if(scene==='city'){
    s+=`<circle cx="${x+w*.75}" cy="${y+h*.25}" r="${Math.min(w,h)*.12}" fill="${color?c[2]:'#fff'}" stroke="${ink}" stroke-width="2"/>`;
    for(let i=0;i<10;i++){const bw=w/10+r()*15,bx=x+i*w/10,bh=h*(.3+r()*.5);s+=`<rect x="${bx}" y="${y+h-bh}" width="${bw}" height="${bh}" fill="${color?c[1]:c[2+(i%2)]}" stroke="${ink}" stroke-width="2"/>`;
      for(let k=0;k<4;k++)s+=`<rect x="${bx+5+r()*(bw-12)}" y="${y+h-bh+8+r()*(bh-20)}" width="5" height="7" fill="${color?c[2]:'#fff'}"/>`}
  }else if(scene==='face'||scene==='face2'){
    const cx=x+w/2,cy=y+h*.58,R=Math.min(w,h)*.3;
    for(let i=0;i<14;i++){const a=r()*Math.PI*2;s+=`<line x1="${cx}" y1="${cy}" x2="${cx+Math.cos(a)*w}" y2="${cy+Math.sin(a)*h}" stroke="${color?c[2]:'#ccc'}" stroke-width="${1+r()*3}" opacity=".6"/>`}
    s+=`<path d="M${cx-R*1.1} ${cy+R*1.6} Q${cx} ${cy+R*.7} ${cx+R*1.1} ${cy+R*1.6}Z" fill="${color?c[3]:'#555'}" stroke="${ink}" stroke-width="2.5"/>`;
    s+=`<ellipse cx="${cx}" cy="${cy}" rx="${R*.8}" ry="${R}" fill="${color?'#ffe0c2':'#fff'}" stroke="${ink}" stroke-width="3"/>`;
    let hair=`M${cx-R*.95} ${cy-R*.2}`;for(let i=0;i<=8;i++){hair+=` L${cx-R*.95+i*R*1.9/8} ${cy-R*(i%2?1.55:1.05)}`}hair+=` L${cx+R*.95} ${cy-R*.2} Q${cx} ${cy-R*.75} ${cx-R*.95} ${cy-R*.2}Z`;
    s+=`<path d="${hair}" fill="${color?c[1]:'#222'}" stroke="${ink}" stroke-width="2.5"/>`;
    const ey=cy-R*.05, angry=scene==='face2';
    s+=`<ellipse cx="${cx-R*.32}" cy="${ey}" rx="${R*.14}" ry="${R*.2}" fill="${ink}"/><ellipse cx="${cx+R*.32}" cy="${ey}" rx="${R*.14}" ry="${R*.2}" fill="${ink}"/><circle cx="${cx-R*.28}" cy="${ey-R*.07}" r="${R*.05}" fill="#fff"/><circle cx="${cx+R*.36}" cy="${ey-R*.07}" r="${R*.05}" fill="#fff"/>`;
    s+=angry?`<path d="M${cx-R*.5} ${ey-R*.35} L${cx-R*.15} ${ey-R*.22} M${cx+R*.5} ${ey-R*.35} L${cx+R*.15} ${ey-R*.22}" stroke="${ink}" stroke-width="4"/><path d="M${cx-R*.2} ${cy+R*.5} L${cx+R*.2} ${cy+R*.5}" stroke="${ink}" stroke-width="3"/>`
      :`<path d="M${cx-R*.22} ${cy+R*.45} Q${cx} ${cy+R*.62} ${cx+R*.22} ${cy+R*.45}" stroke="${ink}" stroke-width="3" fill="none"/>`;
  }else if(scene==='action'){
    for(let i=0;i<40;i++){const a=i/40*Math.PI*2,len=Math.max(w,h);s+=`<path d="M${x+w/2+Math.cos(a)*30} ${y+h/2+Math.sin(a)*30} L${x+w/2+Math.cos(a)*len} ${y+h/2+Math.sin(a)*len} L${x+w/2+Math.cos(a+.05)*len} ${y+h/2+Math.sin(a+.05)*len}Z" fill="${color?c[3]:ink}" opacity="${.5+r()*.5}"/>`}
    s+=`<path d="M${x+w*.2} ${y+h*.8} L${x+w*.82} ${y+h*.2}" stroke="${color?c[2]:'#fff'}" stroke-width="10" stroke-linecap="round"/><path d="M${x+w*.2} ${y+h*.8} L${x+w*.82} ${y+h*.2}" stroke="${ink}" stroke-width="3"/>`;
  }else if(scene==='rain'){
    s+=`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${color?c[1]:'#9a9a9a'}"/>`;
    for(let i=0;i<70;i++){const rx=x+r()*w,ry=y+r()*h;s+=`<line x1="${rx}" y1="${ry}" x2="${rx-10}" y2="${ry+28}" stroke="#fff" stroke-width="1.5" opacity=".7"/>`}
    s+=`<path d="M${x+w*.45} ${y+h} L${x+w*.45} ${y+h*.45} M${x+w*.3} ${y+h*.5} Q${x+w*.45} ${y+h*.25} ${x+w*.6} ${y+h*.5}Z" stroke="${ink}" stroke-width="4" fill="${color?c[3]:'#333'}"/>`;
  }else if(scene==='cafe'){
    s+=`<rect x="${x}" y="${y+h*.7}" width="${w}" height="${h*.3}" fill="${color?c[1]:'#ccc'}"/>`;
    const cx=x+w/2,cy=y+h*.62;
    s+=`<path d="M${cx-50} ${cy-40} L${cx+50} ${cy-40} L${cx+40} ${cy+40} L${cx-40} ${cy+40}Z" fill="${color?c[2]:'#fff'}" stroke="${ink}" stroke-width="3"/><path d="M${cx+48} ${cy-25} q30 10 0 40" stroke="${ink}" stroke-width="3" fill="none"/>`;
    for(let i=0;i<3;i++)s+=`<path d="M${cx-20+i*20} ${cy-50} q-10 -20 0 -40 q10 -20 0 -40" stroke="${color?'#fff':'#888'}" stroke-width="3" fill="none" opacity=".8"/>`;
    for(let i=0;i<20;i++)s+=`<circle cx="${x+r()*w}" cy="${y+r()*h*.5}" r="${r()*2+.5}" fill="${color?'#fff':'#999'}"/>`;
  }else{ // space / mountain
    s+=`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${color?c[1]:'#2a2a2a'}"/>`;
    for(let i=0;i<50;i++)s+=`<circle cx="${x+r()*w}" cy="${y+r()*h}" r="${r()*2}" fill="#fff"/>`;
    s+=`<circle cx="${x+w*.3}" cy="${y+h*.4}" r="${Math.min(w,h)*.22}" fill="${color?c[2]:'#ddd'}" stroke="${ink}" stroke-width="3"/>`;
    let d=`M${x} ${y+h}`;for(let i=0;i<=8;i++)d+=` L${x+i*w/8} ${y+h*(.65+r()*.25)}`;d+=` L${x+w} ${y+h}Z`;s+=`<path d="${d}" fill="${ink}"/>`;
  }
  return s;
}
function bubbleSVG(text,x,y,w,h,r,shout){
  if(!text)return '';
  const lines=wrapWords(text,shout?12:20,4); const lh=shout?30:22, fs=shout?26:18;
  const bw=Math.min(w-30,Math.max(...lines.map(l=>l.length))*(shout?15:10)+36), bh=lines.length*lh+26;
  const bx=x+(r()>.5?14:w-bw-14), by=y+12;
  let shape;
  if(shout){let d='';const n=16;for(let i=0;i<n;i++){const a=i/n*Math.PI*2,rr=i%2?1:1.18;d+=(i?'L':'M')+(bx+bw/2+Math.cos(a)*bw/2*rr)+' '+(by+bh/2+Math.sin(a)*bh/2*rr)}shape=`<path d="${d}Z" fill="#fff" stroke="#111" stroke-width="3"/>`}
  else shape=`<ellipse cx="${bx+bw/2}" cy="${by+bh/2}" rx="${bw/2+6}" ry="${bh/2+4}" fill="#fff" stroke="#111" stroke-width="2.5"/><path d="M${bx+bw*.45} ${by+bh} L${bx+bw*.38} ${by+bh+22} L${bx+bw*.6} ${by+bh-2}" fill="#fff" stroke="#111" stroke-width="2.5"/><rect x="${bx+bw*.43}" y="${by+bh-6}" width="${bw*.17}" height="7" fill="#fff"/>`;
  const t=lines.map((l,i)=>`<text x="${bx+bw/2}" y="${by+20+lh*.6+i*lh}" text-anchor="middle" font-family="Barlow Condensed,Arial Narrow,sans-serif" font-weight="${shout?900:700}" font-size="${fs}" fill="#111">${escXml(l)}</text>`).join('');
  return shape+t;
}
function pageSVG(page,seed,color){
  const r=rng(seed); const layout=PANEL_LAYOUTS[page.layout%PANEL_LAYOUTS.length]; let s='';const clips=[];
  layout.forEach((b,i)=>{const pn=page.panels[i]; if(!pn)return; const cid=uid('p');
    clips.push(`<clipPath id="${cid}"><rect x="${b[0]}" y="${b[1]}" width="${b[2]}" height="${b[3]}"/></clipPath>`);
    s+=`<g clip-path="url(#${cid})">${sceneSVG(pn.scene,b[0],b[1],b[2],b[3],r,color)}${bubbleSVG(pn.text,b[0],b[1],b[2],b[3],r,pn.shout)}</g><rect x="${b[0]}" y="${b[1]}" width="${b[2]}" height="${b[3]}" fill="none" stroke="#111" stroke-width="5"/>`;
  });
  return `<svg viewBox="0 0 600 900" xmlns="http://www.w3.org/2000/svg"><defs>${clips.join('')}</defs><rect width="600" height="900" fill="#fff"/>${s}<text x="580" y="893" text-anchor="end" font-family="Rajdhani,sans-serif" font-size="12" fill="#999">CHOGGUN</text></svg>`;
}

/* ================= Catálogos de CHOGGUN (sin contenido de ejemplo) ================= */
const FORMATS = {
  novela:     {label:'Novela',      icon:'book-open-text', cls:''},
  relato:     {label:'Relato',      icon:'feather',        cls:'green'},
  manga:      {label:'Manga',       icon:'swords',         cls:'red'},
  comic:      {label:'Cómic',       icon:'book-image',     cls:'purple'},
  ilustracion:{label:'Ilustración', icon:'palette',        cls:'blue'},
  video:      {label:'Video',       icon:'clapperboard',   cls:'red'},
  foro:       {label:'Foro',        icon:'messages-square',cls:'gray'},
};
const GENRES = ['Fantasía','Ciencia ficción','Terror','Misterio','Romance','Drama','Comedia','Acción','Aventura','Realismo mágico','Slice of life','Histórica','Infantil','Cyberpunk','Épica','Poesía'];
const ROLES = ['Escritor/a','Ilustrador/a','Lector/a'];
const ROLE_ICONS = {'Escritor/a':'pen-tool','Ilustrador/a':'brush','Lector/a':'library'};
const COLLABS = ['Coautoría','Portadas','Ilustrar capítulos','Guion de cómic','Webcomic','Beta reader / Feedback','Traducción'];
const CREDIT_ROLES = ['Coautor/a','Ilustración','Portada','Guion','Color','Edición','Traducción'];
const LICENSES = ['Todos los derechos reservados','CC BY 4.0','CC BY-NC 4.0','CC BY-NC-ND 4.0'];
const REPORT_REASONS = ['Spam o publicidad','Acoso o lenguaje ofensivo','Contenido sexual no etiquetado','Violencia gráfica','Plagio / infracción de derechos de autor','Información falsa','Otro motivo'];
const BAD_WORDS = ['idiota','estupido','imbecil','basura','maldito','maldita','inutil','asqueroso','tarado','tarada','gonorrea','malparido','hpta','mierda','largate','muerete'];
const COMMUNITY_CATS = ['Historias','Visual','Entretenimiento','Otros'];
const COMMUNITY_ICONS = ['book-open-text','feather','pen-tool','swords','book-image','palette','brush','tv','clapperboard','gamepad-2','music','cpu','ghost','rocket','moon-star','castle','skull','flower-2','coffee','lightbulb','crown','mountain','drama','scroll'];
const COMMUNITY_COLORS = ['#f5b942','#e04848','#5ab8e8','#3fb37f','#9b7cf0','#ff8a5c','#ff9ecd','#ffd166'];

/* Fuentes de noticias (RSS públicos en español) */
const NEWS_CATS = {
  gaming:{label:'Gaming', icon:'gamepad-2', color:'#3fb37f'},
  anime: {label:'Anime',  icon:'swords',    color:'#ff9ecd'},
  cine:  {label:'Cine y series', icon:'clapperboard', color:'#5ab8e8'},
};
const NEWS_FEEDS = [
  {id:'vandal',    name:'Vandal',         cat:'gaming', url:'https://vandal.elespanol.com/xml.cgi'},
  {id:'3djuegos',  name:'3DJuegos',       cat:'gaming', url:'https://www.3djuegos.com/feedburner.xml'},
  {id:'ramen',     name:'Ramen Para Dos', cat:'anime',  url:'https://ramenparados.com/feed/'},
  {id:'sensacine', name:'SensaCine',      cat:'cine',   url:'https://www.sensacine.com/rss/noticias-cine.xml'},
  {id:'sensaseries',name:'SensaCine Series',cat:'cine', url:'https://www.sensacine.com/rss/noticias-series.xml'},
  {id:'espinof',   name:'Espinof',        cat:'cine',   url:'https://www.espinof.com/feedburner.xml'},
];

/* Tipografías disponibles en toda la app */
const FONTS = {
  choggun:{label:'CHOGGUN',   body:"'Rajdhani',system-ui,sans-serif",       head:"'Barlow Condensed','Arial Narrow',sans-serif", desc:'Rajdhani + Barlow Condensed'},
  nunito: {label:'Redondeada',body:"'Nunito',system-ui,sans-serif",         head:"'Nunito',system-ui,sans-serif", desc:'Nunito'},
  serif:  {label:'Clásica',   body:"'Merriweather',Georgia,serif",          head:"'Merriweather',Georgia,serif", desc:'Merriweather'},
  manga:  {label:'Manga',     body:"'Nunito',system-ui,sans-serif",         head:"'Bangers','Impact',sans-serif", desc:'Bangers + Nunito'},
  system: {label:'Sistema',   body:"system-ui,-apple-system,'Segoe UI',Roboto,sans-serif", head:"system-ui,-apple-system,'Segoe UI',Roboto,sans-serif", desc:'La fuente de tu teléfono'},
};

const H = 3600e3;

/* ================= CHOGGUN — núcleo ================= */
const ASSETS = { logo:logoImg, avdef:avdefImg, fondo1:fondo1Img, fondo2:fondo2Img, match:matchImg, google:googleImg };
const APP_VERSION='4.0.0';
const KEY = 'choggun_settings_v3';
let S = null;

/* ---------- utilidades ---------- */
const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => [...root.querySelectorAll(sel)];
function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function fmtNum(n){ n=Number(n)||0; if(Math.abs(n)>=1e6) return (n/1e6).toFixed(1).replace('.0','')+' M'; if(Math.abs(n)>=1e3) return (n/1e3).toFixed(1).replace('.0','')+' k'; return String(n); }
function timeAgo(t){
  const s=Math.max(1,Math.floor((Date.now()-t)/1000));
  if(s<60) return 'ahora'; const m=Math.floor(s/60); if(m<60) return `hace ${m} min`;
  const h=Math.floor(m/60); if(h<24) return `hace ${h} h`; const d=Math.floor(h/24); if(d<7) return `hace ${d} d`;
  return new Date(t).toLocaleDateString('es-CO',{day:'numeric',month:'short'});
}
function clock(t){ return new Date(t).toLocaleTimeString('es-CO',{hour:'numeric',minute:'2-digit'}); }
function dayLabel(t){ const d=new Date(t), n=new Date(); const y=new Date(); y.setDate(n.getDate()-1);
  if(d.toDateString()===n.toDateString()) return 'Hoy'; if(d.toDateString()===y.toDateString()) return 'Ayer';
  return d.toLocaleDateString('es-CO',{weekday:'long',day:'numeric',month:'short'}); }
function wordCount(t){ return (String(t||'').trim().match(/\S+/g)||[]).length; }
function normalize(s){ return String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,''); }
function isToxic(text){ const t=' '+normalize(text)+' '; return BAD_WORDS.some(w=>t.includes(normalize(w))); }
const errMsg = e => (e && e.message) || 'Ocurrió un error. Intenta de nuevo.';

/* ---------- estado ----------
 * Los datos (personas, obras, comunidades, mensajes…) vienen de Supabase.
 * En el teléfono solo se guardan los ajustes (tema, fuente, lectura) y la sesión. */
function defaultSettings(){ return {theme:'dark',font:'choggun',cardOpacity:1,readerSize:18,readerTheme:'sepia',notifications:true,mature:false,onboarded:false}; }
function emptyData(){ return { session:null, uid:null, users:{}, byId:{}, works:[], communities:[], following:[],
  joined:{}, saved:{}, history:{}, hidden:{}, myVotes:{}, chats:{}, clears:{}, notifRows:[], reports:[], loaded:false }; }
function load(){
  let settings=defaultSettings();
  try{ const raw=localStorage.getItem(KEY); if(raw) settings={...settings,...JSON.parse(raw)}; }catch(e){}
  S={...emptyData(),settings};
}
let saveTimer=null;
function save(now){
  clearTimeout(saveTimer);
  const doSave=()=>{ try{ localStorage.setItem(KEY,JSON.stringify(S.settings)); }catch(e){} };
  if(now) doSave(); else saveTimer=setTimeout(doSave,150);
}

/* ---------- selectores ---------- */
const me = () => S.session ? S.users[S.session] : null;
const user = u => S.users[u] || {username:u,name:'Usuario eliminado',role:'Lector/a',genres:[],collab:[],followerCount:0,followingCount:0,karma:0,workCount:0};
const work = id => S.works.find(w=>w.id===id);
const community = id => (id && S.communities.find(c=>c.id===id)) || null;
function score(w){ return w.score||0; }
function myVote(w){ return S.session ? S.myVotes[w.id]||0 : 0; }
function commentCount(w){ return w.commentCount||0; }
function chaptersOf(w){ return w.chapters || w.chaptersMeta || []; }
function isSaved(id){ return S.session && (S.saved[S.session]||[]).includes(id); }
function isJoined(cid){ return S.session && (S.joined[S.session]||[]).includes(cid); }
function isFollowing(u){ return !!S.session && S.following.includes(u); }
function followersCount(u){ return user(u).followerCount||0; }
function isHiddenForMe(w){ return w.removed || (S.session && (S.hidden[S.session]||[]).includes(w.id)); }
function visibleWorks(){ return S.works.filter(w=>w.status==='publicado' && !w.removed && (S.settings.mature || !w.mature || w.author===S.session)); }
function hot(w){ const hrs=(Date.now()-w.created)/H; return (score(w)+commentCount(w)*3+(w.views||0)/60)/Math.pow(hrs+2,1.15); }
function myNotifs(){ return S.session ? S.notifRows.map(notifView) : []; }
function unreadNotifs(){ return S.session ? S.notifRows.filter(n=>!n.read).length : 0; }
function chatId(other){ return [S.session,other].sort().join('__'); }
function chatOther(c){ return (c.members||[]).find(m=>m!==S.session); }
function myChats(){ const m=S.session; if(!m) return []; return Object.entries(S.chats).filter(([k,c])=>(c.members||[]).includes(m)).map(([k,c])=>({id:k,...c,with:chatOther(c),unreadMe:!!(c.unread||{})[m]})).sort((a,b)=>(b.msgs.at(-1)?.t||0)-(a.msgs.at(-1)?.t||0)); }
function unreadChats(){ return myChats().filter(c=>c.unreadMe).length; }
function ensureChat(other){ const id=chatId(other); if(!S.chats[id]) S.chats[id]={members:[S.session,other],msgs:[],unread:{}}; return S.chats[id]; }
function karmaOf(u){ return user(u).karma||0; }

/* ---------- avisos (los crea la base de datos; aquí solo se muestran) ---------- */
function notifView(r){
  const who=r.actor?`<b>${esc(r.actor.name||r.actor.username)}</b>`:'Alguien';
  const title=r.work?`“${esc(r.work.title)}”`:'tu obra';
  const extra=esc(r.extra||'');
  const base={id:r.id,t:new Date(r.created_at).getTime(),read:r.read};
  const wl=r.work_id?{s:'work',id:r.work_id}:null;
  switch(r.type){
    case 'vote': return {...base,type:'vote',text:`${who} votó tu obra ${title}`,link:wl};
    case 'comment': return {...base,type:'comment',text:`${who} comentó ${title}: “${extra}”`,link:wl&&{...wl,focus:'comments'}};
    case 'reply': return {...base,type:'comment',text:`${who} respondió tu comentario: “${extra}”`,link:wl&&{...wl,focus:'comments'}};
    case 'comment_like': return {...base,type:'vote',text:`A ${who} le gustó tu comentario en ${title}`,link:wl&&{...wl,focus:'comments'}};
    case 'follow': return {...base,type:'follow',text:`${who} empezó a seguirte`,link:r.actor?{s:'user',u:r.actor.username}:null};
    case 'credit': return {...base,type:'system',text:`${who} te dio crédito como ${extra} en ${title}`,link:wl};
    case 'message': return {...base,type:'match',text:`${who} te envió un mensaje`,link:r.actor?{s:'chat',id:r.actor.username}:null};
    case 'match': return {...base,type:'match',text:`<b>¡Nuevo match!</b> Tú y ${who} quieren colaborar. ¡Escríbele!`,link:r.actor?{s:'chat',id:r.actor.username}:{s:'matches'}};
    case 'mod_work': return {...base,type:'mod',text:`Moderación retiró ${title} por: ${extra}`,link:null};
    case 'mod_report': return {...base,type:'mod',text:`Tu reporte fue revisado: <b>${r.extra==='retirado'?'contenido retirado':'sin infracción'}</b>. ¡Gracias!`,link:{s:'reports',mode:'mine'}};
    default: return {...base,type:'system',text:`<b>Bienvenido/a a CHOGGUN.</b> Completa tu perfil para que otros creadores te conozcan.`,link:{s:'editProfile'}};
  }
}

/* ---------- componentes ---------- */
function avatarHTML(u, cls=''){
  const x=typeof u==='string'?user(u):u;
  return `<img class="avatar ${cls}" src="${x.avatar||ASSETS.avdef}" alt="" loading="lazy">`;
}
function coverHTML(w){
  if(w.cover) return `<img src="${w.cover}" alt="">`;
  if(w.type==='ilustracion') return artHTML(w);
  return coverSVG({...w, authorName:user(w.author).name});
}
function videoThumbHTML(w){
  const p=w.video&&w.video.poster;
  return `${p?`<img src="${p}" alt="" loading="lazy">`:illustrationSVG(w.id,w.title)}<span class="play-badge">${icon('clapperboard')}</span>`;
}
function artHTML(w){
  if(w.image && w.image.data) return `<img src="${w.image.data}" alt="${esc(w.title)}" loading="lazy">`;
  return illustrationSVG((w.image&&w.image.gen)||w.id, w.title);
}
function fmtTag(type){ const f=FORMATS[type]||FORMATS.foro; return `<span class="tag ${f.cls}">${icon(f.icon,'width="12" height="12"')} ${f.label}</span>`; }
function fmtLabel(type){ const f=FORMATS[type]||FORMATS.foro; return `<span class="row" style="gap:8px;display:inline-flex">${icon(f.icon,'width="20" height="20"')}${f.label}</span>`; }
function nameHTML(u){ return esc(user(u).name); }
function voteHTML(w){
  const v=myVote(w);
  return `<div class="vote ${v>0?'up':v<0?'down':''}"><button class="v-up" data-a="vote" data-id="${w.id}" data-dir="1" aria-label="Votar a favor">${icon('up','stroke-width="2.8"')}</button><b>${fmtNum(score(w))}</b><button class="v-down" data-a="vote" data-id="${w.id}" data-dir="-1" aria-label="Votar en contra">${icon('down','stroke-width="2.8"')}</button></div>`;
}
function topbar({title='',back=true,actions='',brand=false}={}){
  return `<header class="topbar">${back?`<button class="icon-btn" data-a="back" aria-label="Atrás">${icon('back')}</button>`:''}${brand?`<div class="brand"><img src="${ASSETS.logo}" alt=""><span>CHOGGUN</span></div>`:`<div class="title">${title}</div>`}${actions}</header>`;
}
function emptyHTML(ic,title,text,btn=''){ return `<div class="empty">${icon(ic,'class="empty-ic"')}<div class="h3">${title}</div><div class="small">${text}</div>${btn}</div>`; }

function postCard(w){
  if(isHiddenForMe(w)) return `<div class="card post hidden-post">${icon('eyeOff','width="20" height="20"')}<span class="grow">${w.removed?'Contenido retirado por moderación.':'Ocultaste esta publicación.'}</span>${w.removed?'':`<button class="link small" data-a="unhide" data-id="${w.id}">Mostrar</button>`}</div>`;
  const a=user(w.author); const c=community(w.community);
  let body='';
  if(w.type==='foro'){
    body=`<div class="post-wide" data-a="open" data-id="${w.id}">${fmtTag('foro')}<div class="h3" style="margin:7px 0 4px">${esc(w.title)}</div><p class="muted clamp3" style="font-size:14.5px">${esc(w.synopsis)}</p></div>`;
  }else if(w.type==='video'){
    body=`<div class="post-wide" data-a="open" data-id="${w.id}"><div class="art video-thumb">${videoThumbHTML(w)}</div><div class="row" style="margin-top:9px">${fmtTag('video')}${w.mature?'<span class="tag red">+18</span>':''}</div><div class="h3" style="margin:6px 0 2px">${esc(w.title)}</div><p class="muted clamp2" style="font-size:14.5px">${esc(w.synopsis)}</p></div>`;
  }else if(w.type==='ilustracion'){
    body=`<div class="post-wide" data-a="open" data-id="${w.id}"><div class="art">${artHTML(w)}</div><div class="row" style="margin-top:9px">${fmtTag('ilustracion')}${w.mature?'<span class="tag red">+18</span>':''}</div><div class="h3" style="margin:6px 0 2px">${esc(w.title)}</div><p class="muted clamp2" style="font-size:14.5px">${esc(w.synopsis)}</p></div>`;
  }else{
    const nch=chaptersOf(w).length;
    body=`<div class="post-cover" data-a="open" data-id="${w.id}"><div class="cover">${coverHTML(w)}</div><div class="post-body"><div class="row wrap" style="gap:6px">${fmtTag(w.type)}${w.mature?'<span class="tag red">+18</span>':''}</div><div class="h3">${esc(w.title)}</div><p class="clamp3">${esc(w.synopsis)}</p><div class="tiny faint" style="margin-top:6px">${(w.genres||[]).slice(0,3).map(esc).join(' · ')}</div><div class="tiny muted" style="margin-top:3px">${icon('book','width="12" height="12" style="display:inline;vertical-align:-1px"')} ${nch} ${nch===1?'capítulo':'capítulos'} · ${fmtNum(w.views)} lecturas</div></div></div>`;
  }
  const credits=(w.credits||[]).length?`<div class="av-stack" title="Colaboradores">${[w.author,...w.credits.map(c=>c.user)].slice(0,3).map(u=>avatarHTML(u,'av-xs')).join('')}</div>`:'';
  return `<article class="card post">
    <div class="post-head">${avatarHTML(a,'av-sm')}<div class="who" data-a="user" data-u="${a.username}"><b>${nameHTML(a.username)}</b><div>${c?`en <span class="gold" data-a="comm" data-id="${c.id}">c/${esc(c.id)}</span> · `:''}${timeAgo(w.created)}</div></div><button class="icon-btn" data-a="postMenu" data-id="${w.id}" aria-label="Más opciones">${icon('more')}</button></div>
    ${body}
    <div class="post-actions">${voteHTML(w)}<button class="pa" data-a="open" data-id="${w.id}" data-focus="comments">${icon('comment')}${fmtNum(commentCount(w))}</button><button class="pa ${isSaved(w.id)?'on':''}" data-a="save" data-id="${w.id}" aria-label="Guardar">${icon('bookmark',isSaved(w.id)?'fill="currentColor"':'')}</button><button class="pa" data-a="share" data-id="${w.id}" aria-label="Compartir">${icon('share')}</button><span class="spacer"></span>${credits}</div>
  </article>`;
}

/* ---------- navegación ---------- */
let stack=[{name:'home',params:{}}];
let navAnim=true;
const SCREENS={};
const TAB_SCREENS=['home','explore','match','profile'];
function current(){ return stack[stack.length-1]; }
function saveScroll(){ const sc=$('#view .scroll'); if(sc) current().scroll=sc.scrollTop; }
function go(name,params={}){ closeOverlay(true); saveScroll(); stack.push({name,params}); navAnim=true; render(); }
function replace(name,params={}){ closeOverlay(true); stack[stack.length-1]={name,params}; navAnim=true; render(); }
function setTab(name){ closeOverlay(true); if(current().name===name && stack.length===1){ const sc=$('#view .scroll'); if(sc) sc.scrollTo({top:0,behavior:'smooth'}); return; } stack=[{name,params:{}}]; navAnim=false; render(); }
function back(){
  if(overlayOpen()){ closeOverlay(); return true; }
  if(stack.length>1){ stack.pop(); navAnim=false; render(); return true; }
  if(current().name!=='home' && TAB_SCREENS.includes(current().name)){ setTab('home'); return true; }
  return false;
}
function refresh(){ saveScroll(); navAnim=false; render(); }

function render(){
  const cur=current(); const scr=SCREENS[cur.name]; if(!scr){ stack=[{name:'home',params:{}}]; return render(); }
  applyTheme();
  const view=$('#view');
  let html=scr.render(cur.params||{});
  const isTab=TAB_SCREENS.includes(cur.name) && !scr.noNav;
  view.innerHTML=`<section class="screen ${navAnim?'':'no-anim'} ${scr.cls||''}">${html}</section>${isTab?bottomNav(cur.name):''}`;
  const sc=$('#view .scroll'); if(sc && cur.scroll) sc.scrollTop=cur.scroll;
  if(scr.after) scr.after(cur.params||{}, view);
}
function bottomNav(active){
  const m=me();
  const item=(n,ic,label)=>`<button class="nav-item ${active===n?'on':''}" data-a="tab" data-t="${n}">${ic}<span>${label}</span></button>`;
  return `<nav class="bottom-nav">${item('home',icon('home'),'Inicio')}${item('explore',icon('compass'),'Explorar')}<button class="nav-plus" data-a="create" aria-label="Publicar"><span>${icon('plus')}</span></button>${item('match',icon('zap'),'Match')}${item('profile',m?avatarHTML(m):icon('user'),'Perfil')}</nav>`;
}
function applyTheme(){
  let t=S.settings.theme; if(t==='system') t=matchMedia('(prefers-color-scheme: light)').matches?'light':'dark';
  document.documentElement.setAttribute('data-theme',t);
  const F=FONTS[S.settings.font]||FONTS.choggun; document.documentElement.style.setProperty('--font-body',F.body); document.documentElement.style.setProperty('--font-head',F.head); document.documentElement.setAttribute('data-font',S.settings.font||'choggun');
  document.documentElement.style.setProperty('--card-opacity',S.settings.cardOpacity);
  const mc=$('meta[name=theme-color]'); if(mc) mc.content=t==='light'?'#fbf7ee':'#0b1720';
  if(isNative){ StatusBar.setStyle({style:t==='light'?'LIGHT':'DARK'}).catch(()=>{}); StatusBar.setBackgroundColor({color:t==='light'?'#fbf7ee':'#0b1720'}).catch(()=>{}); }
}

/* ---------- overlays ---------- */
function overlayOpen(){ return !!$('#overlay .overlay'); }
function closeOverlay(instant){ const o=$('#overlay'); if(o) o.innerHTML=''; }
function showSheet(inner,title=''){ $('#overlay').innerHTML=`<div class="overlay" data-a="overlayBg"><div class="sheet" role="dialog"><div class="grab"></div>${title?`<div class="sheet-title">${title}</div>`:''}${inner}</div></div>`; }
function showDialog({title,text='',ok='Aceptar',cancel='Cancelar',danger=false,onOk,html=''}){
  dialogOk=onOk;
  $('#overlay').innerHTML=`<div class="overlay center" data-a="overlayBg"><div class="dialog" role="alertdialog"><div class="h2">${title}</div>${text?`<p>${text}</p>`:''}${html}<div class="row">${cancel?`<button class="btn btn-ghost btn-sm" data-a="closeOverlay">${cancel}</button>`:''}<button class="btn ${danger?'btn-red':'btn-primary'} btn-sm" data-a="dialogOk">${ok}</button></div></div></div>`;
}
let dialogOk=null;
let toastTimer=null;
function toast(msg){ const t=$('#toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove('show'),2600); }
function requireAuth(what){
  if(S.session) return true;
  showDialog({title:'Únete a CHOGGUN',text:`Inicia sesión o crea una cuenta para ${what}.`,ok:'Iniciar sesión',cancel:'Ahora no',onOk:()=>go('auth',{mode:'login'})});
  return false;
}

/* ---------- notificaciones ---------- */
function showIncoming(row){
  if(!S.settings.notifications) return;
  const v=notifView(row); toast(v.text.replace(/<[^>]+>/g,''));
}
function updateBadges(){
  const n=unreadNotifs(), c=unreadChats();
  $$('[data-badge=notifs]').forEach(b=>{ b.textContent=n; b.style.display=n?'grid':'none'; });
  $$('[data-badge=chats]').forEach(b=>{ b.textContent=c; b.style.display=c?'grid':'none'; });
}
function later(ms,fn){ setTimeout(()=>{ try{ fn(); }catch(e){ console.error(e); } },ms); }

/* ---------- imágenes ---------- */
function pickImages({multiple=false,max=1000,quality=.82}={}){
  return new Promise(resolve=>{
    const inp=document.createElement('input'); inp.type='file'; inp.accept='image/*'; if(multiple) inp.multiple=true;
    inp.onchange=async()=>{ const files=[...inp.files]; const out=[]; for(const f of files){ try{ out.push(await resizeImage(f,max,quality)); }catch(e){ toast('No se pudo leer una imagen'); } } resolve(out); };
    inp.click();
  });
}
function resizeImage(file,max,quality){
  return new Promise((res,rej)=>{
    const fr=new FileReader(); fr.onerror=rej;
    fr.onload=()=>{ const img=new Image(); img.onerror=rej; img.onload=()=>{
      const k=Math.min(1,max/Math.max(img.width,img.height)); const c=document.createElement('canvas');
      c.width=Math.round(img.width*k); c.height=Math.round(img.height*k);
      const ctx=c.getContext('2d'); ctx.fillStyle='#fff'; ctx.fillRect(0,0,c.width,c.height); ctx.drawImage(img,0,0,c.width,c.height);
      res(c.toDataURL('image/jpeg',quality)); }; img.src=fr.result; };
    fr.readAsDataURL(file);
  });
}

function pickVideo(){
  return new Promise(resolve=>{
    const inp=document.createElement('input'); inp.type='file'; inp.accept='video/mp4,video/webm,video/quicktime,video/*';
    inp.onchange=()=>resolve(inp.files[0]||null); inp.click();
  });
}
/** Toma un fotograma del video como miniatura (JPEG). */
function videoPoster(file){
  return new Promise(resolve=>{
    const url=URL.createObjectURL(file); const v=document.createElement('video'); v.muted=true; v.playsInline=true; v.preload='auto'; v.src=url;
    const done=d=>{ URL.revokeObjectURL(url); resolve(d); };
    v.onloadedmetadata=()=>{ v.currentTime=Math.min(1,(v.duration||2)/2); };
    v.onseeked=()=>{ const k=Math.min(1,960/Math.max(v.videoWidth,v.videoHeight)); const c=document.createElement('canvas'); c.width=Math.max(1,Math.round(v.videoWidth*k)); c.height=Math.max(1,Math.round(v.videoHeight*k)); c.getContext('2d').drawImage(v,0,0,c.width,c.height); done(c.toDataURL('image/jpeg',.82)); };
    v.onerror=()=>done(null); setTimeout(()=>done(null),12000);
  });
}

/* ---------- progreso de subida ---------- */
function showProgress(title){
  $('#overlay').innerHTML=`<div class="overlay center"><div class="dialog" role="alertdialog"><div class="h2">${title}</div><p class="small muted" id="upText" style="margin-top:6px">Preparando…</p><div class="progress" style="margin-top:12px"><i id="upBar" style="width:0%"></i></div></div></div>`;
}
function setProgress(done,total,frac){ const b=$('#upBar'), t=$('#upText'); if(b) b.style.width=Math.round(frac*100)+'%'; if(t) t.textContent=total?`Subiendo archivos: ${done} de ${total} (${Math.round(frac*100)}%)`:'Guardando…'; }

/* ---------- compartir ---------- */
async function shareText(title,text){
  const full=`${title}\n${text}\n— Léelo en CHOGGUN`;
  if(isNative){ try{ await Share.share({title,text:full,dialogTitle:'Compartir'}); return; }catch(e){ if(/cancel/i.test(String(e&&e.message))) return; } }
  try{ if(navigator.share){ await navigator.share({title,text:full}); return; } }catch(e){ if(e&&e.name==='AbortError') return; }
  try{ await navigator.clipboard.writeText(full); toast('Copiado al portapapeles'); }catch(e){ toast('No se pudo compartir'); }
}

/* ================= Noticias: gaming, anime, cine y series (RSS) ================= */
const NEWS_KEY='choggun_news_v1';
const NEWS_TTL=30*60*1000;          // se actualizan cada 30 minutos
const NEWS={items:[],t:0,loading:false,error:false};
(function(){ try{ const c=JSON.parse(localStorage.getItem(NEWS_KEY)||'null'); if(c&&Array.isArray(c.items)){ NEWS.items=c.items; NEWS.t=c.t||0; } }catch(e){} })();

function decodeEntities(s){ const t=document.createElement('textarea'); t.innerHTML=s; return t.value; }
function stripCdata(s){ return String(s||'').replace(/^\s*<!\[CDATA\[/,'').replace(/\]\]>\s*$/,''); }
function xmlTag(block,name){ const m=block.match(new RegExp('<'+name+'(?:\\s[^>]*)?>([\\s\\S]*?)</'+name+'>','i')); return m?stripCdata(m[1]).trim():''; }
function xmlAttr(block,tag,attr){ const m=block.match(new RegExp('<'+tag+'\\b[^>]*\\b'+attr+'=["\']([^"\']+)["\']','i')); return m?m[1]:''; }
function textOnly(html){ const d=document.createElement('div'); d.innerHTML=html; return (d.textContent||'').replace(/\s+/g,' ').trim(); }

function parseFeed(xml,feed){
  const out=[]; const parts=String(xml).split(/<item[\s>]/i).slice(1);
  for(const raw of parts.slice(0,25)){
    const block=raw.split(/<\/item>/i)[0];
    const title=textOnly(decodeEntities(xmlTag(block,'title')));
    let link=decodeEntities(xmlTag(block,'link'))||decodeEntities(xmlTag(block,'guid'));
    if(!title||!/^https?:\/\//.test(link)) continue;
    const descRaw=xmlTag(block,'content:encoded')||xmlTag(block,'description');
    const descHtml=decodeEntities(descRaw);
    let img=xmlAttr(block,'media:thumbnail','url')||xmlAttr(block,'media:content','url')||(xmlAttr(block,'enclosure','type').startsWith('image')||/\.(jpe?g|png|webp)/i.test(xmlAttr(block,'enclosure','url'))?xmlAttr(block,'enclosure','url'):'');
    if(!img){ const m=descHtml.match(/<img[^>]+src=["']([^"']+)["']/i); if(m) img=m[1]; }
    if(img && img.startsWith('//')) img='https:'+img;
    if(img && !/^https:\/\//.test(img)) img='';
    const date=Date.parse(xmlTag(block,'pubDate')||xmlTag(block,'dc:date')||'')||Date.now();
    let snippet=textOnly(descHtml); if(snippet.length>170) snippet=snippet.slice(0,167).replace(/\s+\S*$/,'')+'…';
    out.push({id:feed.id+'_'+hashStr(link).toString(36),title,link,img,snippet,date,source:feed.name,cat:feed.cat});
  }
  return out;
}
function fetchWithTimeout(url,ms){
  const get=isNative
    ? CapacitorHttp.get({url,headers:{'Accept':'application/rss+xml, application/xml, text/xml, */*'},responseType:'text',connectTimeout:ms,readTimeout:ms}).then(r=>{ if(r.status<200||r.status>=300) throw new Error('HTTP '+r.status); return typeof r.data==='string'?r.data:String(r.data||''); })
    : fetch(url,{headers:{'Accept':'application/rss+xml, application/xml, text/xml, */*'}}).then(r=>{ if(!r.ok) throw new Error('HTTP '+r.status); return r.text(); });
  return Promise.race([get,new Promise((_,rej)=>setTimeout(()=>rej(new Error('timeout')),ms))]);
}
async function loadNews(force){
  if(NEWS.loading) return;
  if(!force && NEWS.items.length && Date.now()-NEWS.t<NEWS_TTL) return;
  NEWS.loading=true; NEWS.error=false; onNewsChange();
  const results=await Promise.allSettled(NEWS_FEEDS.map(f=>fetchWithTimeout(f.url,15000).then(x=>parseFeed(x,f))));
  const items=results.filter(r=>r.status==='fulfilled').flatMap(r=>r.value);
  NEWS.loading=false;
  if(items.length){
    const seen=new Set(); NEWS.items=items.sort((a,b)=>b.date-a.date).filter(n=>{ const k=normalize(n.title).slice(0,60); if(seen.has(k)) return false; seen.add(k); return true; }).slice(0,90);
    NEWS.t=Date.now();
    try{ localStorage.setItem(NEWS_KEY,JSON.stringify({t:NEWS.t,items:NEWS.items})); }catch(e){}
  } else NEWS.error=true;
  onNewsChange();
}
function onNewsChange(){ const c=current(); if(c && c.name==='home' && !overlayOpen()) refresh(); }
function openExternal(url){
  if(isNative){ Browser.open({url,toolbarColor:'#0b1720'}).catch(()=>window.open(url,'_blank','noopener')); return; }
  window.open(url,'_blank','noopener');
}
function newsThumb(n,cls=''){
  const c=NEWS_CATS[n.cat]||NEWS_CATS.gaming;
  const ph=`<div class="news-ph" style="--nc:${c.color}">${icon(c.icon)}</div>`;
  return `<div class="news-img ${cls}">${ph}${n.img?`<img src="${esc(n.img)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()">`:''}</div>`;
}
function newsCatTag(cat){ const c=NEWS_CATS[cat]; return `<span class="tag" style="color:${c.color};border-color:${c.color}55;background:${c.color}1a">${icon(c.icon,'width="12" height="12"')} ${c.label}</span>`; }
function newsCard(n){ return `<button class="news-card" data-a="openNews" data-id="${n.id}">${newsThumb(n)}<div class="news-body"><div class="row" style="gap:6px">${newsCatTag(n.cat)}<span class="tiny faint ellipsis">${esc(n.source)} · ${timeAgo(n.date)}</span></div><b class="clamp3">${esc(n.title)}</b></div></button>`; }
function newsRow(n){ return `<button class="news-row" data-a="openNews" data-id="${n.id}">${newsThumb(n,'sm')}<div class="grow" style="min-width:0;text-align:left"><div class="row" style="gap:6px;margin-bottom:4px">${newsCatTag(n.cat)}<span class="tiny faint ellipsis">${esc(n.source)} · ${timeAgo(n.date)}</span></div><b class="clamp3" style="font-size:15.5px;line-height:1.25">${esc(n.title)}</b>${n.snippet?`<p class="tiny muted clamp2" style="margin-top:4px">${esc(n.snippet)}</p>`:''}</div></button>`; }
function newsStatusHTML(){
  if(NEWS.loading && !NEWS.items.length) return `<div class="empty"><div class="spinner"></div><div class="small">Cargando las últimas noticias…</div></div>`;
  if(!NEWS.items.length) return `<div class="empty">${icon('wifi-off','class="empty-ic"')}<div class="h3">No se pudieron cargar las noticias</div><div class="small">Revisa tu conexión a internet e inténtalo de nuevo.</div><button class="btn btn-primary btn-sm" data-a="newsRefresh">${icon('refresh')} Reintentar</button></div>`;
  return '';
}

/* ================= CHOGGUN — pantallas ================= */
const A={}, F={}, I={};
const UI={ feedTab:'parati', feedFmt:'all', newsCat:'all', exploreQ:'', exploreFilter:'all', commTab:'popular', profileTab:'obras', replyTo:null, commentSort:'top', matchFilters:{roles:[],genres:[],collab:[]}, lastSkipped:[] };

/* ======================= ONBOARDING ======================= */
const ONB=[
  {logo:true,t:'Bienvenido a CHOGGUN',d:'La comunidad colaborativa de escritores, ilustradores y lectores de Latinoamérica.'},
  {bg:'fondo1',t:'Publica en todos los formatos',d:'Novelas por capítulos, relatos, manga, cómic e ilustración en un mismo lugar. Recibe votos, comentarios y feedback real.'},
  {bg:'fondo2',t:'Crea en comunidad',d:'Únete a comunidades, sigue a creadores, escríbeles por mensaje y comparte créditos en cada obra. Solo personas reales: cada cuenta confirma su correo.'},
];
SCREENS.onboarding={ noNav:true, cls:'onb-screen', render(p){ const i=p.i||0;
  return `<div class="onb-stage">${ONB.map((s,k)=>s.bg
    ?`<div class="onb-slide ${k===i?'on':''}" data-k="${k}"><div class="onb-bg" style="background-image:url(${ASSETS[s.bg]})"></div><div class="onb-shade"></div><div class="onb-text"><div class="h1">${s.t}</div><p>${s.d}</p></div></div>`
    :`<div class="onb-slide onb-first ${k===i?'on':''}" data-k="${k}"><div class="onb-glow"></div><div class="onb"><div class="art"><img src="${ASSETS.logo}" alt="CHOGGUN"></div><div class="h1">${s.t}</div><p class="muted" style="font-size:17px;max-width:330px">${s.d}</p></div></div>`).join('')}</div>
    <div class="onb-top"><span></span><button class="btn btn-sm onb-skip" data-a="onbDone">Saltar</button></div>
    <div class="onb-controls"><div class="dots" style="margin-bottom:20px">${ONB.map((_,k)=>`<i class="${k===i?'on':''}" data-a="onbGo" data-i="${k}"></i>`).join('')}</div>
    <button class="btn btn-primary btn-block onb-next" data-a="onbNext"><span class="onb-label">${i===ONB.length-1?'Empezar':'Siguiente'}</span> ${icon('chevR')}</button></div>`; },
  after(p,view){ const el=view.querySelector('.onb-screen'); if(!el) return; let x0=null,y0=0;
    el.addEventListener('touchstart',e=>{ x0=e.touches[0].clientX; y0=e.touches[0].clientY; },{passive:true});
    el.addEventListener('touchend',e=>{ if(x0==null) return; const dx=e.changedTouches[0].clientX-x0, dy=e.changedTouches[0].clientY-y0; x0=null;
      if(Math.abs(dx)<50||Math.abs(dx)<Math.abs(dy)) return; const i=current().params.i||0;
      if(dx<0){ if(i<ONB.length-1) onbTo(i+1); } else if(i>0) onbTo(i-1); },{passive:true}); } };
function onbTo(n){ const cur=current(); if(cur.name!=='onboarding') return; const i=cur.params.i||0; if(n===i) return; cur.params={i:n};
  const view=$('#view'), dir=n>i?'fwd':'back';
  view.querySelectorAll('.onb-slide').forEach(sl=>{ const k=+sl.dataset.k; sl.classList.remove('on','fwd','back'); if(k===n){ sl.classList.add(dir); void sl.offsetWidth; sl.classList.add('on'); } });
  view.querySelectorAll('.onb-controls .dots i').forEach((d,k)=>d.classList.toggle('on',k===n));
  const lb=view.querySelector('.onb-label'); if(lb){ const t=n===ONB.length-1?'Empezar':'Siguiente'; if(lb.textContent!==t){ lb.classList.remove('swap'); void lb.offsetWidth; lb.textContent=t; lb.classList.add('swap'); } } }
A.onbGo=el=>onbTo(+el.dataset.i);
A.onbNext=()=>{ const i=current().params.i||0; if(i<ONB.length-1) onbTo(i+1); else A.onbDone(); };
let onbLeaving=false;
A.onbDone=()=>{ if(onbLeaving) return; onbLeaving=true; S.settings.onboarded=true; save(); const sc=$('#view .screen'); if(sc) sc.classList.add('onb-out');
  setTimeout(()=>{ onbLeaving=false; stack=[{name:'auth',params:{mode:'login',first:true,enter:true}}]; navAnim=true; render(); },380); };

/* ======================= AUTH ======================= */
function authHero(p){ return `<div class="auth-hero" style="${p.first?'padding-top:calc(40px + var(--safe-top))':''}"><img src="${ASSETS.logo}" alt=""><div class="h1 gold" style="letter-spacing:.14em">CHOGGUN</div><div class="muted small">Escribe. Ilustra. Colabora.</div></div>`; }
const PASS_RULE='Mínimo 6 caracteres, con al menos un número y una minúscula';
const passOk=p=>p.length>=6&&/[a-z]/.test(p)&&/\d/.test(p);
SCREENS.auth={ noNav:true, get cls(){ const c=current(); return c.params&&c.params.enter?'auth-enter':''; }, render(p){ const reg=p.mode==='register';
  return `${p.first?'':topbar({title:''})}<div class="scroll">
  ${authHero(p)}
  <div class="pad"><div class="seg" style="margin-bottom:18px"><button class="${reg?'':'on'}" data-a="authMode" data-m="login">Iniciar sesión</button><button class="${reg?'on':''}" data-a="authMode" data-m="register">Crear cuenta</button></div>
  ${reg?`<form data-f="register" novalidate>
    <div class="row" style="gap:10px"><label class="field grow"><span>Nombre</span><input class="input" name="name" placeholder="Juana" autocomplete="given-name"></label><label class="field grow"><span>Apellido</span><input class="input" name="last" placeholder="Pérez" autocomplete="family-name"></label></div>
    <label class="field"><span>Nombre de usuario</span><div class="input-wrap">${icon('at')}<input class="input" name="username" placeholder="tu_usuario" autocapitalize="off" autocomplete="username"></div><div class="hint">3–20 caracteres: letras, números o _ (no se puede cambiar después)</div></label>
    <label class="field"><span>Correo electrónico</span><div class="input-wrap">${icon('mail')}<input class="input" type="email" name="email" placeholder="correo@ejemplo.com" autocomplete="email" autocapitalize="off"></div><div class="hint">Te enviaremos un código para confirmar que eres una persona real</div></label>
    <label class="field"><span>Contraseña</span><div class="input-wrap">${icon('lock')}<input class="input" type="password" name="pass" placeholder="••••••••" autocomplete="new-password"><button type="button" class="icon-btn eye" data-a="togglePw">${icon('eye')}</button></div><div class="hint">${PASS_RULE}</div></label>
    <label class="field"><span>Confirmar contraseña</span><div class="input-wrap">${icon('lock')}<input class="input" type="password" name="pass2" placeholder="••••••••" autocomplete="new-password"></div></label>
    <div class="field"><span>Soy…</span><div class="chips wrap" data-single="role">${ROLES.map((r,i)=>`<button type="button" class="chip ${i===0?'on':''}" data-a="chipSingle" data-v="${r}">${icon(ROLE_ICONS[r])} ${r}</button>`).join('')}</div><input type="hidden" name="role" value="${ROLES[0]}"></div>
    <label class="row small muted" style="margin:6px 0 16px;gap:10px"><input type="checkbox" name="terms" style="width:20px;height:20px;accent-color:var(--gold)"> Acepto las <button type="button" class="link" data-a="rules">normas de la comunidad</button></label>
    <div class="err" data-err style="margin-bottom:10px"></div>
    <button class="btn btn-primary btn-block">Crear cuenta</button></form>`
  :`<form data-f="login" novalidate>
    <label class="field"><span>Correo electrónico</span><div class="input-wrap">${icon('mail')}<input class="input" type="email" name="id" placeholder="correo@ejemplo.com" autocapitalize="off" autocomplete="email"></div></label>
    <label class="field"><span>Contraseña</span><div class="input-wrap">${icon('lock')}<input class="input" type="password" name="pass" placeholder="••••••••" autocomplete="current-password"><button type="button" class="icon-btn eye" data-a="togglePw">${icon('eye')}</button></div></label>
    <div class="row between small" style="margin:-4px 0 16px"><span></span><button type="button" class="link" data-a="forgot">¿Olvidaste tu contraseña?</button></div>
    <div class="err" data-err style="margin-bottom:10px"></div>
    <button class="btn btn-primary btn-block">Entrar</button></form>
    <div class="divider">¿Eres nuevo?</div>
    <button class="btn btn-ghost btn-block" data-a="authMode" data-m="register">${icon('userPlus')} Crear una cuenta</button>`}
  <div class="divider">o</div>
  <button class="btn btn-block btn-google" data-a="googleLogin"><img class="g-logo" src="${ASSETS.google}" alt=""> Continuar con Google</button>
  <button class="btn btn-block" style="margin-top:10px;color:var(--muted)" data-a="guest">Explorar como invitado</button>
  <p class="tiny faint center" style="margin:18px 0 10px">Semillero SIIANTEC · TEINCO</p>
  </div></div>`; } };
A.authMode=el=>{ replace('auth',{...current().params,mode:el.dataset.m,enter:false}); };
A.togglePw=el=>{ const i=el.parentElement.querySelector('input'); i.type=i.type==='password'?'text':'password'; el.innerHTML=icon(i.type==='password'?'eye':'eyeOff'); };
A.chipSingle=el=>{ const box=el.closest('[data-single]'); $$('.chip',box).forEach(c=>c.classList.toggle('on',c===el)); const h=box.parentElement.querySelector(`input[name=${box.dataset.single}]`); if(h) h.value=el.dataset.v; };
A.forgot=()=>{ const f=$('form[data-f=login]'); go('forgot',{email:f?f.id.value.trim():''}); };
A.guest=()=>{ stack=[{name:'home',params:{}}]; render(); toast('Explorando como invitado'); };
function busy(form,on,label){ const b=form.querySelector('button.btn-primary'); if(!b) return; if(on){ b.dataset.l=b.innerHTML; b.disabled=true; b.innerHTML=label; } else { b.disabled=false; if(b.dataset.l) b.innerHTML=b.dataset.l; } }
F.login=async form=>{
  const d=Object.fromEntries(new FormData(form)); const err=$('[data-err]',form);
  const email=(d.id||'').trim();
  if(!email||!d.pass){ err.textContent='Escribe tu correo y tu contraseña'; return; }
  if(!email.includes('@')){ err.textContent='Entra con tu correo electrónico'; return; }
  err.textContent=''; busy(form,true,'Entrando…');
  try{ await DB.signIn(email,d.pass); await afterLogin(false); }
  catch(e){
    if(e.code==='EMAIL_NOT_CONFIRMED'){ DB.resendSignup(email).catch(()=>{}); go('verify',{email:email.toLowerCase()}); toast('Te enviamos un código nuevo'); }
    else err.textContent=errMsg(e);
  }finally{ busy(form,false); }
};
F.register=async form=>{
  const d=Object.fromEntries(new FormData(form)); const err=$('[data-err]',form); const un=(d.username||'').trim();
  if(!d.name.trim()||!d.last.trim()||!un||!d.email.trim()||!d.pass){ err.textContent='Completa todos los campos'; return; }
  if(!/^[a-zA-Z0-9_]{3,20}$/.test(un)){ err.textContent='El usuario debe tener 3–20 caracteres (letras, números o _)'; return; }
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email.trim())){ err.textContent='Escribe un correo válido'; return; }
  if(!passOk(d.pass)){ err.textContent='La contraseña debe tener 6+ caracteres, un número y una minúscula'; return; }
  if(d.pass!==d.pass2){ err.textContent='Las contraseñas no coinciden'; return; }
  if(!d.terms){ err.textContent='Debes aceptar las normas de la comunidad'; return; }
  if(isToxic(un+' '+d.name+' '+d.last)){ err.textContent='El nombre contiene lenguaje no permitido'; return; }
  err.textContent=''; busy(form,true,'Creando cuenta…');
  try{
    if(!await DB.usernameAvailable(un)){ err.textContent='Ese nombre de usuario ya existe'; return; }
    const r=await DB.signUp({email:d.email,password:d.pass,username:un,name:`${d.name.trim()} ${d.last.trim()}`,role:d.role||ROLES[0]});
    if(r.needsCode) go('verify',{email:d.email.trim().toLowerCase(),isNew:1}); else await afterLogin(true);
  }catch(e){ err.textContent=errMsg(e); }
  finally{ busy(form,false); }
};
/* Confirmar correo con el código de 6 dígitos */
let resendAt=0;
function codeField(){ return `<label class="field"><span>Código</span><input class="input code-input" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="10" placeholder="123456"></label>`; }
SCREENS.verify={ noNav:true, render(p){
  return `${topbar({title:''})}<div class="scroll">${authHero({})}<div class="pad">
  <div class="h2" style="margin-bottom:6px">Confirma tu correo</div><p class="muted small" style="margin-bottom:16px">Te enviamos un código de 6 dígitos a <b>${esc(p.email)}</b>. Revisa también la carpeta de spam.</p>
  <form data-f="verify" novalidate>${codeField()}<div class="err" data-err style="margin-bottom:10px"></div><button class="btn btn-primary btn-block">Confirmar</button></form>
  <button class="btn btn-block" style="margin-top:10px;color:var(--muted)" data-a="resendCode">${icon('refresh')} Enviar un código nuevo</button></div></div>`; } };
F.verify=async form=>{ const p=current().params; const code=(form.code.value||'').replace(/\D/g,''); const err=$('[data-err]',form);
  if(code.length<6){ err.textContent='Escribe el código completo'; return; }
  busy(form,true,'Confirmando…');
  try{ await DB.verifySignup(p.email,code); await afterLogin(true); }catch(e){ err.textContent=errMsg(e); }finally{ busy(form,false); } };
A.resendCode=async()=>{ const p=current().params; if(Date.now()<resendAt) return toast(`Espera ${Math.ceil((resendAt-Date.now())/1000)} s para pedir otro`);
  try{ await DB.resendSignup(p.email); resendAt=Date.now()+60000; toast('Te enviamos un código nuevo'); }catch(e){ toast(errMsg(e)); } };
/* Recuperar contraseña con código */
SCREENS.forgot={ noNav:true, render(p){
  const step2=!!p.sent;
  return `${topbar({title:''})}<div class="scroll">${authHero({})}<div class="pad">
  <div class="h2" style="margin-bottom:6px">${step2?'Crea tu contraseña nueva':'Recupera tu contraseña'}</div>
  <p class="muted small" style="margin-bottom:16px">${step2?`Si existe una cuenta con <b>${esc(p.email)}</b>, te enviamos un código de 6 dígitos.`:'Te enviaremos un código a tu correo para crear una contraseña nueva.'}</p>
  ${step2?`<form data-f="resetPw" novalidate>${codeField()}<label class="field"><span>Contraseña nueva</span><div class="input-wrap">${icon('lock')}<input class="input" type="password" name="pass" placeholder="••••••••" autocomplete="new-password"><button type="button" class="icon-btn eye" data-a="togglePw">${icon('eye')}</button></div><div class="hint">${PASS_RULE}</div></label><div class="err" data-err style="margin-bottom:10px"></div><button class="btn btn-primary btn-block">Guardar y entrar</button></form>`
  :`<form data-f="forgot" novalidate><label class="field"><span>Correo electrónico</span><div class="input-wrap">${icon('mail')}<input class="input" type="email" name="email" value="${esc(p.email||'')}" placeholder="correo@ejemplo.com" autocapitalize="off" autocomplete="email"></div></label><div class="err" data-err style="margin-bottom:10px"></div><button class="btn btn-primary btn-block">Enviar código</button></form>`}
  </div></div>`; } };
F.forgot=async form=>{ const email=form.email.value.trim(); const err=$('[data-err]',form);
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ err.textContent='Escribe un correo válido'; return; }
  busy(form,true,'Enviando…');
  try{ await DB.requestReset(email); replace('forgot',{email:email.toLowerCase(),sent:1}); }catch(e){ err.textContent=errMsg(e); }finally{ busy(form,false); } };
F.resetPw=async form=>{ const p=current().params; const code=(form.code.value||'').replace(/\D/g,''); const pass=form.pass.value; const err=$('[data-err]',form);
  if(code.length<6){ err.textContent='Escribe el código completo'; return; }
  if(!passOk(pass)){ err.textContent='La contraseña debe tener 6+ caracteres, un número y una minúscula'; return; }
  busy(form,true,'Guardando…');
  try{ await DB.resetWithCode(p.email,code,pass); await afterLogin(false); toast('Contraseña actualizada'); }catch(e){ err.textContent=errMsg(e); }finally{ busy(form,false); } };

/** Tras entrar: carga la cuenta y sus datos; las cuentas nuevas van a completar su perfil. */
/* ---------- Entrar con Google (nativo) ---------- */
const GOOGLE_WEB_CLIENT_ID='976953608981-e09qak98oca7p8egsqm65e4effdrno5r.apps.googleusercontent.com';
let googleInit=null, googleBusy=false;
async function sha256Hex(t){ const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t)); return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join(''); }
A.googleLogin=async btn=>{
  if(googleBusy) return;
  if(!isNative) return toast('Entrar con Google está disponible en la app del celular');
  googleBusy=true; const label=btn.innerHTML; btn.disabled=true; btn.innerHTML='Abriendo Google…';
  try{
    if(!googleInit) googleInit=SocialLogin.initialize({google:{webClientId:GOOGLE_WEB_CLIENT_ID,mode:'online'}});
    await googleInit;
    const raw=[...crypto.getRandomValues(new Uint8Array(32))].map(x=>x.toString(16).padStart(2,'0')).join('');
    const res=await SocialLogin.login({provider:'google',options:{nonce:await sha256Hex(raw),style:'standard'}});
    const idToken=res&&res.result&&res.result.idToken;
    if(!idToken) throw new Error('Google no entregó la cuenta. Intenta de nuevo.');
    btn.innerHTML='Entrando…';
    await DB.signInWithGoogle(idToken,raw);
    await afterLogin('auto');
  }catch(e){
    googleInit=null; const m=String(e&&e.message||e||'');
    if(!/reauth/i.test(m)&&/cancel|canceled|cancelled|16:|user.*abort/i.test(m)) return;
    if(/28444|developer console|not set up correctly|reauth|\[16\]|signingSha1/i.test(m)) showDialog({title:'Google aún no reconoce la app',text:'Falta registrar esta app de Android en Google Cloud (paquete com.choggun.app y su huella SHA-1). Mientras tanto puedes entrar con tu correo y contraseña.',ok:'Entendido',cancel:''});
    else if(/no credential|no.*account/i.test(m)) toast('Agrega una cuenta de Google en tu teléfono e intenta de nuevo');
    else toast(errMsg(e));
  }finally{ googleBusy=false; if(document.body.contains(btn)){ btn.disabled=false; btn.innerHTML=label; } }
};
async function afterLogin(isNew){
  await startSession();
  if(!S.session) throw new Error('No se pudo iniciar sesión');
  if(isNew==='auto'){ const m=me(); isNew=!!m && Date.now()-m.joined<5*60*1000 && !m.bio; }
  stack=[{name:'home',params:{}}];
  if(isNew){ stack.push({name:'editProfile',params:{first:true}}); toast('Cuenta creada'); }
  else toast(`Bienvenido de nuevo, ${me().name.split(' ')[0]}`);
  navAnim=true; render();
}

/* ======================= APARIENCIA (tema + fuente) ======================= */
function appearanceHTML(){
  const s=S.settings;
  return `<div class="field"><span>Modo</span><div class="seg">${[['dark','Oscuro','moon'],['light','Claro','sun'],['system','Sistema','sun-moon']].map(([k,l,ic])=>`<button class="${s.theme===k?'on':''}" data-a="setTheme" data-v="${k}">${icon(ic)} ${l}</button>`).join('')}</div></div>
  <div class="field" style="margin-bottom:0"><span>Tipo de fuente</span><div class="font-grid">${Object.entries(FONTS).map(([k,f])=>`<button class="font-opt ${s.font===k?'on':''}" data-a="setFont" data-v="${k}"><b style="font-family:${f.head.replace(/"/g,"'")}">Aa</b><span style="font-family:${f.body.replace(/"/g,"'")}">${f.label}</span><i>${esc(f.desc)}</i></button>`).join('')}</div></div>`;
}
A.appearance=()=>showSheet(`<div style="padding:0 18px 10px" id="appearanceBox">${appearanceHTML()}</div>`,'Apariencia');
A.setTheme=el=>{ S.settings.theme=el.dataset.v; save(); applyTheme(); const box=$('#appearanceBox'); if(box) box.innerHTML=appearanceHTML(); else refresh(); };
A.setFont=el=>{ S.settings.font=el.dataset.v; save(); applyTheme(); const box=$('#appearanceBox'); if(box){ box.innerHTML=appearanceHTML(); } else refresh(); toast('Fuente: '+FONTS[el.dataset.v].label); };

/* ======================= HOME ======================= */
function headerActions(){
  return `<button class="icon-btn" data-a="appearance" aria-label="Apariencia">${icon('sun-moon')}</button><button class="icon-btn" data-a="go" data-s="chats" aria-label="Mensajes">${icon('chat')}<span class="badge" data-badge="chats" style="display:none"></span></button><button class="icon-btn" data-a="go" data-s="notifs" aria-label="Notificaciones">${icon('bell')}<span class="badge" data-badge="notifs" style="display:none"></span></button>`;
}
function feedList(){
  let list=visibleWorks(); const m=me();
  if(UI.feedFmt!=='all') list=list.filter(w=>w.type===UI.feedFmt);
  if(UI.feedTab==='siguiendo'){
    if(!m) return null;
    const j=S.joined[m.username]||[];
    list=list.filter(w=>isFollowing(w.author)||j.includes(w.community)||w.author===m.username);
    list.sort((a,b)=>b.created-a.created);
  }else if(UI.feedTab==='nuevo') list.sort((a,b)=>b.created-a.created);
  else list.sort((a,b)=>hot(b)-hot(a));
  return list;
}
function newsSection(){
  const items=NEWS.items.slice(0,10);
  let body;
  if(items.length) body=`<div class="shelf news-shelf">${items.map(newsCard).join('')}</div>`;
  else if(NEWS.loading) body=`<div class="shelf news-shelf">${[0,1,2].map(()=>`<div class="news-card skeleton" style="height:208px"></div>`).join('')}</div>`;
  else body=`<button class="card row" style="padding:14px;width:100%;gap:12px;text-align:left" data-a="newsRefresh">${icon('wifi-off','width="22" height="22" style="color:var(--muted)"')}<span class="grow small muted">No se pudieron cargar las noticias. Toca para reintentar.</span>${icon('refresh','width="18" height="18"')}</button>`;
  return `<div class="section-label"><span>Últimas noticias</span><button data-a="feedTab" data-k="noticias">Ver todas</button></div>${body}`;
}
function newsTab(){
  const list=UI.newsCat==='all'?NEWS.items:NEWS.items.filter(n=>n.cat===UI.newsCat);
  return `<div class="chips" style="margin-bottom:12px">${[['all','Todo','newspaper'],...Object.entries(NEWS_CATS).map(([k,c])=>[k,c.label,c.icon])].map(([k,l,ic])=>`<button class="chip ${UI.newsCat===k?'on':''}" data-a="newsCat" data-k="${k}">${icon(ic)} ${l}</button>`).join('')}</div>
  <div class="row between" style="margin-bottom:10px"><span class="tiny faint">${NEWS.loading?'Actualizando…':NEWS.t?`Actualizado ${timeAgo(NEWS.t)} · se renueva cada 30 min`:''}</span><button class="btn btn-sm btn-ghost" data-a="newsRefresh" ${NEWS.loading?'disabled':''}>${icon('refresh')} Actualizar</button></div>
  ${newsStatusHTML()||(list.length?`<div class="list">${list.map(newsRow).join('')}</div>`:emptyHTML('newspaper','Sin noticias en esta categoría','Prueba con otra categoría o actualiza.'))}
  <p class="tiny faint center" style="margin-top:14px">Fuentes: ${NEWS_FEEDS.map(f=>esc(f.name)).filter((v,i,a)=>a.indexOf(v)===i).join(' · ')}</p>`;
}
SCREENS.home={ render(){
  const m=me(); let content='';
  if(UI.feedTab==='noticias') content=newsTab();
  else{
    const list=feedList();
    const hist=m?Object.entries(S.history[m.username]||{}).map(([id,h])=>({w:work(id),h})).filter(x=>x.w&&!x.w.removed&&x.w.status==='publicado'&&chaptersOf(x.w).length).sort((a,b)=>b.h.t-a.h.t):[];
    let posts='';
    if(list===null) posts=emptyHTML('lock','Inicia sesión','Inicia sesión para ver las publicaciones de las personas y comunidades que sigues.',`<button class="btn btn-primary" data-a="go" data-s="auth" data-mode="login">Iniciar sesión</button>`);
    else if(!list.length) posts=emptyHTML(UI.feedTab==='siguiendo'?'users':'pen-tool', UI.feedTab==='siguiendo'?'Aún no sigues a nadie':'Todavía no hay publicaciones', UI.feedTab==='siguiendo'?'Sigue a creadores o únete a comunidades para llenar este feed.':(S.loaded?'Aquí aparecerán las novelas, relatos, mangas, cómics, ilustraciones, videos y foros que publiquen las personas registradas en CHOGGUN. Sin bots: solo personas reales.':'Cargando publicaciones…'), UI.feedTab==='siguiendo'?`<button class="btn btn-primary" data-a="tab" data-t="explore">Explorar</button>`:`<button class="btn btn-primary" data-a="create">${icon('plus')} Publicar la primera obra</button>`);
    else list.forEach((w,i)=>{ posts+=postCard(w); if(i===2 && UI.feedTab==='parati') posts+=suggestStrip(); });
    content=`${UI.feedTab==='parati'?newsSection():''}
    ${!m?`<div class="banner-tip" style="margin:16px 0 4px"><img src="${ASSETS.logo}" alt=""><div class="grow"><b class="h3">Únete a la comunidad</b><div class="small muted">Publica tus obras, vota y encuentra colaboradores.</div></div><button class="btn btn-primary btn-sm" data-a="go" data-s="auth" data-mode="register">Unirme</button></div>`:''}
    ${hist.length && UI.feedTab==='parati'?`<div class="section-label"><span>Continuar leyendo</span></div><div class="shelf" style="margin-bottom:8px">${hist.map(({w,h})=>`<button class="shelf-item" data-a="read" data-id="${w.id}" data-ch="${h.ch}" style="text-align:left"><div class="cover">${coverHTML(w)}</div><div class="t clamp2">${esc(w.title)}</div><div class="tiny muted">Cap. ${h.ch+1} de ${chaptersOf(w).length}</div><div class="progress"><i style="width:${Math.min(100,Math.round(((h.ch+(h.pct||0))/Math.max(1,chaptersOf(w).length))*100))}%"></i></div></button>`).join('')}</div>`:''}
    <div class="section-label"><span>${UI.feedTab==='parati'?'Publicaciones de la comunidad':UI.feedTab==='siguiendo'?'De quienes sigues':'Lo más nuevo'}</span></div>
    <div class="chips" style="margin-bottom:14px">${[['all','Todo','sparkles'],...Object.entries(FORMATS).map(([k,f])=>[k,f.label,f.icon])].map(([k,l,ic])=>`<button class="chip ${UI.feedFmt===k?'on':''}" data-a="feedFmt" data-k="${k}">${icon(ic)} ${l}</button>`).join('')}</div>
    ${posts}`;
  }
  return `${topbar({back:false,brand:true,actions:headerActions()})}
  <div class="tabs">${[['parati','Para ti'],['noticias','Noticias'],['siguiendo','Siguiendo'],['nuevo','Nuevo']].map(([k,l])=>`<button class="tab ${UI.feedTab===k?'on':''}" data-a="feedTab" data-k="${k}">${l}</button>`).join('')}</div>
  <div class="scroll pb-nav"><div class="pad">${content}</div></div>`; }, after(){ updateBadges(); loadNews(); } };
function suggestStrip(){
  const cands=Object.values(S.users).filter(u=>u.username!==S.session && !isFollowing(u.username)).slice(0,8);
  if(!cands.length) return '';
  return `<div class="card" style="padding:14px;margin-bottom:14px"><div class="row between" style="margin-bottom:10px"><b class="h3 row" style="gap:6px">${icon('users','width="18" height="18" style="color:var(--gold)"')} Creadores en CHOGGUN</b><button class="link small" data-a="tab" data-t="explore">Ver más</button></div><div class="shelf">${cands.map(u=>`<button class="shelf-item center" style="width:92px" data-a="user" data-u="${u.username}">${avatarHTML(u,'av-lg')}<div class="t ellipsis" style="font-size:13px">${esc(u.name.split(' ')[0])}</div><div class="tiny muted">${esc(u.role)}</div></button>`).join('')}</div></div>`;
}
A.feedTab=el=>{ UI.feedTab=el.dataset.k; current().scroll=0; refresh(); };
A.feedFmt=el=>{ UI.feedFmt=el.dataset.k; refresh(); };
A.newsCat=el=>{ UI.newsCat=el.dataset.k; refresh(); };
A.newsRefresh=()=>{ loadNews(true); };
A.openNews=el=>{ const n=NEWS.items.find(x=>x.id===el.dataset.id); if(n) openExternal(n.link); };

/* ======================= ACCIONES DE POST ======================= */
A.tab=el=>setTab(el.dataset.t);
A.back=()=>back();
A.go=el=>{ const s=el.dataset.s; const p={...el.dataset}; delete p.a; delete p.s; if(['chats','notifs','matches','matchProfile'].includes(s) && !requireAuth('ver esta sección')) return; go(s,p); };
A.open=el=>{ const w=work(el.dataset.id); if(!w) return; if(w.author!==S.session && w.status==='publicado'){ w.views=(w.views||0)+1; DB.addView(w.id); } go('work',{id:w.id,focus:el.dataset.focus||''}); };
A.user=el=>{ const u=el.dataset.u; if(u===S.session) setTab('profile'); else go('user',{u}); };
A.comm=el=>go('community',{id:el.dataset.id});
function redrawVotes(w){ $$(`.vote`).forEach(v=>{ const b=v.querySelector(`[data-id="${w.id}"]`); if(b){ v.outerHTML=voteHTML(w); } }); }
async function setVote(w,value){
  const cur=myVote(w); if(cur===value) return;
  S.myVotes[w.id]=value; w.score=(w.score||0)+value-cur; redrawVotes(w);
  try{ await DB.vote(w.id,value); }
  catch(e){ S.myVotes[w.id]=cur; w.score=(w.score||0)-value+cur; redrawVotes(w); toast(errMsg(e)); }
}
A.vote=el=>{
  if(!requireAuth('votar')) return; const w=work(el.dataset.id); const dir=+el.dataset.dir; const cur=myVote(w);
  setVote(w,cur===dir?0:dir);
  if(navigator.vibrate) try{navigator.vibrate(8)}catch(e){}
};
A.save=async el=>{
  if(!requireAuth('guardar obras')) return; const id=el.dataset.id; const arr=S.saved[S.session]=S.saved[S.session]||[];
  const i=arr.indexOf(id); const on=i<0;
  if(on){ arr.unshift(id); toast('Guardado en tu biblioteca'); } else { arr.splice(i,1); toast('Eliminado de guardados'); }
  closeOverlay(); refresh();
  try{ await DB.setSaved(S.uid,id,on); }catch(e){ if(on) arr.splice(arr.indexOf(id),1); else arr.unshift(id); refresh(); toast(errMsg(e)); }
};
A.share=el=>{ const w=work(el.dataset.id); shareText(w.title, `${FORMATS[w.type].label} de ${user(w.author).name}: ${w.synopsis.slice(0,140)}…`); };
A.unhide=el=>{ const id=el.dataset.id; S.hidden[S.session]=(S.hidden[S.session]||[]).filter(x=>x!==id); refresh(); DB.setHidden(S.uid,id,false).catch(e=>toast(errMsg(e))); };
A.postMenu=el=>{
  const w=work(el.dataset.id); const mine=w.author===S.session;
  showSheet(`
    <button class="opt" data-a="save" data-id="${w.id}">${icon('bookmark')} ${isSaved(w.id)?'Quitar de guardados':'Guardar'}</button>
    <button class="opt" data-a="share" data-id="${w.id}">${icon('share')} Compartir</button>
    ${mine?'':`<button class="opt" data-a="user" data-u="${w.author}">${icon('user')} Ver perfil de ${esc(user(w.author).name.split(' ')[0])}</button>`}
    ${mine?`<button class="opt" data-a="editWork" data-id="${w.id}">${icon('edit')} Editar</button><button class="opt danger" data-a="deleteWork" data-id="${w.id}">${icon('trash')} Eliminar</button>`
    :`<button class="opt" data-a="hide" data-id="${w.id}">${icon('eyeOff')} Ocultar publicación</button><button class="opt danger" data-a="report" data-kind="work" data-id="${w.id}">${icon('flag')} Reportar</button>`}`, esc(w.title));
};
A.hide=el=>{ if(!requireAuth('ocultar publicaciones')) return; const id=el.dataset.id; const arr=S.hidden[S.session]=S.hidden[S.session]||[]; if(!arr.includes(id)) arr.push(id); closeOverlay(); refresh(); toast('Publicación ocultada'); DB.setHidden(S.uid,id,true).catch(e=>toast(errMsg(e))); };
A.editWork=async el=>{ closeOverlay(); const w=work(el.dataset.id); if(!w) return;
  if(['novela','relato','manga','comic'].includes(w.type) && !w.chapters){ toast('Cargando…'); try{ await DB.loadContent(w); }catch(e){ return toast(errMsg(e)); } }
  draft=null; go('create',{editId:w.id}); };
A.deleteWork=el=>{ const id=el.dataset.id; showDialog({title:'¿Eliminar obra?',text:'Esta acción no se puede deshacer. Se eliminarán también sus comentarios.',ok:'Eliminar',danger:true,onOk:async()=>{
  const w=work(id); if(!w) return;
  try{ await DB.deleteWork(w); }catch(e){ return toast(errMsg(e)); }
  S.works=S.works.filter(x=>x.id!==id); while(stack.length>1 && current().params && current().params.id===id) stack.pop(); render(); toast('Obra eliminada'); }}); };
A.overlayBg=()=>closeOverlay();
A.closeOverlay=()=>closeOverlay();
A.dialogOk=()=>{ const f=dialogOk; dialogOk=null; closeOverlay(); if(f) f(); };

/* ---------- reportes ---------- */
let reportCtx=null;
A.report=el=>{
  if(!requireAuth('reportar contenido')) return;
  reportCtx={kind:el.dataset.kind,id:el.dataset.id,parent:el.dataset.parent||null,reason:REPORT_REASONS[0]};
  showSheet(`<p class="small muted" style="padding:0 18px 8px">Tu reporte es anónimo. Moderación lo revisará (revisión humana + filtro automático de lenguaje).</p>${REPORT_REASONS.map((r,i)=>`<button class="radio-row ${i===0?'on':''}" data-a="reportReason" data-v="${esc(r)}"><i></i>${esc(r)}</button>`).join('')}<div style="padding:12px 18px 4px"><textarea class="textarea" id="reportNote" placeholder="Detalles adicionales (opcional)" style="min-height:70px"></textarea><button class="btn btn-red btn-block" style="margin-top:12px" data-a="reportSend">${icon('flag')} Enviar reporte</button></div>`,'Reportar contenido');
};
A.reportReason=el=>{ $$('.radio-row').forEach(r=>r.classList.toggle('on',r===el)); reportCtx.reason=el.dataset.v; };
A.reportSend=async()=>{
  const note=($('#reportNote')||{}).value||''; const ctx=reportCtx;
  closeOverlay();
  try{ await DB.report(S,{...ctx,note}); }catch(e){ return toast(errMsg(e)); }
  if(ctx.kind==='work'){ const arr=S.hidden[S.session]=S.hidden[S.session]||[]; if(!arr.includes(ctx.id)){ arr.push(ctx.id); DB.setHidden(S.uid,ctx.id,true).catch(()=>{}); } }
  refresh();
  showDialog({title:'Gracias por reportar',text:'Ocultamos este contenido para ti. Te avisaremos cuando moderación revise el caso.',ok:'Listo',cancel:''});
};

/* ======================= DETALLE DE OBRA ======================= */
SCREENS.work={ render(p){
  const w=work(p.id); if(!w) return topbar({title:'No encontrado'})+emptyHTML('search','Esta obra ya no existe','Puede que su autor la haya eliminado.');
  const a=user(w.author); const mine=w.author===S.session; const readable=['novela','relato','manga','comic'].includes(w.type);
  const c=community(w.community);
  const hist=S.session&&S.history[S.session]?S.history[S.session][w.id]:null; const readSet=hist?(hist.read||[]):[];
  if(w.comments===null && !w._loadingComments){ w._loadingComments=true; DB.loadComments(S,w).then(()=>{ w._loadingComments=false; const c=current(); if(c.name==='work'&&c.params.id===w.id){ const box=$('#comments'); if(box) box.innerHTML=commentsHTML(w); } },e=>{ w._loadingComments=false; w.comments=[]; toast(errMsg(e)); }); }
  if(isHiddenForMe(w)) return topbar({title:FORMATS[w.type].label})+emptyHTML('eyeOff',w.removed?'Contenido retirado':'Ocultaste esta obra',w.removed?'Moderación retiró este contenido por incumplir las normas.':'La reportaste u ocultaste.',w.removed?'':`<button class="btn btn-ghost" data-a="unhide" data-id="${w.id}">Mostrar de todas formas</button>`);
  const actions=`<button class="icon-btn" data-a="share" data-id="${w.id}">${icon('share')}</button><button class="icon-btn" data-a="postMenu" data-id="${w.id}">${icon('more')}</button>`;
  const where=c?`en <span class="gold" data-a="comm" data-id="${c.id}">c/${esc(c.id)}</span> · `:'';
  let hero='';
  if(w.type==='foro'){
    hero=`<div class="pad"><div class="row" style="margin-bottom:10px">${avatarHTML(a)}<div class="grow" data-a="user" data-u="${a.username}"><b>${nameHTML(a.username)}</b><div class="tiny muted">${where}${timeAgo(w.created)}</div></div>${followBtn(a.username)}</div>
      ${fmtTag('foro')}<div class="h2" style="margin:10px 0 8px">${esc(w.title)}</div><p style="font-size:16px;white-space:pre-wrap;line-height:1.5">${esc(w.synopsis)}</p>
      <div class="row" style="margin-top:14px">${voteHTML(w)}<button class="pa ${isSaved(w.id)?'on':''}" data-a="save" data-id="${w.id}">${icon('bookmark',isSaved(w.id)?'fill="currentColor"':'')} Guardar</button><span class="spacer"></span><span class="tiny muted">${fmtNum(w.views)} vistas</span></div></div>`;
  }else if(w.type==='video'){
    hero=`<div class="video-box">${w.video&&w.video.url?`<video src="${w.video.url}" ${w.video.poster?`poster="${w.video.poster}"`:''} controls playsinline preload="metadata"></video>`:videoThumbHTML(w)}</div>
      <div class="pad">${fmtTag('video')} ${w.mature?'<span class="tag red">+18</span>':''}<div class="h2" style="margin:8px 0 10px">${esc(w.title)}</div>
      <div class="row" style="margin-bottom:12px">${avatarHTML(a,'av-sm')}<div class="grow" data-a="user" data-u="${a.username}"><b>${nameHTML(a.username)}</b><div class="tiny muted">${where}${timeAgo(w.created)}</div></div>${followBtn(a.username)}</div>
      <div class="row">${voteHTML(w)}<button class="pa ${isSaved(w.id)?'on':''}" data-a="save" data-id="${w.id}">${icon('bookmark',isSaved(w.id)?'fill="currentColor"':'')} Guardar</button><span class="spacer"></span><span class="tiny muted">${fmtNum(w.views)} vistas</span></div>
      <div class="section-label"><span>Descripción</span></div><p style="white-space:pre-wrap">${esc(w.synopsis)}</p>
      <div class="chips wrap" style="margin-top:10px">${(w.genres||[]).map(g=>`<span class="tag gray">${esc(g)}</span>`).join('')}</div></div>`;
  }else if(w.type==='ilustracion'){
    hero=`<button class="post-wide" style="padding:0;width:100%" data-a="viewArt" data-id="${w.id}"><div class="art" style="border-radius:0;aspect-ratio:4/3">${artHTML(w)}</div></button>
      <div class="pad">${fmtTag('ilustracion')} ${w.mature?'<span class="tag red">+18</span>':''}<div class="h2" style="margin:8px 0 10px">${esc(w.title)}</div>
      <div class="row" style="margin-bottom:12px">${avatarHTML(a,'av-sm')}<div class="grow" data-a="user" data-u="${a.username}"><b>${nameHTML(a.username)}</b><div class="tiny muted">${where}${timeAgo(w.created)}</div></div>${followBtn(a.username)}</div>
      <div class="row">${voteHTML(w)}<button class="pa ${isSaved(w.id)?'on':''}" data-a="save" data-id="${w.id}">${icon('bookmark',isSaved(w.id)?'fill="currentColor"':'')} Guardar</button><span class="spacer"></span><span class="tiny muted">${fmtNum(w.views)} vistas</span></div>
      <div class="section-label"><span>Descripción</span></div><p style="white-space:pre-wrap">${esc(w.synopsis)}</p>
      <div class="chips wrap" style="margin-top:10px">${(w.genres||[]).map(g=>`<span class="tag gray">${esc(g)}</span>`).join('')}</div></div>`;
  }else{
    hero=`<div class="work-hero"><div class="bgblur">${coverHTML(w)}</div><div class="cover">${coverHTML(w)}</div><div class="grow" style="padding-top:4px">${fmtTag(w.type)} ${w.mature?'<span class="tag red">+18</span>':''}<div class="h2" style="margin:8px 0">${esc(w.title)}</div>
      <button class="row" style="gap:8px" data-a="user" data-u="${a.username}">${avatarHTML(a,'av-xs')}<b class="small">${nameHTML(a.username)}</b></button>
      <div class="chips wrap" style="margin-top:10px;gap:5px">${(w.genres||[]).map(g=>`<span class="tag gray">${esc(g)}</span>`).join('')}</div>
      <div class="tiny faint row" style="margin-top:8px;gap:4px">${icon('shield','width="12" height="12"')} ${esc(w.license)}</div></div></div>
      <div class="pad" style="padding-top:4px">
      <div class="stats"><div class="stat"><b>${fmtNum(score(w))}</b><span>Votos</span></div><div class="stat"><b>${fmtNum(w.views)}</b><span>Lecturas</span></div><div class="stat"><b>${chaptersOf(w).length}</b><span>Capítulos</span></div><div class="stat"><b>${commentCount(w)}</b><span>Coment.</span></div></div>
      <div class="row" style="margin-top:12px">${voteHTML(w)}<button class="pa ${isSaved(w.id)?'on':''}" data-a="save" data-id="${w.id}">${icon('bookmark',isSaved(w.id)?'fill="currentColor"':'')} ${isSaved(w.id)?'Guardado':'Guardar'}</button><span class="spacer"></span>${followBtn(a.username)}</div>
      <div class="section-label"><span>Sinopsis</span></div><p style="white-space:pre-wrap;line-height:1.5">${esc(w.synopsis)}</p>
      <div class="section-label"><span>Capítulos</span>${mine?`<button data-a="editWork" data-id="${w.id}">+ Añadir</button>`:''}</div>
      <div class="list">${chaptersOf(w).map((ch,i)=>`<button class="chapter ${readSet.includes(i)?'read':''}" data-a="read" data-id="${w.id}" data-ch="${i}"><span class="n">${readSet.includes(i)?icon('check','width="16" height="16"'):i+1}</span><span class="grow"><b class="ellipsis" style="display:block">${esc(ch.title||'Capítulo '+(i+1))}</b><span class="tiny muted">${ch.pages!=null&&ch.pages!==undefined?(Array.isArray(ch.pages)?ch.pages.length:ch.pages)+' páginas':Math.max(1,Math.round((ch.words!=null?ch.words:wordCount(ch.text))/200))+' min de lectura'}</span></span>${icon('chevR','width="20" height="20" style="color:var(--faint)"')}</button>`).join('')||'<div class="pad small muted">Aún no hay capítulos.</div>'}</div></div>`;
  }
  const creditsHTML=`<div class="pad" style="padding-top:0"><div class="section-label"><span>Créditos</span></div><div class="list" style="padding:4px 14px">${[{user:w.author,role:'Autor/a principal'},...(w.credits||[])].map(cr=>`<button class="credit" style="width:100%;text-align:left" data-a="user" data-u="${cr.user}">${avatarHTML(cr.user,'av-sm')}<span class="grow"><b>${nameHTML(cr.user)}</b><span class="tiny muted" style="display:block">@${esc(cr.user)}</span></span><span class="tag">${esc(cr.role)}</span></button>`).join('')}</div></div>`;
  return `${topbar({title:fmtLabel(w.type),actions})}
  <div class="scroll" style="padding-bottom:20px">${hero}${w.type!=='foro'?creditsHTML:''}
  <div class="pad" id="comments" style="padding-top:0">${commentsHTML(w)}</div></div>
  ${readable&&w.status==='publicado'?`<div class="sticky-cta"><button class="btn btn-primary grow" data-a="read" data-id="${w.id}" data-ch="${hist?hist.ch:0}">${icon('book')} ${hist?`Continuar · Cap. ${hist.ch+1}`:'Empezar a leer'}</button><button class="btn btn-ghost" data-a="focusComment" aria-label="Comentar">${icon('comment')}</button></div>`:''}
  ${w.status==='publicado'?composerHTML(w,!readable):''}`;
}, after(p){ if(p.focus==='comments'){ const c=$('#comments'); if(c) c.scrollIntoView(); p.focus=''; } } };
function followBtn(u){ if(u===S.session||!S.users[u]) return ''; const f=isFollowing(u); return `<button class="btn btn-sm ${f?'btn-ghost':'btn-outline'}" data-a="follow" data-u="${u}">${f?'Siguiendo':'+ Seguir'}</button>`; }
function commentsHTML(w){
  if(w.comments===null) return `<div class="section-label"><span>Comentarios (${commentCount(w)})</span></div><div class="empty" style="padding:20px"><div class="spinner"></div></div>`;
  const list=[...(w.comments||[])].sort(UI.commentSort==='top'?(a,b)=>(b.likeCount||0)-(a.likeCount||0):(a,b)=>b.time-a.time);
  return `<div class="section-label"><span>Comentarios (${commentCount(w)})</span><div class="row" style="gap:4px"><button class="${UI.commentSort==='top'?'':'faint'}" data-a="cSort" data-v="top">Top</button>·<button class="${UI.commentSort==='new'?'':'faint'}" data-a="cSort" data-v="new">Recientes</button></div></div>
  ${list.length?list.map(c=>commentHTML(w,c)).join(''):`<div class="empty" style="padding:20px">${icon('comment','class="empty-ic" style="width:34px;height:34px"')}<div class="small">Sé el primero en dejar feedback.</div></div>`}`;
}
function commentHTML(w,c,parent){
  const liked=!!c.liked;
  const hidden=S.session && S.reports.some(r=>r.kind==='comment'&&r.id===c.id&&r.by===S.session);
  if(hidden) return `<div class="comment"><span class="small faint row" style="gap:6px">${icon('eyeOff','width="14" height="14"')} Comentario reportado y oculto.</span></div>`;
  if(c.removed) return `<div class="comment"><span class="small faint">Comentario retirado por moderación.</span></div>`;
  return `<div class="comment ${c.pending?'pending':''}">${avatarHTML(c.user,'av-sm')}<div class="body"><div class="meta"><b data-a="user" data-u="${c.user}">${nameHTML(c.user)}</b>${c.user===w.author?'<span class="tag" style="padding:0 5px;font-size:10px">Autor</span> ':''}· ${c.pending?'enviando…':timeAgo(c.time)}</div><p>${esc(c.text)}</p>
  <div class="acts"><button class="${liked?'on':''}" data-a="likeComment" data-w="${w.id}" data-c="${c.id}" data-p="${parent||''}">${icon('heart',liked?'fill="currentColor"':'')} ${c.likeCount||''}</button>${parent?'':`<button data-a="replyComment" data-c="${c.id}" data-u="${c.user}">${icon('comment')} Responder</button>`}<button data-a="commentMenu" data-w="${w.id}" data-c="${c.id}" data-p="${parent||''}">${icon('more')}</button></div>
  ${(c.replies||[]).length?`<div class="replies">${c.replies.map(r=>commentHTML(w,r,c.id)).join('')}</div>`:''}</div></div>`;
}
function composerHTML(w,visible){
  return `<div id="composerWrap" style="${visible?'':'display:none'}">${UI.replyTo?`<div class="reply-to">${icon('comment','width="14" height="14"')} Respondiendo a <b>@${esc(UI.replyTo.u)}</b><span class="spacer"></span><button data-a="cancelReply">${icon('x','width="16" height="16"')}</button></div>`:''}<form class="composer" data-f="comment" data-id="${w.id}"><textarea name="text" rows="1" placeholder="${S.session?'Escribe un comentario constructivo…':'Inicia sesión para comentar'}" maxlength="1000"></textarea><button class="send-btn" aria-label="Enviar">${icon('send')}</button></form></div>`;
}
A.cSort=el=>{ UI.commentSort=el.dataset.v; const w=work(current().params.id); $('#comments').innerHTML=commentsHTML(w); };
A.focusComment=()=>{ if(!requireAuth('comentar')) return; const cw=$('#composerWrap'); cw.style.display=''; const st=$('.sticky-cta'); if(st) st.style.display='none'; $('textarea',cw).focus(); };
A.replyComment=el=>{ if(!requireAuth('responder')) return; UI.replyTo={c:el.dataset.c,u:el.dataset.u}; const w=work(current().params.id); $('#composerWrap').outerHTML=composerHTML(w,true); const st=$('.sticky-cta'); if(st) st.style.display='none'; $('#composerWrap textarea').focus(); };
A.cancelReply=()=>{ UI.replyTo=null; const w=work(current().params.id); $('#composerWrap').outerHTML=composerHTML(w,true); };
function findComment(w,cid,pid){ if(!w.comments) return null; if(pid){ const p=w.comments.find(c=>c.id===pid); return p&&(p.replies||[]).find(r=>r.id===cid); } return w.comments.find(c=>c.id===cid); }
function redrawComments(w){ const c=current(); if(c.name==='work'&&c.params.id===w.id){ const box=$('#comments'); if(box) box.innerHTML=commentsHTML(w); } }
A.likeComment=async el=>{ if(!requireAuth('dar me gusta')) return; const w=work(el.dataset.w); const c=findComment(w,el.dataset.c,el.dataset.p); if(!c||c.pending) return;
  const on=!c.liked; c.liked=on; c.likeCount=Math.max(0,(c.likeCount||0)+(on?1:-1)); redrawComments(w);
  try{ await DB.setCommentLike(S.uid,c.id,on); }catch(e){ c.liked=!on; c.likeCount=Math.max(0,c.likeCount+(on?-1:1)); redrawComments(w); toast(errMsg(e)); } };
A.commentMenu=el=>{ const w=work(el.dataset.w); const c=findComment(w,el.dataset.c,el.dataset.p); const mine=c.user===S.session;
  showSheet(`${mine||w.author===S.session?`<button class="opt danger" data-a="delComment" data-w="${w.id}" data-c="${c.id}" data-p="${el.dataset.p}">${icon('trash')} Eliminar comentario</button>`:''}${mine?'':`<button class="opt danger" data-a="report" data-kind="comment" data-id="${c.id}" data-parent="${w.id}">${icon('flag')} Reportar comentario</button>`}<button class="opt" data-a="user" data-u="${c.user}">${icon('user')} Ver perfil</button>`); };
A.delComment=async el=>{ const w=work(el.dataset.w); closeOverlay();
  try{ await DB.deleteComment(el.dataset.c); }catch(e){ return toast(errMsg(e)); }
  const n=el.dataset.p?1:1+((findComment(w,el.dataset.c,'')||{}).replies||[]).length;
  if(el.dataset.p){ const p=w.comments.find(c=>c.id===el.dataset.p); p.replies=p.replies.filter(r=>r.id!==el.dataset.c); } else w.comments=w.comments.filter(c=>c.id!==el.dataset.c);
  w.commentCount=Math.max(0,(w.commentCount||0)-n); redrawComments(w); toast('Comentario eliminado'); };
F.comment=form=>{
  if(!requireAuth('comentar')) return; const ta=$('textarea',form); const text=ta.value.trim(); if(!text) return;
  const w=work(form.dataset.id); if(!w.comments) w.comments=[];
  const post=async(flagged)=>{
    const reply=UI.replyTo; const tmp={id:'tmp'+Date.now(),user:S.session,text,time:Date.now(),likeCount:0,liked:false,replies:[],pending:true};
    let parent=null;
    if(reply){ parent=w.comments.find(x=>x.id===reply.c); if(parent) (parent.replies=parent.replies||[]).push(tmp); } else w.comments.push(tmp);
    w.commentCount=(w.commentCount||0)+1;
    UI.replyTo=null; ta.value=''; redrawComments(w); $('#composerWrap').outerHTML=composerHTML(w,true);
    try{
      const row=await DB.addComment(w.id,text,parent?parent.id:null,flagged);
      Object.assign(tmp,{id:row.id,time:new Date(row.created_at).getTime(),pending:false});
      if(flagged) DB.report(S,{kind:'comment',id:row.id,parent:w.id,reason:'Posible lenguaje ofensivo (detección automática)',note:text,auto:true}).catch(()=>{});
      toast('Comentario publicado');
    }catch(e){
      if(parent) parent.replies=parent.replies.filter(r=>r!==tmp); else w.comments=w.comments.filter(r=>r!==tmp);
      w.commentCount=Math.max(0,w.commentCount-1); toast(errMsg(e)); const t2=$('#composerWrap textarea'); if(t2) t2.value=text;
    }
    redrawComments(w);
  };
  if(isToxic(text)) showDialog({title:'Revisión automática',html:`<div class="mod-flag" style="margin-top:8px">${icon('triangle-alert')}<span>Nuestro sistema detectó lenguaje que podría ser ofensivo. CHOGGUN es un espacio de feedback respetuoso.</span></div><p style="margin-top:10px">Si lo publicas, será enviado a revisión humana.</p>`,ok:'Publicar igual',cancel:'Editar',onOk:()=>post(true)});
  else post(false);
};
A.follow=async el=>{
  if(!requireAuth('seguir creadores')) return; const u=el.dataset.u; const t=S.users[u]; if(!t) return; const m=me();
  const on=!isFollowing(u);
  if(on){ S.following.push(u); t.followerCount=(t.followerCount||0)+1; m.followingCount=(m.followingCount||0)+1; toast(`Ahora sigues a ${t.name}`); }
  else { S.following=S.following.filter(x=>x!==u); t.followerCount=Math.max(0,(t.followerCount||0)-1); m.followingCount=Math.max(0,(m.followingCount||0)-1); toast(`Dejaste de seguir a ${t.name}`); }
  refresh();
  try{ await DB.setFollow(S.uid,t.id,on); }catch(e){ if(on) S.following=S.following.filter(x=>x!==u); else S.following.push(u); toast(errMsg(e)); refresh(); }
};
A.viewArt=el=>{ const w=work(el.dataset.id); $('#overlay').innerHTML=`<div class="overlay center" data-a="overlayBg" style="background:rgba(0,0,0,.94);padding:0"><button class="icon-btn" data-a="closeOverlay" style="position:absolute;top:calc(10px + var(--safe-top));right:10px;color:#fff;z-index:2">${icon('x')}</button><div style="width:100%" data-a="overlayBg">${artHTML(w).replace('<svg','<svg style="width:100%;height:auto"')}</div></div>`; };

/* ======================= LECTOR ======================= */
SCREENS.read={ noNav:true, cls:'reader', render(p){
  const w=work(p.id); if(!w||!w.chapters||!w.chapters.length) return topbar({title:'Lector'})+emptyHTML('book','No se pudo abrir','Vuelve a intentarlo.'); const ch=Math.min(+p.ch||0,w.chapters.length-1); const c=w.chapters[ch];
  const actions=`<button class="icon-btn" data-a="readerList" aria-label="Capítulos">${icon('list')}</button>${c.pages?'':`<button class="icon-btn" data-a="readerSettings" aria-label="Ajustes de lectura">${icon('type')}</button>`}`;
  const content=c.pages?`<div class="reader-pages">${c.pages.map((pg,i)=>`<div class="page"><img src="${pg}" alt="Página ${i+1}" loading="lazy"></div>`).join('')}</div>`
    :`<article class="reader-text" style="--rsize:${S.settings.readerSize}px"><h2>${esc(c.title||'Capítulo '+(ch+1))}</h2><div class="by">${esc(w.title)} · ${esc(user(w.author).name)}</div>${String(c.text||'').split(/\n\s*\n/).map(par=>`<p>${esc(par.trim()).replace(/\n/g,'<br>')}</p>`).join('')}</article>`;
  const next=ch<w.chapters.length-1, prev=ch>0, v=myVote(w);
  return `${topbar({title:`<span class="small" style="font-family:var(--font-body);text-transform:none;letter-spacing:0;font-weight:700">${esc(c.title||'Capítulo '+(ch+1))}</span>`,actions})}<div class="reader-progress"><i id="rprog"></i></div>
  <div class="scroll" id="rscroll">${content}
   <div class="reader-end" style="${c.pages?'background:#111;color:#ddd':''}"><div class="h3" style="margin-bottom:6px">Fin del capítulo ${ch+1}</div><p class="small" style="opacity:.7;margin-bottom:16px">¿Te gustó? Tu voto ayuda a que más lectores descubran esta obra.</p>
   <div class="row" style="justify-content:center;gap:10px;margin-bottom:16px"><button class="btn btn-sm ${v>0?'btn-primary':'btn-ghost'}" data-a="readerVote" data-id="${w.id}">${icon('up')} ${v>0?'Votado':'Votar'}</button><button class="btn btn-sm btn-ghost" data-a="readerComment" data-id="${w.id}">${icon('comment')} Comentar</button><button class="btn btn-sm btn-ghost" data-a="share" data-id="${w.id}">${icon('share')}</button></div>
   <div class="row" style="justify-content:center;gap:10px">${prev?`<button class="btn btn-ghost" data-a="read" data-id="${w.id}" data-ch="${ch-1}" data-replace="1">${icon('back')} Anterior</button>`:''}${next?`<button class="btn btn-primary" data-a="read" data-id="${w.id}" data-ch="${ch+1}" data-replace="1">Siguiente ${icon('chevR')}</button>`:`<div class="small" style="opacity:.7">Estás al día. Sigue al autor para enterarte del próximo capítulo.</div>`}</div></div></div>`;
}, after(p){
  const scr=$('#view .screen'); scr.classList.add('r-'+S.settings.readerTheme);
  const w=work(p.id); if(!w||!w.chapters) return; const ch=Math.min(+p.ch||0,w.chapters.length-1); const sc=$('#rscroll'); const bar=$('#rprog');
  const hist=S.session?(S.history[S.session]=S.history[S.session]||{}):null;
  if(hist){ const h=hist[w.id]=hist[w.id]||{ch:0,pct:0,read:[]}; h.ch=ch; h.t=Date.now(); if(h.pctCh!==ch) h.pct=0; h.pctCh=ch; DB.saveHistory(w.id,h); }
  let ticking=false;
  // Capítulo corto que cabe en pantalla: cuenta como leído sin necesidad de desplazarse.
  if(hist && sc.scrollHeight-sc.clientHeight<=4){ const h=hist[w.id]; h.pct=1; bar.style.width='100%'; if(!h.read.includes(ch)) h.read.push(ch); DB.saveHistory(w.id,h); }
  sc.addEventListener('scroll',()=>{ if(ticking) return; ticking=true; requestAnimationFrame(()=>{ ticking=false; const max=sc.scrollHeight-sc.clientHeight; const pct=max>0?sc.scrollTop/max:1; bar.style.width=(pct*100)+'%';
    if(hist){ const h=hist[w.id]; h.pct=pct; if(pct>.9 && !h.read.includes(ch)){ h.read.push(ch); } DB.saveHistory(w.id,h); } }); },{passive:true});
} };
A.read=async el=>{ const w=work(el.dataset.id); if(!w) return; if(!chaptersOf(w).length) return toast('Esta obra aún no tiene capítulos');
  if(!w.chapters){ toast('Abriendo…'); try{ await DB.loadContent(w); }catch(e){ return toast(errMsg(e)); } }
  if(!w.chapters.length) return toast('Esta obra aún no tiene capítulos');
  closeOverlay(); const p={id:w.id,ch:+el.dataset.ch||0}; if(el.dataset.replace||current().name==='read') replace('read',p); else go('read',p); };
A.readerVote=el=>{ if(!requireAuth('votar')) return; const w=work(el.dataset.id); if(myVote(w)===1) return; setVote(w,1); el.className='btn btn-sm btn-primary'; el.innerHTML=icon('up')+' Votado'; toast('Gracias por tu voto'); };
A.readerComment=el=>{ stack.pop(); if(current().name==='work'){ current().params.focus='comments'; navAnim=false; render(); } else go('work',{id:el.dataset.id,focus:'comments'}); };
A.readerList=()=>{ const p=current().params; const w=work(p.id); showSheet(`<div class="list" style="margin:0 14px">${w.chapters.map((c,i)=>`<button class="chapter" data-a="read" data-id="${w.id}" data-ch="${i}" data-replace="1"><span class="n" style="${i===+p.ch?'background:var(--gold);color:#1d1405':''}">${i+1}</span><span class="grow ellipsis"><b>${esc(c.title||'Capítulo '+(i+1))}</b></span></button>`).join('')}</div>`,'Capítulos'); };
A.readerSettings=()=>{ const s=S.settings; showSheet(`<div style="padding:0 18px 8px"><div class="field"><span>Tamaño del texto · <b id="rsv">${s.readerSize}px</b></span><div class="row"><span class="small">A</span><input type="range" min="14" max="26" value="${s.readerSize}" data-i="readerSize"><span style="font-size:22px">A</span></div></div>
  <div class="field"><span>Fondo</span><div class="seg">${[['sepia','Sepia'],['light','Claro'],['dark','Oscuro']].map(([k,l])=>`<button class="${s.readerTheme===k?'on':''}" data-a="readerTheme" data-v="${k}">${l}</button>`).join('')}</div></div></div>`,'Ajustes de lectura'); };
I.readerSize=el=>{ S.settings.readerSize=+el.value; $('#rsv').textContent=el.value+'px'; const a=$('.reader-text'); if(a) a.style.setProperty('--rsize',el.value+'px'); save(); };
A.readerTheme=el=>{ S.settings.readerTheme=el.dataset.v; save(); const scr=$('#view .screen'); scr.classList.remove('r-sepia','r-light','r-dark'); scr.classList.add('r-'+el.dataset.v); $$('.seg button',$('#overlay')).forEach(b=>b.classList.toggle('on',b===el)); };

/* ======================= EXPLORAR ======================= */
function memberCount(cid){ const c=community(cid); return c?c.memberCount||0:0; }
SCREENS.explore={ render(){
  return `${topbar({back:false,title:'Explorar',actions:`<button class="icon-btn" data-a="createComm" aria-label="Crear comunidad">${icon('plus')}</button>`})}
  <div class="pad" style="padding-bottom:6px"><div class="searchbar">${icon('search')}<input id="exploreQ" placeholder="Buscar obras, comunidades, personas…" value="${esc(UI.exploreQ)}" data-i="exploreQ" autocomplete="off" enterkeyhint="search">${UI.exploreQ?`<button data-a="clearSearch">${icon('x')}</button>`:''}</div></div>
  <div class="scroll pb-nav"><div class="pad" id="exploreBody" style="padding-top:8px">${exploreBody()}</div></div>`; } };
function exploreBody(){
  const q=normalize(UI.exploreQ.trim());
  if(q){
    const f=UI.exploreFilter;
    const works=visibleWorks().filter(w=>normalize(w.title+' '+w.synopsis+' '+(w.genres||[]).join(' ')+' '+user(w.author).name+' '+FORMATS[w.type].label).includes(q)).sort((a,b)=>score(b)-score(a));
    const comms=S.communities.filter(c=>normalize(c.name+' '+c.id+' '+c.desc+' '+c.cat).includes(q));
    const users=Object.values(S.users).filter(u=>normalize(u.name+' '+u.username+' '+u.role+' '+(u.genres||[]).join(' ')).includes(q));
    const chips=`<div class="chips" style="margin-bottom:12px">${[['all','Todo'],['works',`Obras (${works.length})`],['comms',`Comunidades (${comms.length})`],['users',`Personas (${users.length})`]].map(([k,l])=>`<button class="chip ${f===k?'on':''}" data-a="exploreFilter" data-k="${k}">${l}</button>`).join('')}</div>`;
    let out='';
    if((f==='all'||f==='users')&&users.length) out+=`<div class="section-label"><span>Personas</span></div><div class="list" style="margin-bottom:6px">${users.slice(0,f==='all'?4:50).map(u=>`<button class="li" data-a="user" data-u="${u.username}">${avatarHTML(u)}<span class="txt"><b>${nameHTML(u.username)}</b><span>@${esc(u.username)} · ${esc(u.role)}</span></span>${icon('chevR','class="chev"')}</button>`).join('')}</div>`;
    if((f==='all'||f==='comms')&&comms.length) out+=`<div class="section-label"><span>Comunidades</span></div><div class="list" style="margin-bottom:6px">${comms.slice(0,f==='all'?4:50).map(commRow).join('')}</div>`;
    if((f==='all'||f==='works')&&works.length) out+=`<div class="section-label"><span>Obras y publicaciones</span></div>${works.slice(0,f==='all'?6:60).map(postCard).join('')}`;
    return chips+(out||emptyHTML('search','Sin resultados',`No encontramos nada para “${esc(UI.exploreQ)}”.`));
  }
  const trend=visibleWorks().sort((a,b)=>hot(b)-hot(a)).slice(0,5);
  const cats=COMMUNITY_CATS.filter(cat=>S.communities.some(c=>c.cat===cat));
  const people=Object.values(S.users).filter(u=>u.username!==S.session);
  return `${trend.length?`<div class="section-label"><span>Tendencias</span></div><div class="list">${trend.map((w,i)=>`<button class="li" data-a="open" data-id="${w.id}"><span class="rank ${i===0?'r1':''}">#${i+1}</span><span class="txt"><b class="ellipsis">${esc(w.title)}</b><span>${FORMATS[w.type].label} · ${esc(user(w.author).name)}</span></span><span class="tag">${icon('up','width="12" height="12"')} ${fmtNum(score(w))}</span></button>`).join('')}</div>`:''}
  <div class="section-label"><span>Comunidades</span><button data-a="createComm">+ Crear</button></div>
  ${S.communities.length?cats.map(cat=>`<div class="tiny faint" style="font-weight:700;letter-spacing:.12em;text-transform:uppercase;margin:12px 0 8px">${esc(cat)}</div><div class="comm-grid">${S.communities.filter(c=>c.cat===cat).map(commTile).join('')}</div>`).join('')
    :`<div class="card">${emptyHTML('users','Aún no hay comunidades','Crea la primera comunidad de CHOGGUN e invita a otros creadores.',`<button class="btn btn-primary btn-sm" data-a="createComm">${icon('plus')} Crear comunidad</button>`)}</div>`}
  ${people.length?`<div class="section-label"><span>Personas en CHOGGUN</span></div><div class="list">${people.slice(0,12).map(u=>`<button class="li" data-a="user" data-u="${u.username}">${avatarHTML(u)}<span class="txt"><b>${nameHTML(u.username)}</b><span>@${esc(u.username)} · ${esc(u.role)}</span></span>${icon('chevR','class="chev"')}</button>`).join('')}</div>`:''}
  <div class="section-label"><span>Géneros</span></div><div class="chips wrap">${GENRES.map(g=>`<button class="chip" data-a="searchFor" data-q="${esc(g)}">${esc(g)}</button>`).join('')}</div>`;
}
function commIcon(c,size=40){ return `<span class="comm-icon" style="background:${c.color}22;color:${c.color};width:${size}px;height:${size}px">${icon(c.icon,`width="${Math.round(size*.52)}" height="${Math.round(size*.52)}"`)}</span>`; }
function commRow(c){ return `<button class="li" data-a="comm" data-id="${c.id}">${commIcon(c)}<span class="txt"><b>c/${esc(c.id)}</b><span>${memberCount(c.id)} ${memberCount(c.id)===1?'miembro':'miembros'} · ${esc(c.cat)}</span></span>${isJoined(c.id)?'<span class="tag green">Unido</span>':icon('chevR','class="chev"')}</button>`; }
function commTile(c){ const j=isJoined(c.id); return `<div class="comm-tile" data-a="comm" data-id="${c.id}"><div class="row between">${commIcon(c,46)}<button class="btn btn-sm ${j?'btn-ghost':'btn-primary'}" style="height:30px;padding:0 10px;font-size:12px" data-a="join" data-id="${c.id}">${j?'Unido':'Unirse'}</button></div><b>${esc(c.name)}</b><span class="tiny muted clamp2">${esc(c.desc)}</span><span class="tiny faint">${memberCount(c.id)} ${memberCount(c.id)===1?'miembro':'miembros'}</span></div>`; }
I.exploreQ=el=>{ UI.exploreQ=el.value; $('#exploreBody').innerHTML=exploreBody(); const bar=el.parentElement; const has=bar.querySelector('[data-a=clearSearch]'); if(UI.exploreQ&&!has) bar.insertAdjacentHTML('beforeend',`<button data-a="clearSearch">${icon('x')}</button>`); if(!UI.exploreQ&&has) has.remove(); };
A.clearSearch=()=>{ UI.exploreQ=''; UI.exploreFilter='all'; refresh(); };
A.exploreFilter=el=>{ UI.exploreFilter=el.dataset.k; $('#exploreBody').innerHTML=exploreBody(); };
A.searchFor=el=>{ UI.exploreQ=el.dataset.q; if(current().name!=='explore') setTab('explore'); else refresh(); };
A.join=async el=>{
  if(!requireAuth('unirte a comunidades')) return; const id=el.dataset.id; const arr=S.joined[S.session]=S.joined[S.session]||[]; const c=community(id);
  const on=!arr.includes(id);
  if(on){ arr.push(id); if(c) c.memberCount++; toast(`Te uniste a c/${id}`); } else { S.joined[S.session]=arr.filter(x=>x!==id); if(c) c.memberCount=Math.max(0,c.memberCount-1); toast(`Saliste de c/${id}`); }
  refresh();
  try{ await DB.setJoined(S.uid,id,on); }catch(e){ toast(errMsg(e)); }
};
A.createComm=()=>{ if(!requireAuth('crear comunidades')) return; go('createCommunity'); };

/* ======================= COMUNIDAD ======================= */
SCREENS.community={ render(p){
  const c=community(p.id); if(!c) return topbar({title:'Comunidad'})+emptyHTML('search','Esta comunidad no existe','Puede que haya sido eliminada.');
  const j=isJoined(c.id); const mine=c.owner===S.session;
  let list=visibleWorks().filter(w=>w.community===c.id); list.sort(UI.commTab==='nuevo'?(a,b)=>b.created-a.created:(a,b)=>hot(b)-hot(a));
  return `${topbar({title:'c/'+esc(c.id),actions:`<button class="icon-btn" data-a="shareComm" data-id="${c.id}">${icon('share')}</button>${mine?`<button class="icon-btn" data-a="deleteComm" data-id="${c.id}">${icon('trash')}</button>`:''}`})}
  <div class="scroll" style="padding-bottom:100px"><div class="comm-hero" style="--hero:linear-gradient(135deg,${c.color}55,var(--bg2))"><div class="row" style="gap:14px">${commIcon(c,64)}<div class="grow"><div class="h2">${esc(c.name)}</div><div class="small muted">c/${esc(c.id)} · ${memberCount(c.id)} ${memberCount(c.id)===1?'miembro':'miembros'} ${c.private?'· Privada':''}</div></div></div>
  <p style="margin:12px 0">${esc(c.desc)}</p><div class="row"><button class="btn ${j?'btn-ghost':'btn-primary'} btn-sm" data-a="join" data-id="${c.id}">${j?'Unido':'Unirse'}</button><button class="btn btn-sm btn-ghost" data-a="rules">${icon('shield')} Normas</button></div>
  ${c.owner?`<div class="tiny muted row" style="margin-top:10px;gap:6px">${avatarHTML(c.owner,'av-xs')} Creada por <b data-a="user" data-u="${c.owner}">${nameHTML(c.owner)}</b></div>`:''}</div>
  <div class="tabs">${[['popular','Popular'],['nuevo','Nuevo']].map(([k,l])=>`<button class="tab ${UI.commTab===k?'on':''}" data-a="commTab" data-k="${k}">${l}</button>`).join('')}</div>
  <div class="pad">${list.length?list.map(postCard).join(''):emptyHTML(c.icon,'Comunidad nueva','Todavía no hay publicaciones. ¡Sé el primero en publicar aquí!')}</div></div>
  <button class="fab" style="bottom:calc(20px + var(--safe-bottom))" data-a="create" data-comm="${c.id}" aria-label="Publicar en esta comunidad">${icon('plus')}</button>`; } };
A.commTab=el=>{ UI.commTab=el.dataset.k; refresh(); };
A.shareComm=el=>{ const c=community(el.dataset.id); shareText(`c/${c.id} en CHOGGUN`,c.desc); };
A.deleteComm=el=>{ const id=el.dataset.id; showDialog({title:'¿Eliminar comunidad?',text:'Las publicaciones seguirán existiendo en el perfil de sus autores.',ok:'Eliminar',danger:true,onOk:async()=>{
  try{ await DB.deleteCommunity(id); }catch(e){ return toast(errMsg(e)); }
  S.communities=S.communities.filter(c=>c.id!==id); S.works.forEach(w=>{ if(w.community===id) w.community=''; }); Object.keys(S.joined).forEach(k=>S.joined[k]=(S.joined[k]||[]).filter(x=>x!==id)); back(); toast('Comunidad eliminada'); }}); };

SCREENS.createCommunity={ render(){
  return `${topbar({title:'Crear comunidad'})}<div class="scroll"><form class="pad" data-f="community" novalidate>
  <div class="field"><span>Icono</span><div class="icon-pick" data-single="icon">${COMMUNITY_ICONS.map((ic,i)=>`<button type="button" class="${i===0?'on':''}" data-a="iconPick" data-v="${ic}">${icon(ic)}</button>`).join('')}</div><input type="hidden" name="icon" value="${COMMUNITY_ICONS[0]}"></div>
  <label class="field"><span>Nombre</span><div class="input-wrap"><span style="position:absolute;left:14px;top:50%;transform:translateY(-50%);font-weight:800;color:var(--gold)">c/</span><input class="input" name="name" placeholder="mi_comunidad" maxlength="24" autocapitalize="off" style="padding-left:38px"></div><div class="hint">Letras minúsculas, números o _ (3–24). No se puede cambiar después.</div></label>
  <label class="field"><span>Descripción</span><textarea class="textarea" name="desc" placeholder="¿De qué trata tu comunidad?" maxlength="200"></textarea></label>
  <label class="field"><span>Categoría</span><select class="select" name="cat">${COMMUNITY_CATS.map(c=>`<option>${c}</option>`).join('')}</select></label>
  <div class="field"><span>Privacidad</span><div class="seg" data-single="priv"><button type="button" class="on" data-a="segSingle" data-v="publica">${icon('globe')} Pública</button><button type="button" data-a="segSingle" data-v="privada">${icon('lock')} Privada</button></div><input type="hidden" name="priv" value="publica"></div>
  <div class="err" data-err style="margin-bottom:10px"></div><button class="btn btn-primary btn-block">Crear comunidad</button></form></div>`; } };
A.iconPick=el=>{ const box=el.closest('[data-single]'); $$('button',box).forEach(b=>b.classList.toggle('on',b===el)); box.parentElement.querySelector('input[name=icon]').value=el.dataset.v; };
A.segSingle=el=>{ const box=el.closest('[data-single]'); $$('button',box).forEach(b=>b.classList.toggle('on',b===el)); const h=box.parentElement.querySelector(`input[name=${box.dataset.single}]`); if(h) h.value=el.dataset.v; };
F.community=async form=>{
  if(!requireAuth('crear comunidades')) return; const d=Object.fromEntries(new FormData(form)); const err=$('[data-err]',form); const id=(d.name||'').trim().toLowerCase();
  if(!/^[a-z0-9_]{3,24}$/.test(id)){ err.textContent='Nombre inválido: 3–24 letras minúsculas, números o _'; return; }
  if(S.communities.some(c=>c.id===id)){ err.textContent='Ya existe una comunidad con ese nombre'; return; }
  if(!d.desc.trim()){ err.textContent='Escribe una descripción'; return; }
  if(isToxic(d.desc+' '+id)){ err.textContent='La descripción contiene lenguaje no permitido'; return; }
  busy(form,true,'Creando…');
  try{
    await DB.createCommunity(S,{id,name:id.replace(/_/g,' ').replace(/\b\w/g,m=>m.toUpperCase()),icon:d.icon,cat:d.cat,color:COMMUNITY_COLORS[Math.floor(Math.random()*COMMUNITY_COLORS.length)],desc:d.desc.trim(),private:d.priv==='privada'});
    const arr=S.joined[S.session]=S.joined[S.session]||[]; if(!arr.includes(id)) arr.push(id);
    replace('community',{id}); toast(`Comunidad c/${id} creada`);
  }catch(e){ err.textContent=errMsg(e); }finally{ busy(form,false); }
};

/* ======================= CREAR / EDITAR ======================= */
let draft=null;
function newDraft(p){
  if(p.editId){ const w=work(p.editId); return JSON.parse(JSON.stringify({...w,comments:null,editId:w.id,chapters:(w.chapters||[]).length?w.chapters:[{title:'Capítulo 1',text:'',pages:[]}]})); }
  const type=p.type||'novela';
  return {type,title:'',synopsis:'',community:p.comm||'',genres:[],cover:null,image:null,chapters:[{title:'Capítulo 1',text:'',pages:[]}],credits:[],license:LICENSES[0],mature:false};
}
A.create=el=>{ if(!requireAuth('publicar contenido')) return; draft=null; go('create',{comm:el.dataset.comm||''}); };
SCREENS.create={ noNav:true, render(p){
  if(!draft || (p.editId && draft.editId!==p.editId)) draft=newDraft(p);
  const d=draft; const editing=!!d.editId; const t=d.type;
  const visual=t==='manga'||t==='comic'; const text=t==='novela'||t==='relato';
  const fmtGrid=editing?'':`<div class="field"><span>Formato</span><div class="fmt-grid">${Object.entries(FORMATS).map(([k,f])=>`<button type="button" class="fmt-btn ${t===k?'on':''}" data-a="draftType" data-v="${k}">${icon(f.icon,'class="fmt-ic"')}${f.label}</button>`).join('')}</div></div>`;
  const coverField=t==='foro'||t==='ilustracion'||t==='video'?'':`<div class="field"><span>Portada</span><div class="row" style="align-items:flex-start;gap:14px"><div class="cover" style="width:100px" id="coverPrev">${d.cover?`<img src="${d.cover}" alt="">`:coverSVG({...d,id:'draft',coverSeed:d.coverSeed||'draft',authorName:me().name})}</div><div class="grow stack"><button type="button" class="btn btn-ghost btn-sm btn-block" data-a="pickCover">${icon('image')} Subir imagen</button><button type="button" class="btn btn-ghost btn-sm btn-block" data-a="genCover">${icon('sparkles')} Generar otra</button>${d.cover?`<button type="button" class="btn btn-sm btn-block" style="color:var(--red)" data-a="rmCover">${icon('trash')} Quitar imagen</button>`:''}<div class="hint">Formato vertical 2:3 recomendado.</div></div></div></div>`;
  let content='';
  if(text){
    content=`<div class="section-label"><span>${t==='relato'?'Texto':'Capítulos'}</span>${t==='novela'?`<button type="button" data-a="addChapter">+ Capítulo</button>`:''}</div>${d.chapters.map((c,i)=>`<div class="card" style="padding:12px;margin-bottom:10px"><div class="row" style="margin-bottom:8px"><input class="input" style="padding:9px 12px" data-d="ch.${i}.title" value="${esc(c.title)}" placeholder="Título del capítulo">${d.chapters.length>1?`<button type="button" class="icon-btn" data-a="rmChapter" data-i="${i}">${icon('trash')}</button>`:''}</div><textarea class="textarea" style="min-height:${t==='relato'?260:180}px;font-family:Georgia,serif;font-weight:400" data-d="ch.${i}.text" placeholder="Érase una vez…">${esc(c.text||'')}</textarea><div class="hint" data-wc="${i}">${wordCount(c.text)} palabras</div></div>`).join('')}`;
  }else if(visual){
    content=`<div class="section-label"><span>Capítulos y páginas</span><button type="button" data-a="addChapter">+ Capítulo</button></div>${d.chapters.map((c,i)=>`<div class="card" style="padding:12px;margin-bottom:10px"><div class="row" style="margin-bottom:8px"><input class="input" style="padding:9px 12px" data-d="ch.${i}.title" value="${esc(c.title)}" placeholder="Título del capítulo">${d.chapters.length>1?`<button type="button" class="icon-btn" data-a="rmChapter" data-i="${i}">${icon('trash')}</button>`:''}</div>
      <button type="button" class="upload" data-a="pickPages" data-i="${i}">${icon('layers')}<b>Subir páginas</b><span class="tiny">Puedes elegir varias imágenes a la vez, en orden de lectura</span></button>
      ${(c.pages||[]).length?`<div class="thumbs">${c.pages.map((pg,k)=>`<div class="thumb">${typeof pg==='string'?`<img src="${pg}" alt="">`:pageSVG(pg,'d'+i+k,t==='comic')}<i>${k+1}</i><button type="button" data-a="rmPage" data-i="${i}" data-k="${k}">${icon('x')}</button></div>`).join('')}</div>`:''}</div>`).join('')}`;
  }else if(t==='video'){
    const poster=d.posterData||(d.video&&d.video.poster);
    content=`<div class="field"><span>Video</span>${d.videoFile||d.video?`<div class="post-wide" style="padding:0"><div class="art video-thumb">${poster?`<img src="${poster}" alt="">`:illustrationSVG('draft','')}<span class="play-badge">${icon('clapperboard')}</span></div></div><div class="hint">${d.videoFile?`${esc(d.videoFile.name)} · ${(d.videoFile.size/1048576).toFixed(1)} MB`:'Video actual'}</div><button type="button" class="btn btn-ghost btn-sm" style="margin-top:8px" data-a="pickVideoFile">${icon('refresh')} Cambiar video</button>`:`<button type="button" class="upload" data-a="pickVideoFile">${icon('clapperboard')}<b>Subir video</b><span class="tiny">MP4, WEBM o MOV · hasta ${DB.MAX_VIDEO_MB} MB · miniatura automática</span></button>`}</div>`;
  }else if(t==='ilustracion'){
    content=`<div class="field"><span>Imagen</span>${d.image&&d.image.data?`<div class="post-wide" style="padding:0"><div class="art"><img src="${d.image.data}" alt=""></div></div><button type="button" class="btn btn-ghost btn-sm" style="margin-top:8px" data-a="pickArt">${icon('refresh')} Cambiar imagen</button>`:`<button type="button" class="upload" data-a="pickArt">${icon('image')}<b>Subir ilustración</b><span class="tiny">JPG o PNG desde tu galería o cámara</span></button>`}</div>`;
  }
  const comms=S.communities.filter(c=>!c.private||isJoined(c.id)||c.owner===S.session);
  if(d.community && !comms.some(c=>c.id===d.community)){ const c0=community(d.community); if(c0) comms.push(c0); }
  const creditUsers=Object.values(S.users).filter(u=>u.username!==S.session);
  return `${topbar({title:editing?'Editar obra':'Nueva publicación',actions:`<button class="btn btn-primary btn-sm" style="margin-right:6px" data-a="publish">${editing&&d.status==='publicado'?'Guardar':'Publicar'}</button>`}).replace('data-a="back"','data-a="createClose"')}
  <div class="scroll"><div class="pad" style="padding-bottom:30px">${fmtGrid}
  <label class="field"><span>${t==='foro'?'Título de la discusión':'Título'}</span><input class="input" data-d="title" value="${esc(d.title)}" maxlength="90" placeholder="${t==='foro'?'¿De qué quieres hablar?':'El título de tu obra'}"></label>
  <label class="field"><span>${t==='foro'?'Contenido':t==='ilustracion'?'Descripción':'Sinopsis'}</span><textarea class="textarea" data-d="synopsis" maxlength="${t==='foro'?4000:600}" placeholder="${t==='foro'?'Escribe tu publicación…':'Cuenta de qué trata en pocas líneas'}">${esc(d.synopsis)}</textarea></label>
  ${coverField}${content}
  <div class="section-label"><span>Detalles</span></div>
  <label class="field"><span>Comunidad</span><select class="select" data-d="community"><option value="" ${!d.community?'selected':''}>Sin comunidad (solo en tu perfil y el feed)</option>${comms.map(c=>`<option value="${c.id}" ${d.community===c.id?'selected':''}>c/${esc(c.id)}</option>`).join('')}</select>${comms.length?'':`<div class="hint">Aún no hay comunidades. Puedes crear una desde Explorar.</div>`}</label>
  <div class="field"><span>Géneros (máx. 4)</span><div class="chips wrap">${GENRES.map(g=>`<button type="button" class="chip ${d.genres.includes(g)?'on':''}" data-a="draftGenre" data-v="${esc(g)}">${esc(g)}</button>`).join('')}</div></div>
  ${t==='foro'?'':`<div class="field"><span>Créditos y colaboradores</span>${d.credits.map((c,i)=>`<div class="row" style="margin-bottom:8px">${avatarHTML(c.user,'av-sm')}<span class="grow"><b class="small">${nameHTML(c.user)}</b></span><span class="tag">${esc(c.role)}</span><button type="button" class="icon-btn" data-a="rmCredit" data-i="${i}">${icon('x')}</button></div>`).join('')}
    ${creditUsers.length?`<div class="row" style="gap:8px"><select class="select grow" id="crUser" style="padding:10px"><option value="">Elegir persona…</option>${creditUsers.map(u=>`<option value="${u.username}">${esc(u.name)} (@${esc(u.username)})</option>`).join('')}</select><select class="select" id="crRole" style="width:auto;padding:10px">${CREDIT_ROLES.map(r=>`<option>${r}</option>`).join('')}</select></div><button type="button" class="btn btn-ghost btn-sm" style="margin-top:8px" data-a="addCredit">${icon('userPlus')} Añadir crédito</button><div class="hint">Los colaboradores aparecen en la ficha de la obra y reciben una notificación.</div>`:`<div class="hint">Cuando haya más personas registradas podrás darles crédito aquí.</div>`}</div>
  <label class="field"><span>Licencia</span><select class="select" data-d="license">${LICENSES.map(l=>`<option ${d.license===l?'selected':''}>${l}</option>`).join('')}</select></label>`}
  <div class="row between card" style="padding:12px 14px;margin-bottom:16px"><div><b>Contenido sensible (+18)</b><div class="tiny muted">Se ocultará a quien no lo active en ajustes</div></div><button type="button" class="toggle ${d.mature?'on':''}" data-a="draftMature"></button></div>
  <div class="err" id="draftErr" style="margin-bottom:10px"></div>
  <div class="row"><button class="btn btn-ghost grow" data-a="saveDraft">${icon('file')} Borrador</button><button class="btn btn-primary grow" data-a="publish">${icon('send')} ${editing&&d.status==='publicado'?'Guardar':'Publicar'}</button></div>
  <p class="tiny faint center" style="margin-top:12px">Al publicar confirmas que tienes los derechos sobre este contenido. Todo pasa por moderación automática y reportes de la comunidad.</p>
  </div></div>`; } };
document.addEventListener('input',e=>{
  const el=e.target;
  if(el.dataset.i && I[el.dataset.i]) return I[el.dataset.i](el,e);
  if(el.dataset.d && draft){ const path=el.dataset.d.split('.');
    if(path[0]==='ch'){ draft.chapters[+path[1]][path[2]]=el.value; if(path[2]==='text'){ const h=$(`[data-wc="${path[1]}"]`); if(h) h.textContent=wordCount(el.value)+' palabras'; } }
    else draft[path[0]]=el.value;
    if(path[0]==='title' && !draft.cover){ const cp=$('#coverPrev'); if(cp) cp.innerHTML=coverSVG({...draft,id:'draft',coverSeed:draft.coverSeed||'draft',authorName:me().name}); }
  }
});
document.addEventListener('change',e=>{ const el=e.target; if(el.dataset.d && draft && el.tagName==='SELECT') draft[el.dataset.d]=el.value; });
A.createClose=()=>{ const d=draft; const dirty=d && !d.editId && (d.title||d.synopsis||d.chapters.some(c=>c.text||(c.pages||[]).length)||d.image||d.videoFile);
  if(dirty) showDialog({title:'¿Salir sin publicar?',text:'Puedes guardar lo que llevas como borrador y terminarlo después desde tu perfil.',ok:'Guardar borrador',cancel:'Descartar',onOk:()=>A.saveDraft()});
  else { draft=null; back(); } };
A.draftType=el=>{ const old=draft; draft=newDraft({type:el.dataset.v}); Object.assign(draft,{title:old.title,synopsis:old.synopsis,genres:old.genres,credits:old.credits,community:old.community}); refresh(); };
A.draftGenre=el=>{ const g=el.dataset.v; const arr=draft.genres; const i=arr.indexOf(g); if(i>=0) arr.splice(i,1); else { if(arr.length>=4) return toast('Máximo 4 géneros'); arr.push(g); } el.classList.toggle('on'); };
A.draftMature=el=>{ draft.mature=!draft.mature; el.classList.toggle('on',draft.mature); };
A.addChapter=()=>{ draft.chapters.push({title:'Capítulo '+(draft.chapters.length+1),text:'',pages:[]}); refresh(); };
A.rmChapter=el=>{ draft.chapters.splice(+el.dataset.i,1); refresh(); };
A.pickCover=async()=>{ const [img]=await pickImages({max:700}); if(img){ draft.cover=img; refresh(); } };
A.genCover=()=>{ draft.cover=null; draft.coverSeed='c'+Math.random().toString(36).slice(2); refresh(); };
A.rmCover=()=>{ draft.cover=null; refresh(); };
A.pickPages=async el=>{ const imgs=await pickImages({multiple:true,max:1000,quality:.8}); if(imgs.length){ const c=draft.chapters[+el.dataset.i]; c.pages=[...(c.pages||[]),...imgs]; refresh(); toast(`${imgs.length} página(s) añadida(s)`); } };
A.rmPage=el=>{ draft.chapters[+el.dataset.i].pages.splice(+el.dataset.k,1); refresh(); };
A.pickVideoFile=async()=>{ const f=await pickVideo(); if(!f) return;
  if(!/^video\/(mp4|webm|quicktime)$/.test(f.type)) return toast('Formato no permitido: usa MP4, WEBM o MOV');
  if(f.size>DB.MAX_VIDEO_MB*1048576) return toast(`El video supera ${DB.MAX_VIDEO_MB} MB`);
  draft.videoFile=f; draft.posterData=null; refresh(); toast('Generando miniatura…');
  const poster=await videoPoster(f); if(draft&&draft.videoFile===f){ draft.posterData=poster; refresh(); } };
A.pickArt=async()=>{ const [img]=await pickImages({max:1400,quality:.85}); if(img){ draft.image={data:img}; refresh(); } };
A.addCredit=()=>{ const u=$('#crUser').value, r=$('#crRole').value; if(!u) return toast('Elige una persona'); if(draft.credits.some(c=>c.user===u&&c.role===r)) return toast('Ese crédito ya existe'); draft.credits.push({user:u,role:r}); refresh(); };
A.rmCredit=el=>{ draft.credits.splice(+el.dataset.i,1); refresh(); };
function validateDraft(d,strict){
  if((d.title||'').trim().length<3) return 'El título debe tener al menos 3 caracteres';
  if(!strict) return null;
  if(!(d.synopsis||'').trim()) return d.type==='foro'?'Escribe el contenido de tu publicación':'Escribe una sinopsis o descripción';
  if(d.type==='novela'||d.type==='relato'){ if(d.chapters.some(c=>wordCount(c.text)<20)) return 'Cada capítulo debe tener al menos 20 palabras'; }
  if(d.type==='manga'||d.type==='comic'){ if(d.chapters.some(c=>!(c.pages||[]).length)) return 'Sube al menos una página en cada capítulo'; }
  if(d.type==='ilustracion' && !d.image) return 'Sube la imagen de tu ilustración';
  if(d.type==='video' && !d.videoFile && !d.video) return 'Sube tu video';
  return null;
}
let publishing=false;
async function persistDraft(d,status){
  if(publishing) return null; publishing=true;
  showProgress(status==='publicado'?(d.editId?'Guardando cambios':'Publicando'):'Guardando borrador');
  try{ return await DB.saveWork(S,d,status,setProgress); }
  finally{ publishing=false; closeOverlay(); }
}
A.saveDraft=async()=>{
  const err=validateDraft(draft,false); if(err){ const e=$('#draftErr'); if(e) e.textContent=err; else toast(err); return; }
  const status=draft.editId?(work(draft.editId)||{}).status||'borrador':'borrador';
  try{ await persistDraft(draft,status); }catch(e){ const el=$('#draftErr'); if(el) el.textContent=errMsg(e); toast(errMsg(e)); return; }
  draft=null; closeOverlay(); stack.pop(); render(); toast('Guardado en borradores (Perfil > Borradores)');
};
A.publish=()=>{
  const d=draft; const err=validateDraft(d,true); const e=$('#draftErr'); if(err){ e.textContent=err; e.scrollIntoView({block:'center'}); return; }
  const doPub=async(flagged)=>{
    let w;
    try{ w=await persistDraft(d,'publicado'); }catch(ex){ const el=$('#draftErr'); if(el){ el.textContent=errMsg(ex); el.scrollIntoView({block:'center'}); } toast(errMsg(ex)); return; }
    if(!w) return;
    if(flagged) DB.report(S,{kind:'work',id:w.id,reason:'Posible lenguaje ofensivo (detección automática)',note:'',auto:true}).catch(()=>{});
    draft=null; replace('work',{id:w.id}); toast(d.editId?'Cambios guardados':(w.community?'Publicado en c/'+w.community:'Publicado'));
  };
  if(isToxic(d.title+' '+d.synopsis)) showDialog({title:'Revisión automática',html:`<div class="mod-flag" style="margin-top:8px">${icon('triangle-alert')}<span>El título o la descripción podrían contener lenguaje ofensivo. Puedes editarlo o publicarlo y será revisado por moderación.</span></div>`,ok:'Publicar igual',cancel:'Editar',onOk:()=>doPub(true)});
  else doPub(false);
};

/* ======================= MATCH ======================= */
/* Solo personas reales: cuenta confirmada + perfil con 2+ fotos propias + mayor de 18.
 * La ubicación exacta nunca sale del teléfono: se guarda redondeada (~1 km) y los demás
 * solo ven ciudad, país y una distancia aproximada. */
const MATCH_ROLES = ['Escritor/a','Ilustrador/a','Escritor/a e ilustrador/a'];
const MATCH_ROLE_ICONS = {'Escritor/a':'pen-tool','Ilustrador/a':'brush','Escritor/a e ilustrador/a':'sparkles'};
const MATCH_SEEK = [['Ilustrador/a','Ilustradores'],['Escritor/a','Escritores'],['Cualquiera','Ambos']];
const MATCH_LANGS = ['Español','Inglés','Portugués','Francés','Italiano','Alemán','Japonés','Coreano','Chino'];
const MATCH_EXP = ['Principiante','Intermedio','Avanzado','Profesional'];
const MATCH_COMMIT = ['Por hobby','Proyecto serio','Comisión / pago'];
const MATCH_KM = [[0,'Sin límite'],[10,'10 km'],[25,'25 km'],[50,'50 km'],[100,'100 km'],[300,'300 km']];
const MATCH_MIN_PHOTOS = 2, MATCH_MAX_PHOTOS = 6;

function matchState(){ if(!S.match) S.match={profile:undefined,cands:null,matches:null,blocks:[],filters:{maxKm:0,role:'Cualquiera'},lastPass:null,photoIdx:0,error:null}; return S.match; }
function flagOf(code){ return /^[A-Z]{2}$/.test(code||'')?String.fromCodePoint(...[...code].map(c=>0x1F1E6+c.charCodeAt(0)-65)):''; }
function placeText(x){ return [x.city,x.country].filter(Boolean).join(', '); }
function kmText(km){ if(km==null) return ''; return km<=1?'a menos de 2 km':`a ${km} km`; }
function matchPlaceHTML(x){ const pl=placeText(x); const km=kmText(x.km); if(!pl&&!km) return ''; return `<span class="mplace">${icon('map-pin')} ${esc(pl)}${pl&&x.countryCode?' '+flagOf(x.countryCode):''}${km?`<span class="faint"> · ${km}</span>`:''}</span>`; }

/** Carga mi perfil de Match y a quién bloqueé (una vez por sesión). */
let matchLoading=null;
function loadMatchState(force){
  const M=matchState();
  if(!S.uid) return Promise.resolve();
  if(matchLoading) return matchLoading;
  if(M.profile!==undefined && !force) return Promise.resolve();
  matchLoading=(async()=>{
    try{ const [p,b]=await Promise.all([DB.loadMyMatchProfile(S.uid),DB.loadBlocks(S.uid).catch(()=>[])]); M.profile=p; M.blocks=b; M.error=null; }
    catch(e){ M.error=e; if(e.code==='NO_MATCH_DB') M.profile=null; }
    finally{ matchLoading=null; }
  })();
  return matchLoading;
}
let candLoading=false;
async function loadCandidates(){
  const M=matchState(); if(candLoading) return; candLoading=true;
  try{ M.cands=await DB.matchCandidates(M.filters); M.photoIdx=0; M.candError=null; }
  catch(e){ M.cands=[]; M.candError=errMsg(e); }
  finally{ candLoading=false; if(['match'].includes(current().name)) refresh(); }
}
let matchesLoading=null;
function loadMatches(){
  if(matchesLoading) return matchesLoading;
  const M=matchState();
  matchesLoading=(async()=>{
    try{ M.matches=await DB.myMatches(); }catch(e){ if(!M.matches) M.matches=[]; if(e.code!=='NO_MATCH_DB') toast(errMsg(e)); }
    finally{ matchesLoading=null; }
    if(['matches','match'].includes(current().name)) refresh();
  })();
  return matchesLoading;
}

/* ---------- ubicación ---------- */
async function getCoords(){
  if(isNative){
    let st=await Geolocation.checkPermissions().catch(()=>({}));
    const ok=s=>s.location==='granted'||s.coarseLocation==='granted';
    if(!ok(st)) st=await Geolocation.requestPermissions({permissions:['location','coarseLocation']}).catch(()=>({}));
    if(!ok(st)) throw new Error('PERMISO');
    const p=await Geolocation.getCurrentPosition({enableHighAccuracy:false,timeout:20000,maximumAge:300000});
    return {lat:p.coords.latitude,lng:p.coords.longitude};
  }
  return new Promise((res,rej)=>{
    if(!navigator.geolocation) return rej(new Error('NO_GEO'));
    navigator.geolocation.getCurrentPosition(p=>res({lat:p.coords.latitude,lng:p.coords.longitude}),e=>rej(new Error(e&&e.code===1?'PERMISO':'NO_GEO')),{enableHighAccuracy:false,timeout:20000,maximumAge:300000});
  });
}
/** Coordenadas → país y ciudad (dos servicios gratuitos, por si uno falla). */
async function reverseGeocode({lat,lng}){
  const get=async(url,ms=9000)=>{ const ctl=new AbortController(); const t=setTimeout(()=>ctl.abort(),ms); try{ const r=await fetch(url,{signal:ctl.signal,headers:{Accept:'application/json'}}); return r.ok?await r.json():null; }catch(e){ return null; } finally{ clearTimeout(t); } };
  const a=await get(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lng}&localityLanguage=es`);
  if(a&&a.countryName) return {country:String(a.countryName).replace(/\s*\(.*\)\s*$/,'').slice(0,60),countryCode:String(a.countryCode||'').toUpperCase().slice(0,2),city:String(a.city||a.locality||a.principalSubdivision||'').slice(0,80)};
  const b=await get(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10&accept-language=es&lat=${lat}&lon=${lng}`);
  if(b&&b.address){ const d=b.address; return {country:String(d.country||'').slice(0,60),countryCode:String(d.country_code||'').toUpperCase().slice(0,2),city:String(d.city||d.town||d.village||d.municipality||d.county||d.state||'').slice(0,80)}; }
  return null;
}
function geoErrorText(e){
  const m=String(e&&e.message||e||'');
  if(/PERMISO|denied|permission/i.test(m)) return 'Necesitamos permiso de ubicación. Actívalo en Ajustes del teléfono → Apps → CHOGGUN → Permisos.';
  if(/not enabled|disabled|location services|unavailable/i.test(m)) return 'Activa la ubicación (GPS) del teléfono e intenta de nuevo.';
  if(/timeout|timed out/i.test(m)) return 'No pudimos encontrar tu ubicación a tiempo. Sal a un lugar abierto o intenta de nuevo.';
  return 'No pudimos obtener tu ubicación. Puedes escribir tu país y ciudad a mano.';
}

/* ---------- pantalla principal ---------- */
function matchCardHTML(c,top){
  const M=matchState(); const i=top?Math.min(M.photoIdx,c.photos.length-1):0;
  const bars=c.photos.length>1?`<div class="mph-bars">${c.photos.map((_,k)=>`<i class="${k===i?'on':''}"></i>`).join('')}</div>`:'';
  return `<div class="mcard mphoto ${top?'':'back'}" ${top?'id="topCard"':''} data-u="${c.userId}">
    <div class="mph">${c.photos.map((p,k)=>`<img src="${p}" alt="" class="${k===i?'on':''}" draggable="false" ${k>1&&!top?'loading="lazy"':''}>`).join('')}</div>
    ${bars}<div class="mph-shade"></div>
    <span class="stamp like">COLABORAR</span><span class="stamp nope">PASAR</span>
    <span class="compat">${icon('sparkles')} ${c.affinity}%</span>
    <div class="mph-info">
      <div class="mname">${esc(c.name)}</div>
      <div class="row wrap" style="gap:6px;margin:4px 0 6px"><span class="tag ${c.role==='Ilustrador/a'?'blue':c.role==='Escritor/a'?'':'purple'}">${icon(MATCH_ROLE_ICONS[c.role]||'user','width="12" height="12"')} ${esc(c.role)}</span>${c.commitment?`<span class="tag gray">${esc(c.commitment)}</span>`:''}</div>
      ${matchPlaceHTML(c)}
      <p class="mabout">${esc(c.about)}</p>
      ${(c.lookingFor||[]).length?`<div class="small mlook"><b>Busca:</b> ${c.lookingFor.slice(0,3).map(esc).join(' · ')}</div>`:''}
    </div>
  </div>`;
}
function matchGateHTML(){
  const M=matchState();
  if(!S.session) return `<div class="match-intro"><img src="${ASSETS.match}" alt="" class="mi-bg"><div class="mi-shade"></div><div class="mi-body"><div class="h1">Encuentra con quién crear</div><p>Desliza perfiles de escritores e ilustradores reales cerca de ti. Si los dos dicen “me interesa”, se abre el chat.</p><button class="btn btn-primary btn-block" data-a="go" data-s="auth" data-mode="login">Iniciar sesión</button><button class="btn btn-ghost btn-block" data-a="go" data-s="auth" data-mode="register">Crear cuenta</button></div></div>`;
  if(M.error && M.error.code==='NO_MATCH_DB') return emptyHTML('settings','Match aún no está activado','Falta ejecutar el archivo supabase-match.sql en el SQL Editor de Supabase.');
  if(M.profile===undefined) return `<div class="empty" style="flex:1"><div class="spinner"></div></div>`;
  if(M.error && M.profile===undefined) return emptyHTML('wifi-off','No se pudo cargar Match',errMsg(M.error),`<button class="btn btn-primary" data-a="matchRetry">Reintentar</button>`);
  if(!M.profile) return `<div class="match-intro"><img src="${ASSETS.match}" alt="" class="mi-bg"><div class="mi-shade"></div><div class="mi-body">
    <div class="h1">Crea tu perfil de Match</div>
    <p>Muéstrales a otros creadores quién eres: sube al menos ${MATCH_MIN_PHOTOS} fotos (tuyas o de tu trabajo), cuenta qué haces y qué buscas. Tu ubicación llena tu país y ciudad sola.</p>
    <ul class="mi-list"><li>${icon('shield-check')} Solo personas reales con cuenta confirmada</li><li>${icon('map-pin')} Nadie ve tu ubicación exacta, solo la distancia aproximada</li><li>${icon('message-circle')} El chat se abre solo cuando los dos quieren colaborar</li></ul>
    <button class="btn btn-primary btn-block" data-a="go" data-s="matchProfile">${icon('plus')} Crear mi perfil</button></div></div>`;
  if(!M.profile.active) return emptyHTML('eye-off','Tu perfil de Match está pausado','Nadie te ve en Match y tú no ves perfiles nuevos. Tus matches y chats siguen igual.',`<button class="btn btn-primary" data-a="matchActivate">Activar mi perfil</button>`);
  return '';
}
SCREENS.match={ render(){
  const M=matchState(); const gate=matchGateHTML();
  const f=M.filters; const nf=(f.maxKm?1:0)+(f.role!=='Cualquiera'?1:0);
  const nMatches=(M.matches||[]).filter(c=>{ const ch=S.chats[chatId(c.username)]; return !ch||!ch.msgs.length; }).length;
  const actions=S.session&&M.profile?`<button class="icon-btn" data-a="matchFilters" aria-label="Filtros">${icon('filter')}${nf?`<span class="badge">${nf}</span>`:''}</button><button class="icon-btn" data-a="go" data-s="matches" aria-label="Mis matches">${icon('heart-handshake')}${nMatches?`<span class="badge">${nMatches}</span>`:''}</button><button class="icon-btn" data-a="go" data-s="matchProfile" aria-label="Mi perfil de Match">${icon('square-pen')}</button>`:'';
  if(gate) return `${topbar({back:false,title:'Match',actions})}<div class="match-wrap gate">${gate}</div>`;
  const cands=M.cands;
  let body;
  if(cands==null) body=`<div class="deck"><div class="empty" style="height:100%"><div class="spinner"></div><div class="small">Buscando creadores…</div></div></div>`;
  else if(!cands.length) body=`<div class="deck"><div class="empty" style="height:100%"><img src="${ASSETS.logo}" alt=""><div class="h3">${M.candError?'No se pudo cargar':nf?'No hay más perfiles con estos filtros':'Por ahora no hay más perfiles'}</div><div class="small">${M.candError?esc(M.candError):'Cuando más escritores e ilustradores creen su perfil aparecerán aquí. ¡Invita a tus amigos!'}</div><div class="row wrap" style="justify-content:center">${nf?`<button class="btn btn-ghost btn-sm" data-a="matchClearFilters">Quitar filtros</button>`:''}${M.lastPass?`<button class="btn btn-ghost btn-sm" data-a="matchUndo">${icon('undo')} Deshacer</button>`:''}<button class="btn btn-ghost btn-sm" data-a="matchReload">${icon('refresh')} Buscar de nuevo</button><button class="btn btn-primary btn-sm" data-a="invite">${icon('share')} Invitar</button></div></div></div><div style="height:calc(var(--nav-h) + var(--safe-bottom) + 20px)"></div>`;
  else body=`<div class="deck">${cands[1]?matchCardHTML(cands[1],false):''}${matchCardHTML(cands[0],true)}</div>
    <div class="match-actions"><button class="round sm" data-a="matchUndo" aria-label="Deshacer" style="color:var(--gold)" ${M.lastPass?'':'disabled'}>${icon('undo')}</button><button class="round nope" data-a="matchSwipe" data-dir="-1" aria-label="Pasar">${icon('x','stroke-width="3"')}</button><button class="round like" data-a="matchSwipe" data-dir="1" aria-label="Me interesa colaborar">${icon('heart','fill="currentColor" stroke-width="0"')}</button><button class="round sm info" data-a="matchInfo" aria-label="Ver perfil">${icon('info')}</button></div>`;
  return `${topbar({back:false,title:'Match',actions})}<div class="match-wrap">${!M.profile.hasLocation?`<button class="banner-tip mloc-tip" data-a="go" data-s="matchProfile">${icon('map-pin')}<span class="small grow">Activa tu ubicación para ver a qué distancia está cada persona.</span>${icon('chevR')}</button>`:''}${body}</div>`;
}, after(){
  const M=matchState();
  if(S.session && M.profile===undefined && !matchLoading){ loadMatchState().then(()=>{ if(current().name==='match') refresh(); }); return; }
  if(S.session && M.profile && M.profile.active && M.cands==null) loadCandidates();
  if(S.session && M.profile && M.matches==null) loadMatches();
  setupMatchSwipe();
} };
A.matchRetry=()=>{ loadMatchState(true).then(()=>refresh()); refresh(); };
A.matchReload=()=>{ matchState().cands=null; refresh(); };
A.matchActivate=async()=>{ const M=matchState(); try{ M.profile=await DB.setMatchActive(S.uid,true); }catch(e){ return toast(errMsg(e)); } M.cands=null; toast('Tu perfil vuelve a estar visible'); refresh(); };
A.matchClearFilters=()=>{ const M=matchState(); M.filters={maxKm:0,role:'Cualquiera'}; M.cands=null; refresh(); };
A.matchFilters=()=>{
  const M=matchState(); const f=M.filters; const loc=M.profile&&M.profile.hasLocation;
  showSheet(`<div class="pad" style="padding-top:0">
    <div class="field"><span>Distancia máxima</span><div class="chips wrap">${MATCH_KM.map(([k,l])=>`<button class="chip ${f.maxKm===k?'on':''}" data-a="matchKm" data-v="${k}" ${!loc&&k?'disabled':''}>${l}</button>`).join('')}</div>${loc?'':`<div class="hint">Activa tu ubicación en tu perfil de Match para filtrar por distancia.</div>`}</div>
    <div class="field"><span>Quiero ver</span><div class="chips wrap">${[['Cualquiera','Todos'],['Escritor/a','Escritores'],['Ilustrador/a','Ilustradores']].map(([k,l])=>`<button class="chip ${f.role===k?'on':''}" data-a="matchRoleF" data-v="${k}">${l}</button>`).join('')}</div></div>
    <button class="btn btn-primary btn-block" data-a="matchApplyFilters">Aplicar</button></div>`,'Filtros');
  M._f={...f};
};
A.matchKm=el=>{ matchState()._f.maxKm=+el.dataset.v; $$('.chip',el.parentElement).forEach(c=>c.classList.toggle('on',c===el)); };
A.matchRoleF=el=>{ matchState()._f.role=el.dataset.v; $$('.chip',el.parentElement).forEach(c=>c.classList.toggle('on',c===el)); };
A.matchApplyFilters=()=>{ const M=matchState(); M.filters={...M._f}; M.cands=null; M.lastPass=null; closeOverlay(); refresh(); };

function setupMatchSwipe(){
  const card=$('#topCard'); if(!card) return;
  let sx=0,sy=0,dx=0,dy=0,drag=false,moved=false;
  const like=$('.stamp.like',card), nope=$('.stamp.nope',card);
  card.addEventListener('pointerdown',e=>{ drag=true; moved=false; sx=e.clientX; sy=e.clientY; dx=dy=0; try{ card.setPointerCapture(e.pointerId); }catch(_){} card.style.transition='none'; });
  card.addEventListener('pointermove',e=>{ if(!drag) return; dx=e.clientX-sx; dy=e.clientY-sy; if(Math.abs(dx)>6||Math.abs(dy)>6) moved=true; if(!moved) return;
    card.style.transform=`translate(${dx}px,${dy*.25}px) rotate(${dx/18}deg)`; like.style.opacity=Math.max(0,Math.min(1,dx/90)); nope.style.opacity=Math.max(0,Math.min(1,-dx/90)); });
  const end=e=>{ if(!drag) return; drag=false; card.style.transition='transform .3s ease';
    if(!moved){ // toque: izquierda/derecha cambia de foto, abajo abre el perfil
      const r=card.getBoundingClientRect(); const x=(e.clientX-r.left)/r.width, y=(e.clientY-r.top)/r.height;
      if(y>.62) return A.matchInfo(); matchPhotoStep(x<.4?-1:1); return; }
    if(Math.abs(dx)>100) doMatchSwipe(dx>0?1:-1); else { card.style.transform=''; like.style.opacity=0; nope.style.opacity=0; } };
  card.addEventListener('pointerup',end); card.addEventListener('pointercancel',()=>{ drag=false; card.style.transform=''; like.style.opacity=0; nope.style.opacity=0; });
}
function matchPhotoStep(d){
  const M=matchState(); const c=(M.cands||[])[0]; if(!c) return; const n=c.photos.length; if(n<2) return;
  M.photoIdx=Math.max(0,Math.min(n-1,M.photoIdx+d));
  const card=$('#topCard'); if(!card) return;
  $$('.mph img',card).forEach((im,k)=>im.classList.toggle('on',k===M.photoIdx));
  $$('.mph-bars i',card).forEach((b,k)=>b.classList.toggle('on',k===M.photoIdx));
}
let swiping=false;
async function doMatchSwipe(dir){
  const M=matchState(); const card=$('#topCard'); const c=(M.cands||[])[0]; if(!card||!c||swiping) return;
  swiping=true;
  card.style.transition='transform .35s ease, opacity .35s'; card.style.transform=`translate(${dir*600}px,-40px) rotate(${dir*30}deg)`; card.style.opacity='0';
  M.cands.shift(); M.photoIdx=0; M.lastPass=dir<0?c:null;
  setTimeout(()=>{ swiping=false; if(current().name==='match'){ refresh(); if(M.cands.length<3) loadCandidates(); } },320);
  try{
    const r=await DB.matchSwipe(c.userId,dir>0);
    if(r&&r.matched){ c.matchId=r.matchId; M.matches=[{...c,matchedAt:Date.now()},...(M.matches||[]).filter(x=>x.userId!==c.userId)]; await DB.ensureProfiles(S,[c.userId]).catch(()=>{}); setTimeout(()=>showItsMatch(c),360); }
    else if(dir>0) toast(`Le mostraste tu interés a ${c.name.split(' ')[0]}`);
  }catch(e){ toast(errMsg(e)); }
}
A.matchSwipe=el=>doMatchSwipe(+el.dataset.dir);
A.matchUndo=async()=>{ const M=matchState(); const c=M.lastPass; if(!c) return; M.lastPass=null;
  try{ await DB.matchUndo(c.userId); }catch(e){ return toast(errMsg(e)); }
  M.cands=[c,...(M.cands||[]).filter(x=>x.userId!==c.userId)]; M.photoIdx=0; refresh(); };
A.matchInfo=()=>{ const c=(matchState().cands||[])[0]; if(c) go('matchView',{id:c.userId,from:'deck'}); };

function showItsMatch(c){
  const mine=matchState().profile; const myPhoto=(mine&&mine.photos[0])||(me()&&me().avatar)||ASSETS.avdef;
  $('#overlay').innerHTML=`<div class="its-match"><div class="h1">¡Es un match!</div><div class="pair"><img class="avatar" src="${myPhoto}" alt=""><img class="avatar" src="${c.photos[0]||c.avatar||ASSETS.avdef}" alt=""></div><p style="font-size:17px;max-width:300px">Tú y <b>${esc(c.name.split(' ')[0])}</b> quieren colaborar. ¡Escríbele y cuéntale tu idea!</p><button class="btn btn-primary btn-block" style="max-width:320px" data-a="matchChat" data-u="${esc(c.username)}">${icon('message-circle')} Enviar mensaje</button><button class="btn btn-ghost btn-block" style="max-width:320px" data-a="closeOverlay">Seguir explorando</button></div>`;
}
A.matchChat=async el=>{ const u=el.dataset.u; closeOverlay(); if(!S.users[u]){ const c=[...(matchState().matches||[]),...(matchState().cands||[])].find(x=>x.username===u); if(c) await DB.ensureProfiles(S,[c.userId]).catch(()=>{}); } if(!S.users[u]) return toast('Esta cuenta ya no existe'); ensureChat(u); go('chat',{id:u}); };

/* ---------- mis matches ---------- */
SCREENS.matches={ render(){
  const M=matchState(); const list=M.matches;
  const rows=list==null?`<div class="empty"><div class="spinner"></div></div>`:list.length?`<div class="mgrid">${list.map(c=>{ const chat=S.chats[chatId(c.username)]; const last=chat&&chat.msgs.at(-1); const unread=chat&&(chat.unread||{})[S.session];
      return `<div class="mtile"><button class="mtile-ph" data-a="matchOpen" data-id="${c.userId}"><img src="${c.photos[0]||c.avatar||ASSETS.avdef}" alt="" loading="lazy">${!last?'<span class="mnew">NUEVO</span>':''}</button><div class="mtile-txt"><b class="ellipsis">${esc(c.name)}</b><span class="tiny muted ellipsis">${esc(c.role)}${c.city?' · '+esc(c.city):''}</span><span class="tiny ellipsis" style="${unread?'color:var(--text);font-weight:700':'color:var(--faint)'}">${last?(last.from===S.session?'Tú: ':'')+(last.img&&!last.text?'Imagen':esc(last.text)):'¡Saluda!'}</span></div><button class="btn btn-primary btn-sm btn-block" data-a="matchChat" data-u="${esc(c.username)}">${icon('message-circle')} Chatear</button></div>`; }).join('')}</div>`
    :emptyHTML('heart-handshake','Aún no tienes matches','Cuando tú y otra persona digan “me interesa”, aparecerá aquí y podrán chatear.',`<button class="btn btn-primary" data-a="tab" data-t="match">Ir a Match</button>`);
  return `${topbar({title:'Mis matches',actions:`<button class="icon-btn" data-a="matchesReload" aria-label="Actualizar">${icon('refresh')}</button>`})}<div class="scroll">${rows}</div>`;
}, after(){ const M=matchState(); if(M.profile===undefined) loadMatchState(); if(M.matches==null) loadMatches(); } };
A.matchesReload=()=>{ matchState().matches=null; refresh(); };
A.matchOpen=el=>go('matchView',{id:el.dataset.id,from:'matches'});

/* ---------- ficha completa ---------- */
SCREENS.matchView={ noNav:true, render(p){
  const M=matchState();
  const c=(p.from==='deck'?(M.cands||[]).find(x=>x.userId===p.id):null)||(M.matches||[]).find(x=>x.userId===p.id)||(M.viewCache&&M.viewCache.userId===p.id?M.viewCache:null);
  if(!c) return `${topbar({title:'Perfil'})}<div class="empty"><div class="spinner"></div></div>`;
  const matched=!!c.matchId;
  const row=(ic,label,val)=>val?`<div class="mrow">${icon(ic)}<span class="muted">${label}</span><b>${val}</b></div>`:'';
  const portfolio=c.portfolio?`<a class="btn btn-ghost btn-sm" data-a="openLink" data-url="${esc(c.portfolio)}">${icon('link')} Ver portafolio</a>`:'';
  return `${topbar({title:esc(c.name.split(' ')[0]),actions:`<button class="icon-btn" data-a="matchViewMenu" data-id="${c.userId}" aria-label="Más opciones">${icon('more')}</button>`})}
  <div class="scroll" style="padding-bottom:110px">
    <div class="mgallery">${c.photos.map(ph=>`<img src="${ph}" alt="" loading="lazy">`).join('')}</div>
    ${c.photos.length>1?`<div class="tiny faint center" style="margin-top:6px">Desliza para ver las ${c.photos.length} fotos</div>`:''}
    <div class="pad">
      <div class="row between top"><div><div class="h2">${esc(c.name)}</div><div class="small muted">@${esc(c.username)}</div></div><span class="tag">${icon('sparkles','width="12" height="12"')} ${c.affinity}% afinidad</span></div>
      <div style="margin-top:8px">${matchPlaceHTML(c)}</div>
      <p style="margin-top:12px;white-space:pre-wrap">${esc(c.about)}</p>
      <div class="list" style="margin-top:14px;border-radius:var(--radius);overflow:hidden">
        ${row(MATCH_ROLE_ICONS[c.role]||'user','Es',esc(c.role))}
        ${row('users','Busca',esc((MATCH_SEEK.find(s=>s[0]===c.seeking)||[0,c.seeking])[1]))}
        ${row('star','Experiencia',esc(c.experience))}
        ${row('handshake','Modalidad',esc(c.commitment))}
        ${row('globe','Idiomas',c.languages.map(esc).join(', '))}
      </div>
      ${c.lookingFor.length?`<div class="field" style="margin-top:14px"><span>Le interesa</span><div class="chips wrap">${c.lookingFor.map(x=>`<span class="chip on">${esc(x)}</span>`).join('')}</div></div>`:''}
      ${c.genres.length?`<div class="field"><span>Géneros</span><div class="chips wrap">${c.genres.map(x=>`<span class="chip">${esc(x)}</span>`).join('')}</div></div>`:''}
      <div class="row wrap" style="gap:8px">${portfolio}<button class="btn btn-ghost btn-sm" data-a="matchPublicProfile" data-id="${c.userId}">${icon('user')} Ver obras</button></div>
    </div>
  </div>
  <div class="mview-actions">${matched
    ?`<button class="btn btn-primary btn-block" data-a="matchChat" data-u="${esc(c.username)}">${icon('message-circle')} Enviar mensaje</button>`
    :p.from==='deck'?`<button class="round nope" data-a="matchViewSwipe" data-dir="-1" aria-label="Pasar">${icon('x','stroke-width="3"')}</button><button class="round like" data-a="matchViewSwipe" data-dir="1" aria-label="Me interesa">${icon('heart','fill="currentColor" stroke-width="0"')}</button>`:''}</div>`;
}, after(p){
  const M=matchState();
  const known=(M.cands||[]).some(x=>x.userId===p.id)||(M.matches||[]).some(x=>x.userId===p.id)||(M.viewCache&&M.viewCache.userId===p.id);
  if(!known) DB.matchProfileOf(p.id).then(c=>{ if(!c){ toast('Este perfil ya no está disponible'); return back(); } M.viewCache=c; if(current().name==='matchView') refresh(); },e=>toast(errMsg(e)));
} };
A.matchViewSwipe=el=>{ const dir=+el.dataset.dir; back(); setTimeout(()=>doMatchSwipe(dir),80); };
A.openLink=el=>{ const url=el.dataset.url; if(!/^https?:\/\//i.test(url)) return; if(isNative) Browser.open({url}).catch(()=>window.open(url,'_blank')); else window.open(url,'_blank','noopener'); };
A.matchPublicProfile=async el=>{ const id=el.dataset.id; if(!S.byId[id]) await DB.ensureProfiles(S,[id]).catch(()=>{}); const u=S.byId[id]; if(!u) return toast('Esta cuenta ya no existe'); go('user',{u}); };
function matchFind(id){ const M=matchState(); return [...(M.matches||[]),...(M.cands||[]),...(M.viewCache?[M.viewCache]:[])].find(x=>x.userId===id); }
A.matchViewMenu=el=>{ const c=matchFind(el.dataset.id); if(!c) return;
  showSheet(`${c.matchId?`<button class="opt" data-a="matchUnmatch" data-id="${c.userId}">${icon('x')} Deshacer match</button>`:''}<button class="opt danger" data-a="blockUser" data-id="${c.userId}">${icon('ban')} Bloquear</button><button class="opt danger" data-a="report" data-kind="user" data-id="${esc(c.username)}">${icon('flag')} Reportar perfil</button>`); };
A.matchUnmatch=el=>{ const c=matchFind(el.dataset.id); if(!c) return; closeOverlay();
  showDialog({title:'¿Deshacer el match?',text:`${esc(c.name.split(' ')[0])} desaparecerá de tus matches. La conversación no se borra.`,ok:'Deshacer',danger:true,onOk:async()=>{
    try{ await DB.unmatch(c.matchId); }catch(e){ return toast(errMsg(e)); }
    const M=matchState(); M.matches=(M.matches||[]).filter(x=>x.userId!==c.userId); toast('Match deshecho'); if(current().name==='matchView') back(); else refresh(); }}); };

/* ---------- bloquear (Match, perfil y chat) ---------- */
A.blockUser=el=>{ const id=el.dataset.id||(S.users[el.dataset.u]||{}).id; if(!id) return; const name=(matchFind(id)||S.users[S.byId[id]]||{name:'esta persona'}).name; closeOverlay();
  if(!requireAuth('bloquear')) return;
  showDialog({title:`¿Bloquear a ${esc(String(name).split(' ')[0])}?`,text:'No podrá escribirte ni verte en Match, y se deshace el match si lo tenían. No le avisaremos.',ok:'Bloquear',danger:true,onOk:async()=>{
    try{ await DB.block(id); }catch(e){ return toast(errMsg(e)); }
    const M=matchState(); if(!M.blocks.includes(id)) M.blocks.push(id);
    M.matches=(M.matches||[]).filter(x=>x.userId!==id); M.cands=(M.cands||[]).filter(x=>x.userId!==id);
    toast('Persona bloqueada'); const c=current(); if(['matchView','chat','user'].includes(c.name)) back(); else refresh(); }}); };
A.unblockUser=async el=>{ const id=el.dataset.id; try{ await DB.unblock(S.uid,id); }catch(e){ return toast(errMsg(e)); } const M=matchState(); M.blocks=M.blocks.filter(x=>x!==id); M.cands=null; closeOverlay(); toast('Desbloqueado'); refresh(); };
function isBlocked(username){ const u=S.users[username]; return !!u && matchState().blocks.includes(u.id); }

/* ---------- editar mi perfil de Match ---------- */
let medit=null;
function newMatchDraft(){
  const M=matchState(); const p=M.profile; const m=me()||{};
  if(p) return {photos:[...p.photos],about:p.about,role:p.role,seeking:p.seeking,lookingFor:[...p.lookingFor],genres:[...p.genres],languages:[...p.languages],experience:p.experience,commitment:p.commitment,portfolio:p.portfolio,country:p.country,countryCode:p.countryCode,city:p.city,hasLocation:p.hasLocation,coords:null,clearCoords:false,isAdult:p.isAdult,active:p.active};
  return {photos:m.avatar?[m.avatar]:[],about:m.bio||'',role:m.role==='Ilustrador/a'?'Ilustrador/a':'Escritor/a',seeking:m.role==='Ilustrador/a'?'Escritor/a':'Ilustrador/a',lookingFor:[...(m.collab||[])],genres:[...(m.genres||[])],languages:['Español'],experience:'Intermedio',commitment:'Por hobby',portfolio:'',country:'',countryCode:'',city:'',hasLocation:false,coords:null,clearCoords:false,isAdult:false,active:true};
}
SCREENS.matchProfile={ noNav:true, render(){
  const M=matchState();
  if(M.profile===undefined) return `${topbar({title:'Perfil de Match'})}<div class="empty"><div class="spinner"></div></div>`;
  if(!medit) medit=newMatchDraft();
  const e=medit; const isNew=!M.profile;
  const slots=Array.from({length:MATCH_MAX_PHOTOS},(_,i)=>{ const ph=e.photos[i];
    return ph?`<button class="mslot has" data-a="mPhotoMenu" data-i="${i}"><img src="${ph}" alt="">${i===0?'<span class="mmain">Principal</span>':''}</button>`
      :`<button class="mslot ${i<MATCH_MIN_PHOTOS?'req':''}" data-a="mPhotoAdd">${icon('plus')}${i<MATCH_MIN_PHOTOS?'<span>Obligatoria</span>':''}</button>`; }).join('');
  const chip=(k,v,label,single)=>{ const on=single?e[k]===v:(e[k]||[]).includes(v); return `<button class="chip ${on?'on':''}" data-a="${single?'mPick':'mToggle'}" data-k="${k}" data-v="${esc(v)}">${label||esc(v)}</button>`; };
  const locLine=(e.city||e.country)?`<div class="mloc-now">${icon('map-pin')}<span class="grow"><b>${esc(placeText(e))}</b> ${flagOf(e.countryCode)}<br><span class="tiny muted">${e.coords||e.hasLocation?'Distancia activada · nadie ve tu ubicación exacta':'Sin distancia (escrito a mano)'}</span></span></div>`:'';
  return `${topbar({title:isNew?'Crear perfil de Match':'Mi perfil de Match',actions:`<button class="btn btn-primary btn-sm" style="margin-right:6px" data-a="mSave">Guardar</button>`}).replace('data-a="back"','data-a="mCancel"')}
  <div class="scroll"><div class="pad">
    <div class="field"><span>Fotos <b class="faint">${e.photos.length}/${MATCH_MAX_PHOTOS} · mínimo ${MATCH_MIN_PHOTOS}</b></span><div class="mslots">${slots}</div><div class="hint">Fotos tuyas o de tu trabajo (ilustraciones, portadas, páginas). Toca una foto para hacerla principal o quitarla.</div></div>
    <label class="field"><span>Sobre ti <b class="faint" id="mAboutCount">${(e.about||'').length}/500</b></span><textarea class="textarea" data-m="about" maxlength="500" style="min-height:110px" placeholder="¿Qué escribes o dibujas? ¿Qué proyecto te gustaría hacer?">${esc(e.about||'')}</textarea><div class="hint">Mínimo 20 caracteres.</div></label>
    <div class="field"><span>Soy</span><div class="chips wrap">${MATCH_ROLES.map(r=>chip('role',r,`${icon(MATCH_ROLE_ICONS[r])} ${esc(r)}`,true)).join('')}</div></div>
    <div class="field"><span>Quiero colaborar con</span><div class="chips wrap">${MATCH_SEEK.map(([v,l])=>chip('seeking',v,l,true)).join('')}</div></div>
    <div class="field"><span>Me interesa (elige al menos uno)</span><div class="chips wrap">${COLLABS.map(c=>chip('lookingFor',c)).join('')}</div></div>
    <div class="field"><span>Géneros</span><div class="chips wrap">${GENRES.map(g=>chip('genres',g)).join('')}</div></div>
    <div class="field"><span>Idiomas</span><div class="chips wrap">${MATCH_LANGS.map(l=>chip('languages',l)).join('')}</div></div>
    <div class="field"><span>Experiencia</span><div class="chips wrap">${MATCH_EXP.map(x=>chip('experience',x,null,true)).join('')}</div></div>
    <div class="field"><span>Modalidad</span><div class="chips wrap">${MATCH_COMMIT.map(x=>chip('commitment',x,null,true)).join('')}</div></div>
    <label class="field"><span>Portafolio (opcional)</span><div class="input-wrap">${icon('link')}<input class="input" data-m="portfolio" value="${esc(e.portfolio||'')}" placeholder="https://…" inputmode="url" autocapitalize="off" maxlength="300"></div></label>

    <div class="section-label"><span>Ubicación</span></div>
    ${locLine}
    <button class="btn btn-outline btn-block" data-a="mLocate">${icon('map-pin')} ${e.coords||e.hasLocation?'Actualizar mi ubicación':'Usar mi ubicación'}</button>
    <div class="hint" style="margin-top:8px">Con tu ubicación llenamos tu país y tu ciudad, y calculamos la distancia con otros creadores. Se guarda redondeada (~1 km) y los demás solo ven “a X km”.</div>
    <details class="mmanual" ${!(e.coords||e.hasLocation)&&(e.city||e.country)?'open':''}><summary class="small">Escribir país y ciudad a mano</summary>
      <div class="row" style="gap:10px;margin-top:10px"><label class="field grow"><span>País</span><input class="input" data-m="country" value="${esc(e.country||'')}" maxlength="60" placeholder="Colombia"></label><label class="field grow"><span>Ciudad</span><input class="input" data-m="city" value="${esc(e.city||'')}" maxlength="80" placeholder="Bogotá"></label></div>
      ${e.coords||e.hasLocation?`<button class="btn btn-ghost btn-sm" data-a="mClearLoc">${icon('x')} Quitar distancia</button>`:''}
    </details>

    <div class="section-label"><span>Seguridad</span></div>
    <label class="row small" style="gap:12px;margin:4px 0 12px;align-items:flex-start"><input type="checkbox" data-mc="isAdult" ${e.isAdult?'checked':''} style="width:22px;height:22px;accent-color:var(--gold);flex:none"> <span>Confirmo que tengo <b>18 años o más</b>, que las fotos son mías o de mi trabajo y que respetaré las <button type="button" class="link" data-a="rules">normas de la comunidad</button>.</span></label>
    ${!isNew?`<label class="row small" style="gap:12px;margin:0 0 16px"><input type="checkbox" data-mc="active" ${e.active?'checked':''} style="width:22px;height:22px;accent-color:var(--gold);flex:none"> <span>Mostrar mi perfil en Match</span></label>`:''}
    <button class="btn btn-primary btn-block" data-a="mSave">${isNew?'Crear mi perfil de Match':'Guardar cambios'}</button>
    ${!isNew?`<button class="btn btn-block" style="margin-top:10px;color:var(--red)" data-a="mDelete">${icon('trash')} Eliminar mi perfil de Match</button>`:''}
    ${M.blocks.length?`<button class="btn btn-block" style="margin-top:6px;color:var(--muted)" data-a="mBlocked">${icon('ban')} Personas bloqueadas (${M.blocks.length})</button>`:''}
    <div style="height:30px"></div>
  </div></div>`;
}, after(){ if(matchState().profile===undefined) loadMatchState().then(()=>{ if(current().name==='matchProfile') refresh(); }); } };
document.addEventListener('input',ev=>{ const el=ev.target; if(el.dataset.m && medit){ medit[el.dataset.m]=el.value; if(el.dataset.m==='about'){ const c=$('#mAboutCount'); if(c) c.textContent=el.value.length+'/500'; } if(el.dataset.m==='country'||el.dataset.m==='city'){ if(el.dataset.m==='country') medit.countryCode=''; } } });
document.addEventListener('change',ev=>{ const el=ev.target; if(el.dataset.mc && medit) medit[el.dataset.mc]=el.checked; });
A.mPick=el=>{ medit[el.dataset.k]=el.dataset.v; $$('.chip',el.parentElement).forEach(c=>c.classList.toggle('on',c===el)); };
A.mToggle=el=>{ const arr=medit[el.dataset.k]=medit[el.dataset.k]||[]; const v=el.dataset.v; const i=arr.indexOf(v); if(i>=0) arr.splice(i,1); else { if(el.dataset.k==='languages'&&arr.length>=8) return toast('Máximo 8 idiomas'); arr.push(v); } el.classList.toggle('on'); };
A.mPhotoAdd=async()=>{ const free=MATCH_MAX_PHOTOS-medit.photos.length; if(free<=0) return; const imgs=await pickImages({multiple:true,max:1080,quality:.84}); if(!imgs.length) return; if(imgs.length>free) toast(`Solo caben ${MATCH_MAX_PHOTOS} fotos`); medit.photos.push(...imgs.slice(0,free)); refresh(); };
A.mPhotoMenu=el=>{ const i=+el.dataset.i; showSheet(`${i>0?`<button class="opt" data-a="mPhotoMain" data-i="${i}">${icon('star')} Hacer principal</button>`:''}<button class="opt" data-a="mPhotoReplace" data-i="${i}">${icon('image')} Cambiar foto</button><button class="opt danger" data-a="mPhotoDel" data-i="${i}">${icon('trash')} Quitar</button>`); };
A.mPhotoMain=el=>{ const i=+el.dataset.i; const [p]=medit.photos.splice(i,1); medit.photos.unshift(p); closeOverlay(); refresh(); };
A.mPhotoDel=el=>{ medit.photos.splice(+el.dataset.i,1); closeOverlay(); refresh(); };
A.mPhotoReplace=async el=>{ const i=+el.dataset.i; closeOverlay(); const [img]=await pickImages({max:1080,quality:.84}); if(img){ medit.photos[i]=img; refresh(); } };
let locating=false;
A.mLocate=async el=>{ if(locating) return; locating=true; const label=el.innerHTML; el.disabled=true; el.innerHTML=`<span class="spinner sm"></span> Buscando tu ubicación…`;
  try{
    const coords=await getCoords();
    el.innerHTML=`<span class="spinner sm"></span> Buscando tu ciudad…`;
    const place=await reverseGeocode(coords);
    medit.coords=coords; medit.clearCoords=false;
    if(place){ medit.country=place.country; medit.countryCode=place.countryCode; medit.city=place.city; toast(`Ubicación: ${placeText(place)||'lista'}`); }
    else toast('Ubicación lista. Escribe tu ciudad a mano si no aparece.');
  }catch(e){ showDialog({title:'Ubicación',text:geoErrorText(e),ok:'Entendido',cancel:''}); }
  finally{ locating=false; if(document.body.contains(el)){ el.disabled=false; el.innerHTML=label; } if(current().name==='matchProfile' && !overlayOpen()) refresh(); }
};
A.mClearLoc=()=>{ medit.coords=null; medit.clearCoords=true; medit.hasLocation=false; refresh(); };
A.mCancel=()=>{ medit=null; back(); };
let mSaving=false;
A.mSave=async()=>{
  if(mSaving) return; const e=medit; const M=matchState();
  if(e.photos.length<MATCH_MIN_PHOTOS) return toast(`Sube al menos ${MATCH_MIN_PHOTOS} fotos`);
  if((e.about||'').trim().length<20) return toast('Cuéntanos un poco más sobre ti (mínimo 20 caracteres)');
  if(!e.lookingFor.length) return toast('Elige al menos una cosa que te interese');
  if(e.portfolio && !/^https?:\/\/\S{4,300}$/i.test(e.portfolio.trim())) return toast('El portafolio debe ser un enlace que empiece por https://');
  if(!e.isAdult) return toast('Debes confirmar que tienes 18 años o más');
  if(!e.coords && !e.hasLocation && !(e.city||'').trim()) return toast('Usa tu ubicación o escribe tu ciudad');
  if(isToxic(e.about)) return toast('Tu descripción contiene lenguaje no permitido');
  mSaving=true; showProgress(M.profile?'Guardando perfil':'Creando tu perfil');
  try{ M.profile=await DB.saveMatchProfile(S,e,setProgress); }
  catch(err){ closeOverlay(); mSaving=false; return toast(errMsg(err)); }
  mSaving=false; closeOverlay(); const wasNew=!stack.some(s=>s.name==='match')||!M.cands; medit=null; M.cands=null; M.lastPass=null;
  back(); toast(wasNew?'¡Listo! Ya apareces en Match':'Perfil de Match actualizado');
};
A.mDelete=()=>showDialog({title:'¿Eliminar tu perfil de Match?',text:'Se borran tus fotos de Match y dejas de aparecer. Tus matches desaparecen, pero los chats se conservan.',ok:'Eliminar',danger:true,onOk:async()=>{
  const M=matchState(); try{ await DB.deleteMatchProfile(S); }catch(e){ return toast(errMsg(e)); }
  M.profile=null; M.cands=null; M.matches=[]; medit=null; back(); toast('Perfil de Match eliminado'); }});
A.mBlocked=async()=>{ const M=matchState(); await DB.ensureProfiles(S,M.blocks).catch(()=>{});
  showSheet(M.blocks.map(id=>{ const u=S.byId[id]; return `<div class="opt" style="justify-content:space-between">${u?`${avatarHTML(u,'av-sm')} <span class="grow">${nameHTML(u)}</span>`:'<span class="grow">Cuenta eliminada</span>'}<button class="btn btn-ghost btn-sm" data-a="unblockUser" data-id="${id}">Desbloquear</button></div>`; }).join('')||'<p class="pad muted">No has bloqueado a nadie.</p>','Personas bloqueadas'); };

A.invite=()=>shareText('Únete a CHOGGUN','La comunidad para escritores, ilustradores y lectores. Publica tus obras y encuentra colaboradores.');

/* ======================= CHAT ======================= */
SCREENS.chats={ render(){
  const list=myChats();
  return `${topbar({title:'Mensajes',actions:`<button class="icon-btn" data-a="newChat" aria-label="Nuevo mensaje">${icon('edit')}</button>`})}<div class="scroll">${list.length?list.map(c=>{ const last=c.msgs.at(-1); return `<button class="li conv" data-a="openChat" data-u="${c.with}">${avatarHTML(c.with)}<span class="txt"><b>${nameHTML(c.with)}</b><span style="${c.unreadMe?'color:var(--text);font-weight:700':''}">${last?(last.from===S.session?'Tú: ':'')+(last.img&&!last.text?'Imagen':esc(last.text)):'¡Saluda!'}</span></span><span class="tiny faint" style="text-align:right">${last?timeAgo(last.t):''}${c.unreadMe?'<br><span class="unread-dot" style="display:inline-block;margin-top:4px"></span>':''}</span></button>`; }).join(''):emptyHTML('chat','Sin conversaciones','Escríbele a alguien desde su perfil o desde el botón de nuevo mensaje.',`<button class="btn btn-primary" data-a="tab" data-t="explore">Buscar creadores</button>`)}</div>`; } };
A.openChat=el=>go('chat',{id:el.dataset.u});
A.newChat=()=>{ const pool=S.following.filter(u=>S.users[u]); showSheet(pool.length?pool.map(u=>`<button class="opt" data-a="dmUser" data-u="${u}">${avatarHTML(u,'av-sm')} ${nameHTML(u)}</button>`).join(''):`<p class="pad muted">Sigue a creadores para escribirles desde aquí, o entra a un perfil y toca el botón de mensaje.</p>`,'Nuevo mensaje'); };
function msgHTML(m){ return `<div class="msg ${m.from===S.session?'me':'them'} ${m.pending?'pending':''}">${m.img?`<img src="${m.img}" alt="">`:''}${m.text?esc(m.text):''}<time>${m.pending?'enviando…':clock(m.t)}</time></div>`; }
SCREENS.chat={ noNav:true, render(p){
  const u=user(p.id); const c=S.chats[chatId(p.id)]||{msgs:[]};
  let msgs='', lastDay='';
  c.msgs.forEach(m=>{ const d=dayLabel(m.t); if(d!==lastDay){ msgs+=`<div class="day-sep">${d}</div>`; lastDay=d; } msgs+=msgHTML(m); });
  return `<header class="topbar"><button class="icon-btn" data-a="back">${icon('back')}</button><button class="row grow" style="gap:10px;text-align:left" data-a="user" data-u="${u.username}">${avatarHTML(u,'av-sm')}<span class="grow" style="line-height:1.15"><b class="ellipsis" style="display:block">${nameHTML(u.username)}</b><span class="tiny muted">${esc(u.role)}</span></span></button><button class="icon-btn" data-a="chatMenu" data-u="${u.username}">${icon('more')}</button></header>
  <div class="scroll" id="msgScroll"><div class="msgs" id="msgs">${msgs||`<div class="empty">${icon('message-circle','class="empty-ic"')}<div class="small">Rompe el hielo: cuéntale a ${esc(u.name.split(' ')[0])} sobre tu proyecto.</div></div>`}</div></div>
  <form class="composer" data-f="chat" data-u="${u.username}"><button type="button" class="icon-btn" data-a="chatImg" style="width:40px;height:40px">${icon('camera')}</button><textarea name="text" rows="1" placeholder="Escribe un mensaje…" maxlength="2000"></textarea><button class="send-btn" aria-label="Enviar">${icon('send')}</button></form>`;
}, after(p){ const c=S.chats[chatId(p.id)]; if(c&&c.unread&&c.unread[S.session]){ c.unread[S.session]=false; const o=S.users[p.id]; if(o) DB.markChatRead(S.uid,o.id).catch(()=>{}); updateBadges(); } const sc=$('#msgScroll'); if(sc) sc.scrollTop=sc.scrollHeight; } };
async function pushMsg(u,{text,img}){
  const c=ensureChat(u); const tmp={id:'tmp'+Date.now(),from:S.session,text:text||'',img:img||null,t:Date.now(),pending:true};
  c.msgs.push(tmp); appendMsg(tmp);
  try{
    const row=await DB.sendMessage(S,u,{text,img});
    c.msgs=c.msgs.filter(x=>x!==tmp); DB.addMessage(S,row);
  }catch(e){ c.msgs=c.msgs.filter(x=>x!==tmp); toast(errMsg(e)); }
  const cur=current(); if(cur.name==='chat'&&cur.params.id===u){ const box=$('#msgs'); if(box){ box.innerHTML=chatMsgsHTML(u); const sc=$('#msgScroll'); sc.scrollTop=sc.scrollHeight; } }
}
function appendMsg(m){ const box=$('#msgs'); if(box){ $$('.empty',box).forEach(x=>x.remove()); box.insertAdjacentHTML('beforeend',msgHTML(m)); const sc=$('#msgScroll'); sc.scrollTop=sc.scrollHeight; } }
function chatMsgsHTML(u){ const c=S.chats[chatId(u)]||{msgs:[]}; let msgs='', lastDay=''; c.msgs.forEach(m=>{ const d=dayLabel(m.t); if(d!==lastDay){ msgs+=`<div class="day-sep">${d}</div>`; lastDay=d; } msgs+=msgHTML(m); }); return msgs; }
F.chat=form=>{ const ta=$('textarea',form); const text=ta.value.trim(); if(!text) return; const u=form.dataset.u;
  if(isToxic(text)){ toast('Mantén el respeto: tu mensaje contiene lenguaje ofensivo'); return; }
  ta.value=''; ta.style.height='auto'; pushMsg(u,{text}); };
A.chatImg=async()=>{ const u=current().params.id; const [img]=await pickImages({max:1100}); if(img) pushMsg(u,{text:'',img}); };
A.chatMenu=el=>{ const u=el.dataset.u; showSheet(`<button class="opt" data-a="user" data-u="${u}">${icon('user')} Ver perfil</button><button class="opt" data-a="clearChat" data-u="${u}">${icon('trash')} Vaciar conversación</button>${isBlocked(u)?`<button class="opt" data-a="unblockUser" data-id="${S.users[u].id}">${icon('ban')} Desbloquear</button>`:`<button class="opt danger" data-a="blockUser" data-u="${u}">${icon('ban')} Bloquear</button>`}<button class="opt danger" data-a="report" data-kind="user" data-id="${u}">${icon('flag')} Reportar usuario</button>`); };
A.clearChat=async el=>{ const u=el.dataset.u; const o=S.users[u]; closeOverlay(); try{ await DB.clearChat(o.id); }catch(e){ return toast(errMsg(e)); } S.clears[o.id]=Date.now(); const c=S.chats[chatId(u)]; if(c){ c.msgs=[]; c.unread={}; } refresh(); };
document.addEventListener('keydown',e=>{ if(e.key==='Enter'&&!e.shiftKey&&e.target.matches('.composer textarea')){ e.preventDefault(); e.target.form.requestSubmit(); } });

/* ======================= NOTIFICACIONES ======================= */
const NI={vote:['up','var(--gold)'],comment:['comment','var(--blue)'],match:['heart','var(--red)'],follow:['userPlus','var(--green)'],system:['sparkles','var(--gold)'],mod:['shield','var(--purple)']};
SCREENS.notifs={ render(){
  const list=myNotifs();
  return `${topbar({title:'Notificaciones',actions:list.some(n=>!n.read)?`<button class="btn btn-sm" style="color:var(--gold)" data-a="readAll">Leer todo</button>`:''})}<div class="scroll">${list.length?list.map(n=>{ const [ic,col]=NI[n.type]||NI.system; return `<button class="notif ${n.read?'':'unread'}" data-a="openNotif" data-id="${n.id}"><span class="ni" style="background:color-mix(in srgb,${col} 18%,transparent);color:${col}">${icon(ic,n.type==='match'?'fill="currentColor"':'')}</span><span class="grow"><p>${n.text}</p><span class="tiny faint">${timeAgo(n.t)}</span></span>${n.read?'':'<span class="unread-dot" style="margin-top:6px"></span>'}</button>`; }).join(''):emptyHTML('bell','Todo al día','Aquí verás votos, comentarios, nuevos seguidores y matches.')}</div>`; } };
A.readAll=()=>{ S.notifRows.forEach(n=>n.read=true); refresh(); updateBadges(); DB.markAllNotifsRead(S.uid).catch(()=>{}); };
A.openNotif=async el=>{ const row=S.notifRows.find(x=>String(x.id)===el.dataset.id); if(!row) return; const n=notifView(row);
  if(!row.read){ row.read=true; DB.markNotifRead(row.id).catch(()=>{}); updateBadges(); }
  if(n.link){ const {s,...p}=n.link;
    if(s==='work'&&!work(p.id)){ try{ await DB.refreshWork(S,p.id); }catch(e){} if(!work(p.id)) return toast('Esta obra ya no existe'); }
    if(s==='user'&&!S.users[p.u]) return toast('Esta cuenta ya no existe');
    go(s,p); } else refresh(); };

/* ======================= PERFIL ======================= */
function profileHTML(u,own){
  const x=user(u); const works=S.works.filter(w=>w.author===u&&w.status==='publicado'&&!w.removed);
  if(!own && UI.profileTab==='comunidades' && !S.joined[u]){ S.joined[u]=[]; DB.loadUserCommunities(x.id).then(ids=>{ S.joined[u]=ids; refresh(); },()=>{}); }
  const collabWorks=S.works.filter(w=>w.status==='publicado'&&!w.removed&&(w.credits||[]).some(c=>c.user===u));
  const tabs=own?[['obras','Obras'],['guardados','Guardados'],['borradores','Borradores'],['comunidades','Comunidades']]:[['obras','Obras'],['colabs','Colaboraciones'],['comunidades','Comunidades']];
  if(!tabs.some(t=>t[0]===UI.profileTab)) UI.profileTab='obras';
  let body='';
  if(UI.profileTab==='obras') body=works.length?works.sort((a,b)=>b.created-a.created).map(postCard).join(''):emptyHTML('pen-tool',own?'Aún no has publicado':'Sin publicaciones',own?'Comparte tu primera novela, manga, cómic o ilustración.':'Esta persona todavía no ha publicado.',own?`<button class="btn btn-primary" data-a="create">Publicar</button>`:'');
  if(UI.profileTab==='colabs') body=collabWorks.length?collabWorks.map(postCard).join(''):emptyHTML('heart-handshake','Sin colaboraciones','Aún no aparece en los créditos de otras obras.');
  if(UI.profileTab==='guardados'){ const ws=(S.saved[u]||[]).map(work).filter(Boolean); body=ws.length?ws.map(postCard).join(''):emptyHTML('bookmark','Tu biblioteca está vacía','Guarda obras para leerlas después.'); }
  if(UI.profileTab==='borradores'){ const ds=S.works.filter(w=>w.author===u&&w.status==='borrador'); body=ds.length?`<div class="list">${ds.map(w=>`<div class="li"><div class="cover" style="width:44px">${coverHTML(w)}</div><span class="txt"><b>${esc(w.title)}</b><span>${FORMATS[w.type].label} · ${timeAgo(w.created)}</span></span><button class="btn btn-primary btn-sm" data-a="editWork" data-id="${w.id}">Editar</button><button class="icon-btn" data-a="deleteWork" data-id="${w.id}">${icon('trash')}</button></div>`).join('')}</div>`:emptyHTML('file','Sin borradores','Los borradores que guardes aparecerán aquí.'); }
  if(UI.profileTab==='comunidades'){ const cs=(S.joined[u]||[]).map(community).filter(Boolean); body=cs.length?`<div class="list">${cs.map(commRow).join('')}</div>`:emptyHTML('users','Sin comunidades','No se ha unido a ninguna comunidad.'); }
  return `<div class="banner">${x.bannerImg?`<img src="${x.bannerImg}" alt="">`:bannerSVG(x.banner||u)}</div>
  <div class="profile-head"><div class="row top">${avatarHTML(x,'av-xl')}<div class="row" style="gap:8px;padding-bottom:6px">${own?`<button class="btn btn-ghost btn-sm" data-a="go" data-s="editProfile">${icon('edit')} Editar</button>`:`${followBtn(u)}<button class="btn btn-ghost btn-sm" data-a="dmUser" data-u="${u}">${icon('chat')}</button>`}</div></div>
  <div class="h2" style="margin-top:10px">${nameHTML(u)}</div><div class="small muted">@${esc(u)} · Se unió ${new Date(x.joined||Date.now()).toLocaleDateString('es-CO',{month:'long',year:'numeric'})}</div>
  <div class="row wrap" style="gap:6px;margin-top:8px"><span class="tag ${x.role==='Ilustrador/a'?'blue':x.role==='Escritor/a'?'':'green'}">${icon(ROLE_ICONS[x.role]||'user','width="12" height="12"')} ${esc(x.role||'Lector/a')}</span>${(x.genres||[]).map(g=>`<span class="tag gray">${esc(g)}</span>`).join('')}</div>
  ${x.bio?`<p style="margin-top:10px;white-space:pre-wrap">${esc(x.bio)}</p>`:own?`<p class="muted small" style="margin-top:10px">Añade una biografía para que otros creadores te conozcan.</p>`:''}
  ${(x.collab||[]).length?`<div class="small" style="margin-top:8px"><span class="muted">Busca:</span> ${x.collab.map(esc).join(' · ')}</div>`:''}
  <div class="stats" style="margin-top:14px"><div class="stat"><b>${Math.max(works.length,x.workCount||0)}</b><span>Obras</span></div><div class="stat"><b>${fmtNum(followersCount(u))}</b><span>Seguidores</span></div><div class="stat"><b>${fmtNum(x.followingCount||0)}</b><span>Siguiendo</span></div><div class="stat"><b>${fmtNum(karmaOf(u))}</b><span>Karma</span></div></div></div>
  <div class="tabs" style="margin-top:14px">${tabs.map(([k,l])=>`<button class="tab ${UI.profileTab===k?'on':''}" data-a="profileTab" data-k="${k}">${l}</button>`).join('')}</div>
  <div class="pad">${body}</div>`;
}
SCREENS.profile={ render(){
  const m=me();
  if(!m) return `${topbar({back:false,title:'Perfil',actions:`<button class="icon-btn" data-a="appearance">${icon('sun-moon')}</button><button class="icon-btn" data-a="go" data-s="settings">${icon('gear')}</button>`})}<div class="scroll pb-nav"><div class="empty" style="padding-top:60px"><img src="${ASSETS.logo}" alt="" style="width:130px;height:130px"><div class="h2">Tu espacio creativo</div><div class="small" style="max-width:300px">Crea una cuenta para publicar, guardar obras, seguir creadores y hacer match.</div><button class="btn btn-primary" style="margin-top:10px" data-a="go" data-s="auth" data-mode="register">Crear cuenta</button><button class="btn btn-ghost" data-a="go" data-s="auth" data-mode="login">Ya tengo cuenta</button></div></div>`;
  return `${topbar({back:false,title:'@'+esc(m.username),actions:`<button class="icon-btn" data-a="appearance" aria-label="Apariencia">${icon('sun-moon')}</button><button class="icon-btn" data-a="go" data-s="notifs">${icon('bell')}<span class="badge" data-badge="notifs" style="display:none"></span></button><button class="icon-btn" data-a="go" data-s="settings" aria-label="Ajustes">${icon('gear')}</button>`})}<div class="scroll pb-nav">${profileHTML(m.username,true)}</div>`;
}, after(){ updateBadges(); } };
SCREENS.user={ render(p){ if(!S.users[p.u]) return topbar({title:'Perfil'})+(S.loaded?emptyHTML('user','Esta cuenta no existe','Puede que haya sido eliminada.'):'<div class="empty"><div class="spinner"></div></div>'); const x=user(p.u); return `${topbar({title:esc(x.name),actions:`<button class="icon-btn" data-a="userMenu" data-u="${p.u}">${icon('more')}</button>`})}<div class="scroll" style="padding-bottom:30px">${profileHTML(p.u,false)}</div>`; } };
A.profileTab=el=>{ UI.profileTab=el.dataset.k; refresh(); };
A.dmUser=el=>{ if(!requireAuth('enviar mensajes')) return; const u=el.dataset.u; if(u===S.session) return; closeOverlay(); ensureChat(u); go('chat',{id:u}); };
A.userMenu=el=>{ const u=el.dataset.u; showSheet(`<button class="opt" data-a="shareUser" data-u="${u}">${icon('share')} Compartir perfil</button>${S.session&&u!==S.session?(isBlocked(u)?`<button class="opt" data-a="unblockUser" data-id="${S.users[u].id}">${icon('ban')} Desbloquear</button>`:`<button class="opt danger" data-a="blockUser" data-u="${u}">${icon('ban')} Bloquear</button>`):''}<button class="opt danger" data-a="report" data-kind="user" data-id="${u}">${icon('flag')} Reportar usuario</button>`); };
A.shareUser=el=>{ const x=user(el.dataset.u); shareText(`${x.name} (@${x.username}) en CHOGGUN`,x.bio||''); };

/* ---------- editar perfil ---------- */
let pedit=null;
SCREENS.editProfile={ noNav:true, render(p){
  const m=me(); if(!pedit||pedit.username!==m.username) pedit=JSON.parse(JSON.stringify(m));
  const e=pedit;
  return `${topbar({title:p.first?'Completa tu perfil':'Editar perfil',actions:`<button class="btn btn-primary btn-sm" style="margin-right:6px" data-a="saveProfile">Guardar</button>`}).replace('data-a="back"','data-a="cancelProfile"')}
  <div class="scroll"><div class="banner" style="height:110px">${e.bannerImg?`<img src="${e.bannerImg}" alt="">`:bannerSVG(e.banner||e.username)}<div class="row" style="position:absolute;right:10px;bottom:10px;gap:6px"><button class="btn btn-sm" style="background:rgba(0,0,0,.55);color:#fff" data-a="uploadBanner">${icon('image')} Foto</button><button class="btn btn-sm" style="background:rgba(0,0,0,.55);color:#fff" data-a="newBanner">${icon('refresh')}</button></div></div>
  <div class="pad">${p.first?`<div class="banner-tip" style="margin-bottom:16px"><img src="${ASSETS.logo}" alt=""><div class="small">Elige tu avatar y tus géneros favoritos: así apareces en Match con otros creadores afines.</div></div>`:''}
  <div class="field"><span>Foto de perfil</span><div class="av-pick"><button class="${e.avatar?'':'on'}" data-a="pickAvatar" data-v="" aria-label="Sin foto"><img src="${ASSETS.avdef}" alt=""></button>${e.avatar?`<button class="on" aria-label="Tu foto"><img src="${e.avatar}" alt=""></button>`:''}<button class="up" data-a="uploadAvatar" aria-label="Subir foto">${icon('camera')}</button></div><div class="hint">Deja la silueta o sube una foto o imagen desde tu teléfono.</div></div>
  <label class="field"><span>Nombre visible</span><input class="input" data-p="name" value="${esc(e.name)}" maxlength="40"></label>
  <label class="field"><span>Biografía <b class="faint" id="bioCount">${(e.bio||'').length}/160</b></span><textarea class="textarea" data-p="bio" maxlength="160" style="min-height:80px" placeholder="Cuéntanos qué creas y qué buscas…">${esc(e.bio||'')}</textarea></label>
  <div class="field"><span>Rol principal</span><div class="chips wrap">${ROLES.map(r=>`<button class="chip ${e.role===r?'on':''}" data-a="pRole" data-v="${r}">${icon(ROLE_ICONS[r])} ${r}</button>`).join('')}</div></div>
  <div class="field"><span>Géneros favoritos</span><div class="chips wrap">${GENRES.map(g=>`<button class="chip ${(e.genres||[]).includes(g)?'on':''}" data-a="pToggle" data-k="genres" data-v="${esc(g)}">${esc(g)}</button>`).join('')}</div></div>
  <div class="field"><span>Tipo de colaboración que buscas</span><div class="chips wrap">${COLLABS.map(c=>`<button class="chip ${(e.collab||[]).includes(c)?'on':''}" data-a="pToggle" data-k="collab" data-v="${esc(c)}">${esc(c)}</button>`).join('')}</div></div>
  <button class="btn btn-primary btn-block" style="margin-top:6px" data-a="saveProfile">Guardar perfil</button></div></div>`;
} };
document.addEventListener('input',e=>{ const el=e.target; if(el.dataset.p && pedit){ pedit[el.dataset.p]=el.value; if(el.dataset.p==='bio'){ const c=$('#bioCount'); if(c) c.textContent=el.value.length+'/160'; } } });
A.pickAvatar=el=>{ pedit.avatar=el.dataset.v||null; refresh(); };
A.uploadAvatar=async()=>{ const [img]=await pickImages({max:480,quality:.86}); if(img){ pedit.avatar=img; refresh(); } };
A.uploadBanner=async()=>{ const [img]=await pickImages({max:1200,quality:.82}); if(img){ pedit.bannerImg=img; refresh(); } };
A.newBanner=()=>{ pedit.banner=pedit.username+Math.random().toString(36).slice(2,6); pedit.bannerImg=null; refresh(); };
A.pRole=el=>{ pedit.role=el.dataset.v; $$('.chip',el.parentElement).forEach(c=>c.classList.toggle('on',c===el)); };
A.pToggle=el=>{ const arr=pedit[el.dataset.k]=pedit[el.dataset.k]||[]; const v=el.dataset.v; const i=arr.indexOf(v); if(i>=0) arr.splice(i,1); else arr.push(v); el.classList.toggle('on'); };
A.cancelProfile=()=>{ pedit=null; back(); };
let savingProfile=false;
A.saveProfile=async()=>{ if(savingProfile) return; if(!pedit.name.trim()) return toast('El nombre no puede estar vacío'); if(isToxic(pedit.name+' '+pedit.bio)) return toast('Tu perfil contiene lenguaje no permitido');
  savingProfile=true; showProgress('Guardando perfil');
  try{ await DB.updateProfile(S,pedit); }catch(e){ closeOverlay(); savingProfile=false; return toast(errMsg(e)); }
  savingProfile=false; closeOverlay(); pedit=null; const first=current().params.first; back(); toast(first?'¡Perfil listo! Ya puedes publicar':'Perfil actualizado'); };

/* ======================= AJUSTES ======================= */
SCREENS.settings={ render(){
  const s=S.settings; const m=me();
  const row=(ic,title,sub,act,extra='',right='')=>`<button class="li" ${act?`data-a="${act}"`:''} ${extra}><span class="ic">${icon(ic)}</span><span class="txt"><b>${title}</b>${sub?`<span>${sub}</span>`:''}</span>${right||icon('chevR','class="chev"')}</button>`;
  const tog=(k)=>`<span class="toggle ${s[k]?'on':''}"></span>`;
  return `${topbar({title:'Ajustes'})}<div class="scroll"><div class="pad">
  ${m?`<div class="section-label"><span>Cuenta</span></div><div class="list">${row('user','Editar perfil','@'+esc(m.username),'go','data-s="editProfile"')}${row('lock','Cambiar contraseña','','changePw')}${row('mail','Correo',esc(S.email||''),'')}</div>`:''}
  <div class="section-label"><span>Apariencia</span></div><div class="card" style="padding:14px">${appearanceHTML()}
   <div class="field" style="margin-top:14px"><span>Opacidad de publicaciones · <b id="opv">${Math.round(s.cardOpacity*100)}%</b></span><input type="range" min="30" max="100" value="${Math.round(s.cardOpacity*100)}" data-i="cardOpacity"></div>
   <div class="field" style="margin:0"><span>Tamaño de lectura · <b id="rsv2">${s.readerSize}px</b></span><input type="range" min="14" max="26" value="${s.readerSize}" data-i="readerSize2"></div></div>
  <div class="section-label"><span>Preferencias</span></div><div class="list">${row('bell','Notificaciones','Avisos de votos, comentarios y matches','togSetting','data-k="notifications"',tog('notifications'))}${row('eyeOff','Mostrar contenido sensible (+18)','Contenido marcado por sus autores','togSetting','data-k="mature"',tog('mature'))}</div>
  <div class="section-label"><span>Comunidad y seguridad</span></div><div class="list">${row('shield','Normas de la comunidad','Respeto, créditos y derechos de autor','rules')}${m?row('flag','Mis reportes',`${S.reports.filter(r=>r.by===S.session).length} enviados`,'go','data-s="reports" data-mode="mine"'):''}${m&&m.isMod?row('shield-check','Panel de moderación','Revisión humana de reportes','go','data-s="reports" data-mode="mod"'):''}</div>
  <div class="section-label"><span>Datos</span></div><div class="list">${m?row('download','Exportar mis datos','Copia tus datos en formato JSON','exportData'):''}${row('refresh','Borrar caché del dispositivo','Noticias guardadas y ajustes de este teléfono','resetAll')}${m?row('trash','Eliminar mi cuenta','Borra tu perfil, obras, comentarios y mensajes','deleteAccount'):''}</div>
  <div class="section-label"><span>Acerca de</span></div><div class="card" style="padding:16px;text-align:center"><img src="${ASSETS.logo}" alt="" style="width:80px;height:80px;margin:0 auto 8px"><div class="h2 gold" style="letter-spacing:.12em">CHOGGUN</div><div class="tiny muted">Versión ${APP_VERSION}</div><p class="small" style="margin:10px 0">Plataforma digital colaborativa de contenido literario para escritores, ilustradores y lectores.</p><div class="tiny muted">Semillero SIIANTEC · Tecnólogo en Desarrollo de Software<br>Corporación Tecnológica Industrial Colombiana — TEINCO<br>William Monsalve · Nicolás Arias · Johan Marroquín<br>Bogotá, 2026<br><br>Iconos: Lucide (ISC) · Noticias: ${NEWS_FEEDS.map(f=>esc(f.name)).filter((v,i,a)=>a.indexOf(v)===i).join(', ')}</div></div>
  ${m?`<button class="btn btn-block" style="margin-top:18px;color:var(--red);border:1.5px solid var(--red)" data-a="logout">${icon('logout')} Cerrar sesión</button>`:`<button class="btn btn-primary btn-block" style="margin-top:18px" data-a="go" data-s="auth" data-mode="login">Iniciar sesión</button>`}
  <div style="height:30px"></div></div></div>`; } };
I.cardOpacity=el=>{ S.settings.cardOpacity=el.value/100; $('#opv').textContent=el.value+'%'; applyTheme(); save(); };
I.readerSize2=el=>{ S.settings.readerSize=+el.value; $('#rsv2').textContent=el.value+'px'; save(); };
A.togSetting=el=>{ const k=el.dataset.k; S.settings[k]=!S.settings[k]; save(); refresh(); };
A.changePw=()=>{ showDialog({title:'Cambiar contraseña',html:`<input class="input" type="password" id="pw0" placeholder="Contraseña actual" style="margin-top:10px"><input class="input" type="password" id="pw1" placeholder="Nueva contraseña" style="margin-top:8px"><div class="err" id="pwErr"></div>`,ok:'Cambiar'}); $('#overlay [data-a=dialogOk]').dataset.a='pwOk'; };
A.pwOk=async()=>{ const a=$('#pw0').value, b=$('#pw1').value; const err=$('#pwErr');
  if(!passOk(b)) return err.textContent='Mínimo 6 caracteres, un número y una minúscula';
  err.textContent='Guardando…';
  try{ await DB.changePassword(S.email,a,b); }catch(e){ return err.textContent=errMsg(e); }
  closeOverlay(); toast('Contraseña actualizada'); };
A.rules=()=>showSheet(`<div style="padding:0 18px 10px" class="stack small">${[['handshake','Respeto ante todo','Critica la obra, no a la persona. El feedback debe ser constructivo.'],['pen-tool','Da crédito siempre','Si colaboras, registra a todos en Créditos. Nada de apropiarse del trabajo ajeno.'],['copyright','Respeta los derechos de autor','Publica solo contenido propio o con permiso. El plagio se retira.'],['eye-off','Etiqueta el contenido sensible','Marca como +18 cualquier contenido sexual o violencia gráfica.'],['ban','Cero acoso y spam','El acoso, el discurso de odio y la publicidad no solicitada están prohibidos.'],['shield','Reporta lo que veas mal','Usa Reportar: la moderación combina detección automática y revisión humana.']].map(([ic,t,d])=>`<div class="row" style="align-items:flex-start;gap:12px"><span class="rule-ic">${icon(ic)}</span><div><b>${t}</b><div class="muted">${d}</div></div></div>`).join('')}</div>`,'Normas de la comunidad');
A.exportData=()=>{ const m=me(); const data={perfil:{...m,correo:S.email},obras:S.works.filter(w=>w.author===m.username).map(w=>({...w,comments:undefined})),guardados:S.saved[m.username]||[],comunidades:S.joined[m.username]||[],siguiendo:S.following,historial:S.history[m.username]||{}};
  const json=JSON.stringify(data,null,2);
  navigator.clipboard.writeText(json).then(()=>toast('Tus datos (JSON) se copiaron al portapapeles')).catch(()=>shareText('Mis datos de CHOGGUN',json)); };
A.resetAll=()=>showDialog({title:'¿Borrar la caché?',text:'Se borran las noticias guardadas y los ajustes de apariencia de este teléfono. Tu cuenta y tus obras siguen en la nube.',ok:'Borrar',danger:true,onOk:()=>{ try{ localStorage.removeItem(KEY); localStorage.removeItem(NEWS_KEY); }catch(e){} S.settings={...defaultSettings(),onboarded:true}; NEWS.items=[]; NEWS.t=0; save(true); applyTheme(); refresh(); toast('Caché borrada'); loadNews(true); }});
A.deleteAccount=()=>showDialog({title:'¿Eliminar tu cuenta?',text:'Se borrarán para siempre tu perfil, tus obras, comentarios, mensajes y archivos. No se puede deshacer.',html:`<input class="input" id="delConfirm" placeholder="Escribe ELIMINAR para confirmar" style="margin-top:10px" autocapitalize="characters"><div class="err" id="delErr"></div>`,ok:'Eliminar cuenta',danger:true});
document.addEventListener('click',e=>{ const b=e.target.closest('#overlay [data-a=dialogOk]'); if(!b||!$('#delConfirm')) return; e.stopPropagation(); e.preventDefault();
  if($('#delConfirm').value.trim().toUpperCase()!=='ELIMINAR'){ $('#delErr').textContent='Escribe ELIMINAR para confirmar'; return; }
  $('#delErr').textContent='Eliminando…';
  DB.deleteMyAccount(S.uid).then(()=>{ closeOverlay(); endSession(); stack=[{name:'auth',params:{mode:'login',first:true}}]; render(); toast('Tu cuenta fue eliminada'); },err=>{ $('#delErr').textContent=errMsg(err); });
},true);
A.logout=()=>showDialog({title:'¿Cerrar sesión?',text:'Podrás volver a entrar cuando quieras.',ok:'Cerrar sesión',danger:true,onOk:async()=>{ await DB.signOut(); endSession(); stack=[{name:'auth',params:{mode:'login',first:true}}]; render(); toast('Sesión cerrada'); }});

/* ======================= REPORTES / MODERACIÓN ======================= */
function reportTargetMod(r){
  const t=r.target;
  if(r.kind==='work') return t?`${(FORMATS[t.type]||FORMATS.foro).label}: “${esc(t.title)}” de ${esc(t.author)}`:'Obra eliminada';
  if(r.kind==='comment') return t?`Comentario de ${esc(t.author)}: “${esc(t.text)}”`:'Comentario eliminado';
  return t?`Usuario ${esc(t.name)} (@${esc(t.username)})`:`Usuario @${esc(r.targetId)}`;
}
function reportTarget(r){
  if(r.kind==='work'){ const w=work(r.id); return w?`${FORMATS[w.type].label}: “${esc(w.title)}” de ${esc(user(w.author).name)}`:'Obra eliminada'; }
  if(r.kind==='comment'){ const w=work(r.parent); let c=null; if(w&&w.comments){ for(const x of w.comments){ if(x.id===r.id) c=x; for(const y of (x.replies||[])) if(y.id===r.id) c=y; } } return c?`Comentario de ${esc(user(c.user).name)}: “${esc(c.text.slice(0,80))}”`:(w?`Comentario en “${esc(w.title)}”`:'Comentario'); }
  return `Usuario @${esc(r.id)}`;
}
SCREENS.reports={ render(p){
  const mod=p.mode==='mod';
  if(mod && !(me()&&me().isMod)) return topbar({title:'Moderación'})+emptyHTML('lock','Solo moderación','Esta sección es para el equipo de moderación.');
  if(mod && !UI.modList){ UI.modList='loading'; DB.modReports().then(l=>{ UI.modList=l; if(current().name==='reports') refresh(); },e=>{ UI.modList=null; toast(errMsg(e)); }); }
  const list=mod?(Array.isArray(UI.modList)?UI.modList.map(r=>({rid:r.id,kind:r.kind,id:r.targetId,reason:r.reason,note:r.note,status:r.status,t:new Date(r.createdAt).getTime(),by:r.auto?'sistema':(r.reporter||'?'),target:r.target})):[]):S.reports.filter(r=>r.by===S.session||r.by==='sistema');
  const st={pendiente:['Pendiente',''],retirado:['Contenido retirado','red'],descartado:['Descartado','gray']};
  return `${topbar({title:mod?'Moderación':'Mis reportes'})}<div class="scroll"><div class="pad">${mod?`<div class="mod-flag" style="margin-bottom:14px;background:rgba(155,124,240,.1);border-color:rgba(155,124,240,.3);color:var(--purple)">${icon('shield')}<span>Panel de revisión humana. Los reportes llegan de la comunidad y del filtro automático de lenguaje.</span></div>`:''}
  ${mod&&UI.modList==='loading'?'<div class="empty"><div class="spinner"></div></div>':list.length?list.map(r=>`<div class="card" style="padding:14px;margin-bottom:10px"><div class="row between"><span class="tag ${st[r.status][1]}">${st[r.status][0]}</span><span class="tiny faint">${timeAgo(r.t)}</span></div><p style="margin:8px 0 4px;font-weight:700">${mod?reportTargetMod(r):reportTarget(r)}</p><div class="small muted">Motivo: ${esc(r.reason)}${r.note&&r.by!=='sistema'?` · “${esc(r.note)}”`:''}</div><div class="tiny faint" style="margin-top:3px">Reportado por: ${r.by==='sistema'?'Detección automática':esc(r.by===S.session?'ti':'@'+r.by)}</div>
  ${mod&&r.status==='pendiente'?`<div class="row" style="margin-top:10px"><button class="btn btn-sm btn-red grow" data-a="modAct" data-id="${r.rid}" data-v="retirado">${icon('ban')} Retirar</button><button class="btn btn-sm btn-ghost grow" data-a="modAct" data-id="${r.rid}" data-v="descartado">${icon('check')} Descartar</button>${r.kind==='work'?`<button class="btn btn-sm btn-ghost" data-a="modOpen" data-id="${r.id}">${icon('eye')}</button>`:''}</div>`:''}</div>`).join(''):emptyHTML('shield-check',mod?'Sin reportes pendientes':'No has enviado reportes','Gracias por ayudar a mantener CHOGGUN como un espacio seguro.')}</div></div>`; } };
A.modAct=async el=>{ try{ await DB.modResolve(+el.dataset.id,el.dataset.v); }catch(e){ return toast(errMsg(e)); }
  UI.modList=null; if(el.dataset.v==='retirado'){ /* la obra deja de verse al refrescar */ } refresh(); toast(el.dataset.v==='retirado'?'Contenido retirado':'Reporte descartado'); };
A.modOpen=async el=>{ const id=el.dataset.id; if(!work(id)){ try{ await DB.refreshWork(S,id); }catch(e){} } if(!work(id)) return toast('Esta obra ya no existe'); go('work',{id}); };

/* ======================= EVENTOS GLOBALES ======================= */
document.addEventListener('click',e=>{
  const el=e.target.closest('[data-a]'); if(!el) return;
  const a=el.dataset.a; if(a==='overlayBg' && e.target!==el) return;
  if(A[a]){ e.preventDefault(); e.stopPropagation(); try{ A[a](el,e); }catch(err){ console.error(err); toast('Ups, algo salió mal'); } }
});
document.addEventListener('submit',e=>{ const f=e.target.closest('[data-f]'); if(!f) return; e.preventDefault(); if(F[f.dataset.f]) F[f.dataset.f](f); });
document.addEventListener('input',e=>{ if(e.target.matches('.composer textarea')){ const t=e.target; t.style.height='auto'; t.style.height=Math.min(110,t.scrollHeight)+'px'; } });

function handleBack(){ return back(); }
window.addEventListener('popstate',()=>{ const handled=handleBack(); if(handled) history.pushState({c:1},''); });

/* ======================= SESIÓN Y DATOS ======================= */
let softTimer=null;
/** Redibuja la pantalla actual con datos nuevos, sin molestar si la persona está escribiendo. */
function softRefresh(){
  clearTimeout(softTimer);
  softTimer=setTimeout(()=>{
    const c=current(); const a=document.activeElement;
    if(overlayOpen() || (a && /INPUT|TEXTAREA|SELECT/.test(a.tagName))) return;
    if(['home','explore','community','profile','user','work','notifs','chats','matches'].includes(c.name)) refresh(); else updateBadges();
  },350);
}
async function startSession(){
  const s=await DB.getSession();
  if(!s){ endSession(); return; }
  S.uid=s.user.id; S.email=s.user.email||'';
  await DB.loadPublic(S);
  let mine=Object.values(S.users).find(u=>u.id===S.uid);
  for(let i=0;!mine&&i<4;i++){ await new Promise(r=>setTimeout(r,500)); await DB.ensureProfiles(S,[S.uid]); mine=Object.values(S.users).find(u=>u.id===S.uid); }
  if(!mine){ await DB.signOut(); throw new Error('No se encontró tu perfil. Vuelve a entrar.'); }
  S.session=mine.username;
  await DB.loadMine(S,S.uid);
  S.loaded=true; S.loadError=false;
  listen();
  loadMatchState().then(()=>softRefresh());
}
function endSession(){
  const settings=S.settings; S={...emptyData(),settings}; UI.modList=null; pedit=null; draft=null; medit=null;
  DB.loadPublic(S).then(()=>{ S.loaded=true; softRefresh(); },()=>{ S.loadError=true; });
  listen();
}
function listen(){
  DB.subscribe(S.uid,{
    works:async ev=>{
      if(ev.eventType==='DELETE'){ const id=ev.old&&ev.old.id; if(id){ S.works=S.works.filter(w=>w.id!==id); softRefresh(); } return; }
      const r=ev.new; const visible=(r.status==='publicado'&&!r.removed)||r.author_id===S.uid||(me()&&me().isMod);
      if(!visible){ S.works=S.works.filter(w=>w.id!==r.id); softRefresh(); return; }
      await DB.ensureProfiles(S,[r.author_id]); const old=work(r.id); const prevEdit=old&&old.created;
      const w=DB.upsertWork(S,r); if(old && ev.eventType==='UPDATE' && prevEdit!==undefined) w.chapters=null;
      softRefresh();
    },
    profiles:ev=>{ if(ev.eventType==='DELETE') return; const u=DB.addProfile(S,ev.new); if(u.username===S.session) S.session=u.username; softRefresh(); },
    communities:ev=>{ if(ev.eventType==='DELETE'){ S.communities=S.communities.filter(c=>c.id!==(ev.old&&ev.old.id)); } else DB.upsertCommunity(S,ev.new); softRefresh(); },
    comments:ev=>{ const wid=(ev.new&&ev.new.work_id)||(ev.old&&ev.old.work_id); const w=wid?work(wid):null;
      // El borrado solo trae el id: se recargan las conversaciones abiertas.
      const targets=w?[w]:S.works.filter(x=>x.comments);
      targets.forEach(x=>{ if(x.comments && !x._loadingComments){ x._loadingComments=true; DB.loadComments(S,x).then(()=>{ x._loadingComments=false; redrawComments(x); },()=>{ x._loadingComments=false; }); } }); },
    notifications:async ev=>{ const row=await DB.fetchNotif(ev.new.id).catch(()=>null); if(!row||S.notifRows.some(n=>n.id===row.id)) return; S.notifRows.unshift(row); S.notifRows=S.notifRows.slice(0,80); updateBadges(); showIncoming(row); if(row.type==='match'){ if(row.actor_id) DB.ensureProfiles(S,[row.actor_id]).catch(()=>{}); loadMatches(); } if(current().name==='notifs') softRefresh(); },
    messages:async ev=>{ const m=ev.new; await DB.prepareMessage(S,m); const msg=DB.addMessage(S,m); if(!msg) return;
      const other=msg.from===S.session?S.byId[m.recipient_id]:msg.from; const c=current();
      if(c.name==='chat'&&c.params.id===other){ const box=$('#msgs'); if(box){ box.innerHTML=chatMsgsHTML(other); const sc=$('#msgScroll'); sc.scrollTop=sc.scrollHeight; } if(msg.from!==S.session){ S.chats[chatId(other)].unread[S.session]=false; DB.markChatRead(S.uid,m.sender_id).catch(()=>{}); } }
      updateBadges(); if(c.name==='chats') softRefresh(); },
    status:st=>{ if(st==='SUBSCRIBED' && S._wasOffline){ S._wasOffline=false; resync(); } if(st==='CHANNEL_ERROR'||st==='TIMED_OUT'||st==='CLOSED') S._wasOffline=true; },
  });
}
/** Al volver la conexión: se ponen al día los datos (por si llegó algo mientras no había red). */
let resyncing=false;
async function resync(){
  if(resyncing) return; resyncing=true;
  try{ await DB.loadPublic(S); if(S.uid) await DB.loadMine(S,S.uid); S.loaded=true; S.loadError=false; softRefresh(); updateBadges(); }
  catch(e){ S.loadError=true; }
  finally{ resyncing=false; }
}

/* ======================= INICIO ======================= */
async function boot(){
  load(); applyTheme();
  matchMedia('(prefers-color-scheme: light)').addEventListener?.('change',()=>{ if(S.settings.theme==='system') applyTheme(); });
  const hideSplash=()=>{ const sp=$('#splash'); if(!sp) return; sp.classList.add('hide'); setTimeout(()=>sp.remove(),550); if(isNative) SplashScreen.hide().catch(()=>{}); };
  let hasSession=false;
  try{ hasSession=!!(await DB.getSession()); }catch(e){}
  try{
    if(hasSession) await startSession(); else endSession();
  }catch(e){ S.loadError=true; toast(errMsg(e)); if(!S.session) endSession(); }
  if(!S.settings.onboarded) stack=[{name:'onboarding',params:{i:0}}];
  else if(!S.session) stack=[{name:'auth',params:{mode:'login',first:true}}];
  else stack=[{name:'home',params:{}}];
  render(); hideSplash();
  try{ history.pushState({c:1},''); }catch(e){}
  if(isNative){ CapApp.addListener('backButton',()=>{ if(!handleBack()) CapApp.exitApp(); }); CapApp.addListener('resume',()=>{ DB.reconnect(); if(S.loadError) resync(); loadNews(); }); }
  DB.onAuth((ev)=>{ if(ev==='TOKEN_REFRESHED') DB.refreshRealtimeAuth(); if(ev==='SIGNED_OUT' && S.session){ endSession(); stack=[{name:'auth',params:{mode:'login',first:true}}]; render(); } });
  window.addEventListener('beforeunload',()=>save(true));
  window.addEventListener('online',()=>{ DB.reconnect(); resync(); });
  document.addEventListener('visibilitychange',()=>{ if(document.hidden) save(true); else { DB.reconnect(); loadNews(); } });
  loadNews();
  setInterval(()=>loadNews(),NEWS_TTL);
}
boot();
